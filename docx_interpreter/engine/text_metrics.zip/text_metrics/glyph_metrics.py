"""Measurement utilities converting shaped glyphs to layout metrics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from .font_loader import FontLoader
from .harfbuzz_shaper import HarfBuzzShaper, ShapedGlyph


@dataclass(slots=True)
class PositionedGlyph:
    glyph_id: int
    cluster: int
    x: float
    y: float
    advance_x: float
    advance_y: float
    index: int


@dataclass(slots=True)
class TextLayout:
    text: str
    font_size: float
    width: float
    ascent: float
    descent: float
    height: float
    baseline: float
    glyphs: List[PositionedGlyph]
    direction: Optional[str] = None


class GlyphMetrics:
    """Compute text metrics using HarfBuzz shaping results."""

    def __init__(self, font_loader: Optional[FontLoader]) -> None:
        self.font_loader = font_loader
        self._shaper = None
        if font_loader and font_loader.has_shaper:
            try:
                self._shaper = HarfBuzzShaper(font_loader)
            except RuntimeError:
                self._shaper = None

    def layout_text(
        self,
        text: str,
        *,
        font_size: float,
        direction: Optional[str] = None,
        language: Optional[str] = None,
        script: Optional[str] = None,
        features: Optional[Sequence[str]] = None,
    ) -> TextLayout:
        if not text:
            text = ""

        if not self._shaper or not self.font_loader:
            return self._fallback_layout(text, font_size)

        shaped = self._shaper.shape_text(
            text,
            font_size=font_size,  # Pass font_size to set hb_font.scale dynamically
            features=features,
            direction=direction,
            language=language,
            script=script,
        )

        scale = self.font_loader.scale_for_size(font_size)
        ascent_units, descent_units = self.font_loader.get_ascent_descent()
        line_gap_units = self.font_loader.get_line_gap()

        positioned: List[PositionedGlyph] = []

        for glyph in shaped:
            # position_x and position_y: Since hb_font.scale is set to (font_size * 64, font_size * 64),
            # HarfBuzz returns positions in 1/64 * font_size * 64 = font_size units (points)
            # In harfbuzz_shaper, cursor_x is accumulated using x_adv_units which is already in points
            # After dividing by 64.0, position_x is already in points
            # So we should NOT multiply by scale
            x = glyph.position_x  # Already in points (no need to multiply by scale)
            y = glyph.position_y  # Already in points (no need to multiply by scale)
            
            # x_advance and y_advance: Since hb_font.scale is set to (font_size * 64, font_size * 64),
            # HarfBuzz returns x_advance in 1/64 * font_size * 64 = font_size units (points)
            # In harfbuzz_shaper, we divide by 64.0 to get points directly: x_adv_units = pos.x_advance / 64.0
            # So glyph.x_advance is already in points, we should NOT multiply by scale
            advance_x = glyph.x_advance  # Already in points (no need to multiply by scale)
            advance_y = glyph.y_advance  # Already in points (no need to multiply by scale)
            
            positioned.append(
                PositionedGlyph(
                    glyph_id=glyph.glyph_id,
                    cluster=glyph.cluster,
                    x=x,
                    y=y,
                    advance_x=advance_x,
                    advance_y=advance_y,
                    index=glyph.index,
                )
            )

        # Width calculation for RTL/mixed text: use max_x - min_x
        # This handles cases where advances are negative (RTL) or mixed direction
        min_x = 0.0
        max_x = 0.0
        if positioned:
            # Get all x positions (including glyph positions + offsets)
            x_positions = [g.x for g in positioned]
            # Also consider end positions (x + advance_x) for RTL
            end_positions = [g.x + g.advance_x for g in positioned]
            
            # Calculate actual bounding box
            min_x = min(min(x_positions), min(end_positions))
            max_x = max(max(x_positions), max(end_positions))
            
            # Width = max_x - min_x (handles RTL, mixed, and negative advances)
            width = max_x - min_x
            
            # Fallback: if width is zero or negative, use sum of absolute advances
            if width <= 0:
                width = sum(abs(g.advance_x) for g in positioned)
        else:
            width = 0.0
        
        # Debug: if width is suspiciously small, log it (only at DEBUG level)
        if width < 100 and len(positioned) > 50:
            import logging
            logger = logging.getLogger("docx_interpreter.engine.text_metrics.glyph_metrics")
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(f"Text width calculation: {width:.2f} points for {len(positioned)} glyphs. "
                           f"Sum of advances: {sum(g.advance_x for g in positioned):.2f}. "
                           f"Min x: {min_x:.2f}, Max x: {max_x:.2f}. "
                           f"Scale: {scale:.6f}.")

        ascent = max(ascent_units, 0) * scale
        descent = abs(descent_units) * scale
        line_gap = max(line_gap_units, 0) * scale
        height = ascent + descent + line_gap
        baseline = ascent

        return TextLayout(
            text=text,
            font_size=font_size,
            width=width,
            ascent=ascent,
            descent=descent,
            height=height,
            baseline=baseline,
            glyphs=positioned,
            direction=direction,
        )

    # ------------------------------------------------------------------
    # Fallback measurement when HarfBuzz is unavailable
    # ------------------------------------------------------------------
    def _fallback_layout(self, text: str, font_size: float) -> TextLayout:
        average_char_width = font_size * 0.6
        width = len(text) * average_char_width
        ascent = font_size * 0.8
        descent = font_size * 0.2
        height = ascent + descent
        baseline = ascent
        return TextLayout(
            text=text,
            font_size=font_size,
            width=width,
            ascent=ascent,
            descent=descent,
            height=height,
            baseline=baseline,
            glyphs=[],
        )

