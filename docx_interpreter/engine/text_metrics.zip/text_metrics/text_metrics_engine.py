"""Facade for glyph-level measurement with graceful fallbacks."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

from .font_loader import FontLoader, FontLoaderError
from .glyph_metrics import GlyphMetrics, TextLayout
from ..font_resolver import resolve_font_path


class TextMetricsError(RuntimeError):
    """Raised when advanced text measurement cannot be performed."""


@dataclass(slots=True)
class MetricsConfig:
    font_path: Optional[Path]
    default_font_size: float = 12.0
    direction: Optional[str] = None
    language: Optional[str] = None
    script: Optional[str] = None
    features: Optional[Sequence[str]] = None


@lru_cache(maxsize=128)
def _cached_font_loader(font_path: str) -> Tuple[FontLoader, GlyphMetrics]:
    loader = FontLoader(font_path)
    metrics = GlyphMetrics(loader)
    return loader, metrics


class TextMetricsEngine:
    """High-level API used by the layout engine to measure text runs.
    
    Features:
    - LRU cache for shaped text (font_path, size, features, text) -> TextLayout
    - Thread-safe font loading
    - Graceful fallbacks when HarfBuzz unavailable
    """

    def __init__(self, font_path: Optional[str | Path] = None, *, default_font_size: float = 12.0) -> None:
        self.config = MetricsConfig(
            font_path=Path(font_path) if font_path else None,
            default_font_size=default_font_size,
        )

        self._font_loader: Optional[FontLoader] = None
        self._metrics: GlyphMetrics = GlyphMetrics(None)
        self._current_font_path: Optional[Path] = None

        if self.config.font_path is not None:
            self._initialise_loader(self.config.font_path)
    
    @lru_cache(maxsize=512)
    def _cached_layout_text(
        self,
        text: str,
        font_path_str: Optional[str],
        font_size: float,
        direction: Optional[str],
        language: Optional[str],
        script: Optional[str],
        features_tuple: Optional[Tuple[str, ...]],
    ) -> TextLayout:
        """Cached layout text computation (LRU cache).
        
        Cache key: (text, font_path, font_size, direction, language, script, features)
        Cache size: 512 entries (should cover most common cases in tables/repeaters)
        """
        # Reconstruct features from tuple
        features = list(features_tuple) if features_tuple else None
        
        # Get font path if provided
        font_path = Path(font_path_str) if font_path_str else None
        
        # Temporarily switch font if needed
        if font_path and font_path != self._current_font_path:
            self._maybe_switch_font(font_path)
        
        # Use current metrics to layout text
        return self._metrics.layout_text(
            text,
            font_size=font_size,
            direction=direction,
            language=language,
            script=script,
            features=features,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def layout_text(self, text: str, style: Optional[Dict[str, Any]] = None) -> TextLayout:
        """Layout text with caching for better performance.
        
        Args:
            text: Text to layout
            style: Style dictionary with font info
            
        Returns:
            TextLayout with metrics
        """
        # Resolve style parameters
        font_path = self._resolve_font_path(style)
        font_size = self._resolve_font_size(style)
        direction = self._resolve_property(style, "direction", self.config.direction)
        language = self._resolve_property(style, "language", self.config.language)
        script = self._resolve_property(style, "script", self.config.script)
        features = self._resolve_features(style, self.config.features)
        
        # Convert features to tuple for cache key
        features_tuple = tuple(features) if features else None
        font_path_str = str(font_path.resolve()) if font_path and font_path.exists() else None
        
        try:
            # Use cached layout if available
            return self._cached_layout_text(
                text,
                font_path_str,
                font_size,
                direction,
                language,
                script,
                features_tuple,
            )
        except FontLoaderError as exc:  # pragma: no cover - defensive
            raise TextMetricsError(str(exc)) from exc
        except Exception as exc:  # pragma: no cover - defensive fallback
            # Fall back to naive layout if advanced shaping fails
            fallback_metrics = GlyphMetrics(None)
            return fallback_metrics.layout_text(text, font_size=font_size)

    # ------------------------------------------------------------------
    # Loader initialisation
    # ------------------------------------------------------------------
    def _initialise_loader(self, font_path: Path) -> None:
        resolved = font_path.expanduser().resolve()
        try:
            loader, metrics = _cached_font_loader(str(resolved))
        except FontLoaderError as exc:
            # Keep fallback metrics but surface the error when shaping is requested
            self._font_loader = None
            self._metrics = GlyphMetrics(None)
            self._current_font_path = None
            raise TextMetricsError(str(exc)) from exc
        else:
            self._font_loader = loader
            self._metrics = metrics
            self._current_font_path = resolved

    # ------------------------------------------------------------------
    # Style helpers
    # ------------------------------------------------------------------
    def _resolve_font_size(self, style: Optional[Dict[str, Any]]) -> float:
        if not style:
            return self.config.default_font_size

        if "font_size" in style and style["font_size"]:
            return float(style["font_size"])

        font_dict = style.get("font") if isinstance(style.get("font"), dict) else None
        if font_dict:
            size = font_dict.get("size") or font_dict.get("size_pt") or font_dict.get("size_hps")
            if size:
                try:
                    value = float(size)
                    if font_dict.get("size_hps") and not font_dict.get("size"):
                        value = value / 2.0
                    return value
                except (TypeError, ValueError):
                    pass

        return self.config.default_font_size

    def _resolve_property(self, style: Optional[Dict[str, Any]], key: str, default: Optional[str]) -> Optional[str]:
        if not style:
            return default

        if key in style and style[key]:
            return str(style[key])

        font_dict = style.get("font") if isinstance(style.get("font"), dict) else None
        if font_dict and font_dict.get(key):
            return str(font_dict[key])

        return default

    def _resolve_features(
        self,
        style: Optional[Dict[str, Any]],
        default: Optional[Sequence[str]],
    ) -> Optional[Sequence[str]]:
        # Default features: enable kerning and ligatures for better typography
        DEFAULT_FEATURES = ("kern=1", "liga=1")
        
        if not style:
            # If no style provided, use default or fallback to kerning/ligatures
            return default or DEFAULT_FEATURES

        features = style.get("harfbuzz_features") or style.get("features")
        if isinstance(features, (list, tuple)):
            # User explicitly provided features, use them
            return tuple(str(feature) for feature in features)

        if isinstance(features, str):
            # User provided features as comma-separated string, parse and use them
            return tuple(part.strip() for part in features.split(","))

        # No features in style, use provided default or fallback to kerning/ligatures
        return default or DEFAULT_FEATURES

    @property
    def supports_shaping(self) -> bool:
        return bool(self._font_loader and self._font_loader.has_shaper)

    def _resolve_font_path(self, style: Optional[Dict[str, Any]]) -> Optional[Path]:
        if not style:
            return None

        font_path = style.get("font_path") or style.get("fontFile")
        if font_path:
            return Path(font_path)

        font_dict = style.get("font") if isinstance(style.get("font"), dict) else None
        if font_dict and font_dict.get("path"):
            return Path(font_dict["path"])

        font_name = style.get("font_name")
        if not font_name and font_dict:
            for key in ("name", "family", "ascii"):
                if font_dict.get(key):
                    font_name = font_dict[key]
                    break
        if not font_name:
            font_name = style.get("font_ascii") or style.get("font_hAnsi")

        if font_name:
            bold = bool(style.get("bold") or style.get("font_weight") == "bold")
            italic = bool(style.get("italic") or style.get("font_style") == "italic")
            resolved = resolve_font_path(str(font_name), bold=bold, italic=italic)
            if resolved:
                variant_name, font_path = resolved
                style.setdefault("font_pdf_name", variant_name)
                style["font_path"] = font_path
                return Path(font_path)

        return None

    def _maybe_switch_font(self, requested_path: Optional[Path]) -> None:
        target_path = requested_path or self.config.font_path
        if target_path is None:
            if self._current_font_path is not None:
                self._font_loader = None
                self._metrics = GlyphMetrics(None)
                self._current_font_path = None
            return

        target_path = target_path.expanduser().resolve()
        if self._current_font_path and self._current_font_path == target_path:
            return

        try:
            self._initialise_loader(target_path)
        except TextMetricsError:
            # Fallback silently; caller will still receive naive metrics
            self._font_loader = None
            self._metrics = GlyphMetrics(None)
            self._current_font_path = None

