"""Font loading utilities for text layout using HarfBuzz."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Dict, Optional, Tuple

try:  # pragma: no cover - optional dependency
    import harfpy as _hb  # type: ignore
    _HB_BACKEND = "harfpy"
except ImportError:  # pragma: no cover - optional dependency
    try:
        import uharfbuzz as _hb  # type: ignore
        _HB_BACKEND = "uharfbuzz"
    except ImportError:  # pragma: no cover - optional dependency
        _hb = None  # type: ignore
        _HB_BACKEND = None

try:  # pragma: no cover - optional dependency
    from fontTools.ttLib import TTFont
except ImportError:  # pragma: no cover - optional dependency
    TTFont = None  # type: ignore


class FontLoaderError(RuntimeError):
    """Raised when a font cannot be loaded for glyph shaping."""


@dataclass(slots=True)
class FontMetrics:
    units_per_em: int
    ascent: int
    descent: int
    line_gap: int
    s_typo_ascender: Optional[int] = None  # OS/2 sTypoAscender
    s_typo_descender: Optional[int] = None  # OS/2 sTypoDescender
    s_typo_line_gap: Optional[int] = None  # OS/2 sTypoLineGap


class FontLoader:
    """Load font metrics and create HarfBuzz font instances.
    
    Thread-safe: Uses per-size cache for HB fonts to avoid scale conflicts.
    """

    # Per-size cache for HB fonts: (font_path, size) -> hb_font
    _hb_font_cache: Dict[Tuple[str, int], Any] = {}
    _cache_lock = threading.Lock()

    def __init__(self, font_path: str | Path) -> None:
        self.font_path = Path(font_path)
        if not self.font_path.exists():
            raise FontLoaderError(f"Font file not found: {self.font_path}")

        if TTFont is None:
            raise FontLoaderError("fontTools is required for glyph metrics")

        self._ttfont = TTFont(str(self.font_path))
        self._metrics = self._extract_metrics()
        # Base HB font (with default scale) - for compatibility
        self._hb_font = self._create_harfbuzz_font()

    # ---------------------------------------------------------------------
    # Public API
    # ---------------------------------------------------------------------
    @property
    def hb_font(self):  # pragma: no cover - thin wrapper
        return self._hb_font

    @property
    def metrics(self) -> FontMetrics:
        return self._metrics

    @property
    def has_shaper(self) -> bool:
        return self._hb_font is not None

    def get_ascent_descent(self) -> Tuple[int, int]:
        return self._metrics.ascent, self._metrics.descent

    def get_line_gap(self) -> int:
        return self._metrics.line_gap

    def get_units_per_em(self) -> int:
        return self._metrics.units_per_em

    def scale_for_size(self, point_size: float) -> float:
        """Return scaling factor from font units to point units."""

        upem = max(self._metrics.units_per_em, 1)
        return point_size / upem
    
    def get_hb_font_for_size(self, point_size: float):
        """Get thread-safe HB font for specific size (cached per size).
        
        Args:
            point_size: Font size in points
            
        Returns:
            HB font instance with scale set for this size
        """
        if _hb is None:
            return None
        
        # Round size to nearest integer for cache key
        size_key = int(round(point_size))
        cache_key = (str(self.font_path.resolve()), size_key)
        
        # Check cache first
        with self._cache_lock:
            if cache_key in self._hb_font_cache:
                return self._hb_font_cache[cache_key]
        
        # Create new HB font for this size
        hb_font = self._create_harfbuzz_font_for_size(point_size)
        
        # Cache it
        if hb_font is not None:
            with self._cache_lock:
                # Limit cache size to prevent memory issues
                if len(self._hb_font_cache) > 100:
                    # Remove oldest entry (simple FIFO)
                    oldest_key = next(iter(self._hb_font_cache))
                    del self._hb_font_cache[oldest_key]
                self._hb_font_cache[cache_key] = hb_font
        
        return hb_font
    
    def _create_harfbuzz_font_for_size(self, point_size: float):
        """Create new HB font instance with scale set for specific size."""
        if _hb is None:
            return None
        
        try:
            font_bytes = self.font_path.read_bytes()
        except OSError as exc:
            return None
        
        try:
            if hasattr(_hb.Blob, "create_from_file_path"):
                blob = _hb.Blob.create_from_file_path(str(self.font_path))
            elif hasattr(_hb.Blob, "create"):
                blob = _hb.Blob.create(font_bytes)
            else:
                blob = _hb.Blob(font_bytes)
            
            face = _hb.Face(blob, 0)
            hb_font = _hb.Font(face)
            # Set scale to (point_size * 64, point_size * 64) for this size
            scale_x = int(point_size * 64)
            scale_y = int(point_size * 64)
            hb_font.scale = (scale_x, scale_y)
            
            if hasattr(_hb, "ot_font_set_funcs"):
                _hb.ot_font_set_funcs(hb_font)
            
            return hb_font
        except Exception:
            return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _extract_metrics(self) -> FontMetrics:
        """Extract font metrics with OS/2 sTypo fallback for better baseline/leading."""
        head = self._ttfont["head"]
        hhea = self._ttfont["hhea"]
        units_per_em = getattr(head, "unitsPerEm", 1000)
        
        # Try OS/2 sTypo metrics first (more stable baseline/leading)
        s_typo_ascender = None
        s_typo_descender = None
        s_typo_line_gap = None
        
        if "OS/2" in self._ttfont:
            os2 = self._ttfont["OS/2"]
            s_typo_ascender = getattr(os2, "sTypoAscender", None)
            s_typo_descender = getattr(os2, "sTypoDescender", None)
            s_typo_line_gap = getattr(os2, "sTypoLineGap", None)
        
        # Fallback to hhea metrics if OS/2 sTypo not available
        ascent = getattr(hhea, "ascent", 0)
        descent = getattr(hhea, "descent", 0)
        line_gap = getattr(hhea, "lineGap", 0)
        
        # Use sTypo if available, otherwise use hhea
        if s_typo_ascender is not None:
            ascent = s_typo_ascender
        if s_typo_descender is not None:
            descent = s_typo_descender
        if s_typo_line_gap is not None:
            line_gap = s_typo_line_gap
        
        return FontMetrics(
            units_per_em=units_per_em,
            ascent=ascent,
            descent=descent,
            line_gap=line_gap,
            s_typo_ascender=s_typo_ascender,
            s_typo_descender=s_typo_descender,
            s_typo_line_gap=s_typo_line_gap,
        )

    def _create_harfbuzz_font(self):  # pragma: no cover - optional dependency
        if _hb is None:
            return None

        try:
            font_bytes = self.font_path.read_bytes()
        except OSError as exc:  # pragma: no cover - filesystem error
            raise FontLoaderError(f"Failed to read font bytes: {exc}") from exc

        try:
            if hasattr(_hb.Blob, "create_from_file_path"):
                blob = _hb.Blob.create_from_file_path(str(self.font_path))
            elif hasattr(_hb.Blob, "create"):
                blob = _hb.Blob.create(font_bytes)
            else:  # pragma: no cover - fallback for uharfbuzz
                blob = _hb.Blob(font_bytes)

            face = _hb.Face(blob, 0)
            hb_font = _hb.Font(face)
            upem = face.upem
            hb_font.scale = (upem, upem)

            # Some wrappers require setting functions for glyph advances
            if hasattr(_hb, "ot_font_set_funcs"):
                _hb.ot_font_set_funcs(hb_font)

            return hb_font
        except Exception as exc:  # pragma: no cover - optional dependency
            return None


