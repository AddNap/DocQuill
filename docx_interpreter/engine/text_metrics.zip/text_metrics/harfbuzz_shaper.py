"""Glyph shaping helpers built on top of HarfBuzz wrappers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, List, Optional, Sequence

try:  # pragma: no cover - optional dependency
    import harfpy as _hb  # type: ignore
    _HB_BACKEND = "harfpy"
except ImportError:  # pragma: no cover - optional dependency
    try:
        import uharfbuzz as _hb  # type: ignore
        _HB_BACKEND = "uharfbuzz"
    except ImportError:  # pragma: no cover - optional dependency
        _hb = None  # type: ignore
        _HB_BACKEND = None

# Export _HB_BACKEND for use in feature processing
__all__ = ["HarfBuzzShaper", "ShapedGlyph", "_HB_BACKEND"]

from .font_loader import FontLoader


@dataclass(slots=True)
class ShapedGlyph:
    glyph_id: int
    cluster: int
    x_advance: float
    y_advance: float
    x_offset: float
    y_offset: float
    position_x: float
    position_y: float
    index: int


class HarfBuzzShaper:
    """Shape text into positioned glyphs using HarfBuzz."""

    def __init__(self, font_loader: FontLoader) -> None:
        if _hb is None:
            raise RuntimeError("HarfBuzz wrapper (harfpy or uharfbuzz) is not available")

        if not font_loader.has_shaper:
            raise RuntimeError("FontLoader was initialised without HarfBuzz font support")

        self.font_loader = font_loader

    def shape_text(
        self,
        text: str,
        *,
        font_size: Optional[float] = None,
        features: Optional[Sequence[str]] = None,
        direction: Optional[str] = None,
        language: Optional[str] = None,
        script: Optional[str] = None,
    ) -> List[ShapedGlyph]:
        # Use thread-safe per-size HB font cache instead of modifying scale
        # This avoids race conditions when multiple threads shape text with different sizes
        hb_font = self.font_loader.hb_font
        if font_size is not None:
            # Get cached HB font for this size (thread-safe)
            hb_font_for_size = self.font_loader.get_hb_font_for_size(font_size)
            if hb_font_for_size is not None:
                hb_font = hb_font_for_size
        
        buffer = _hb.Buffer()
        buffer.add_str(text)

        # Guess default properties before overriding specific ones
        if hasattr(buffer, "guess_segment_properties"):
            buffer.guess_segment_properties()

        if direction:
            self._set_buffer_direction(buffer, direction)
        if language:
            self._set_buffer_language(buffer, language)
        if script:
            self._set_buffer_script(buffer, script)

        # Default features: enable kerning and ligatures for better typography
        # Global fallback to ensure kerning is always enabled
        DEFAULT_FEATURES = ["kern=1", "liga=1"]
        
        # Use provided features or fallback to defaults
        active_features = features or DEFAULT_FEATURES
        
        # Convert feature strings to dictionary format if needed (for some HarfBuzz wrappers)
        # Format can be "kern=1" (string) or {"kern": 1} (dict) depending on wrapper
        processed_features = self._process_features(active_features)
        
        # Log features only at DEBUG level with rate limiting
        import logging
        logger = logging.getLogger(__name__)
        if logger.isEnabledFor(logging.DEBUG):
            # Rate limit: only log first occurrence per unique text prefix
            if not hasattr(self, '_logged_features'):
                self._logged_features = set()
            text_prefix = text[:40] if len(text) > 40 else text
            feature_key = (text_prefix, tuple(processed_features.items()) if isinstance(processed_features, dict) else tuple(processed_features))
            if feature_key not in self._logged_features:
                self._logged_features.add(feature_key)
                # Limit logged features set size
                if len(self._logged_features) > 100:
                    self._logged_features.clear()
                if isinstance(processed_features, dict):
                    kern_enabled = processed_features.get("kern", 0)
                    liga_enabled = processed_features.get("liga", 0)
                    if kern_enabled or liga_enabled:
                        logger.debug(f"Features: kern={kern_enabled}, liga={liga_enabled} for text: '{text_prefix}...'")
        
        _hb.shape(hb_font, buffer, processed_features)

        infos = buffer.glyph_infos
        positions = buffer.glyph_positions

        shaped: List[ShapedGlyph] = []
        cursor_x = 0.0
        cursor_y = 0.0

        for index, (info, pos) in enumerate(zip(infos, positions)):
            x_adv_units = pos.x_advance / 64.0
            y_adv_units = pos.y_advance / 64.0
            x_off_units = pos.x_offset / 64.0
            y_off_units = pos.y_offset / 64.0

            glyph = ShapedGlyph(
                glyph_id=info.codepoint,
                cluster=getattr(info, "cluster", 0),
                x_advance=x_adv_units,
                y_advance=y_adv_units,
                x_offset=x_off_units,
                y_offset=y_off_units,
                position_x=cursor_x + x_off_units,
                position_y=cursor_y + y_off_units,
                index=index,
            )
            shaped.append(glyph)

            cursor_x += x_adv_units
            cursor_y += y_adv_units

        return shaped

    # ------------------------------------------------------------------
    # Feature processing
    # ------------------------------------------------------------------
    def _process_features(self, features: Sequence[str]) -> Any:  # pragma: no cover - optional dependency
        """Process feature strings into format expected by HarfBuzz wrapper.
        
        Detects backend (harfpy vs uharfbuzz) and returns appropriate format:
        - harfpy: dict {"kern": 1}
        - uharfbuzz: list ["kern=1"]
        """
        if not features:
            return {} if _HB_BACKEND == "harfpy" else []
        
        # Convert to format based on detected backend
        if _HB_BACKEND == "harfpy":
            # harfpy prefers dict format
            feature_dict = {}
            for feature in features:
                if isinstance(feature, str):
                    if "=" in feature:
                        key, value = feature.split("=", 1)
                        key = key.strip()
                        try:
                            value = int(value.strip())
                            feature_dict[key] = value
                        except ValueError:
                            feature_dict[key] = value.strip()
                    else:
                        feature_dict[feature.strip()] = 1
                elif isinstance(feature, dict):
                    feature_dict.update(feature)
            return feature_dict
        elif _HB_BACKEND == "uharfbuzz":
            # uharfbuzz prefers string list format
            return [str(f) for f in features]
        else:
            # Fallback: try dict first
            try:
                feature_dict = {}
                for feature in features:
                    if isinstance(feature, str):
                        if "=" in feature:
                            key, value = feature.split("=", 1)
                            key = key.strip()
                            try:
                                value = int(value.strip())
                                feature_dict[key] = value
                            except ValueError:
                                feature_dict[key] = value.strip()
                        else:
                            feature_dict[feature.strip()] = 1
                    elif isinstance(feature, dict):
                        feature_dict.update(feature)
                return feature_dict
            except Exception:
                return list(features) if features else []

    # ------------------------------------------------------------------
    # Buffer helpers (wrapper-specific fallbacks)
    # ------------------------------------------------------------------
    def _set_buffer_direction(self, buffer, direction: str) -> None:  # pragma: no cover - optional dependency
        direction = direction.lower()
        try:
            buffer.direction = direction
            return
        except AttributeError:
            pass

        if hasattr(_hb, "Direction"):
            try:
                buffer.direction = getattr(_hb.Direction, direction.upper())
                return
            except AttributeError:
                pass

        if hasattr(_hb, "buffer_set_direction"):
            enum = getattr(_hb, f"DIRECTION_{direction.upper()}", None)
            if enum is not None:
                _hb.buffer_set_direction(buffer, enum)

    def _set_buffer_language(self, buffer, language: str) -> None:  # pragma: no cover - optional dependency
        try:
            buffer.language = language
        except AttributeError:
            if hasattr(_hb, "language_from_string"):
                buffer.language = _hb.language_from_string(language)

    def _set_buffer_script(self, buffer, script: str) -> None:  # pragma: no cover - optional dependency
        try:
            buffer.script = script
        except AttributeError:
            if hasattr(_hb, "script_from_string"):
                buffer.script = _hb.script_from_string(script)

