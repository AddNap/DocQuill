"""Type definitions and protocols for the compiler."""

from __future__ import annotations

from typing import Any, Dict, Protocol, runtime_checkable

from docx_interpreter.engine.geometry import Margins, Size


@runtime_checkable
class DocumentModel(Protocol):
    """Protocol for document models used by PdfCompiler.
    
    This protocol defines the minimum interface that a document model
    must implement to work with PdfCompiler.
    """

    _numbering: Dict[str, Any]
    _context: Any
    placeholder_values: Dict[str, Any]

    def _determine_page_geometry(self) -> tuple[Size, Margins]:
        """Determine page size and margins from document properties.
        
        Returns:
            Tuple of (page_size, margins)
        """
        ...

