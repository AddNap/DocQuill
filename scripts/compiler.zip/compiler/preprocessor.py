"""Simple preprocessing pass for placeholder resolution and content transforms."""

from __future__ import annotations

import re
from typing import Any

from .compilation_context import CompilationContext

PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*([\w\.:-]+)\s*\}\}")


class Preprocessor:
    """Resolve placeholders and basic directives before layout."""

    def __init__(self, model: Any, context: CompilationContext) -> None:
        self.model = model
        self.context = context

    def process(self) -> Any:
        """Return a processed model ready for layout."""

        return self._resolve(self.model)

    def _resolve(self, node: Any) -> Any:
        if isinstance(node, str):
            return PLACEHOLDER_PATTERN.sub(self._replace, node)
        if isinstance(node, list):
            return [self._resolve(item) for item in node]
        if isinstance(node, dict):
            return {key: self._resolve(value) for key, value in node.items()}
        return node

    def _replace(self, match: re.Match[str]) -> str:
        key = match.group(1)
        value = self._lookup_variable(key)
        return "" if value is None else str(value)

    def _lookup_variable(self, dotted_key: str) -> Any:
        current: Any = self.context.variables
        for part in dotted_key.split('.'):
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current


__all__ = ["Preprocessor"]

