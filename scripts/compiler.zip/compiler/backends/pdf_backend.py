"""Rendering backend supporting both ReportLab and direct PDF generation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple

# ------------------------------------------------------------------
# Tunable constants (avoid magic numbers)
# ------------------------------------------------------------------
DEFAULT_DPI: float = 72.0
DEFAULT_MARGIN_PT: float = 50.0
DEFAULT_MARGINS: Tuple[float, float, float, float] = (
    DEFAULT_MARGIN_PT,
    DEFAULT_MARGIN_PT,
    DEFAULT_MARGIN_PT,
    DEFAULT_MARGIN_PT,
)
DEFAULT_PAGE_SIZE_PT: Tuple[float, float] = (595.28, 841.89)  # A4 in pt
FOOTER_AREA_EXTRA_PT: float = 150.0
DEFAULT_TABLE_ROW_MIN_HEIGHT_PT: float = 12.0
DEFAULT_TABLE_ROW_HEIGHT_PT: float = 18.0

from docx_interpreter.engine.base_engine import LayoutBlock, LayoutPage
from docx_interpreter.engine.geometry import Rect
from docx_interpreter.renderers.pdf_renderer import PdfRenderer
from docx_interpreter.renderers.render_utils import resolve_padding, to_color

# Import model classes for type-based rendering
try:
    from docx_interpreter.models.table import Table, TableRow, TableCell
    from docx_interpreter.models.paragraph import Paragraph
    from docx_interpreter.models.run import Run
    from docx_interpreter.models.image import Image
    from docx_interpreter.models.textbox import TextBox
    from docx_interpreter.models.shape import Shape
    from docx_interpreter.models.hyperlink import Hyperlink
    from docx_interpreter.models.field import Field
except ImportError:
    # Fallback if models are not available
    Table = TableRow = TableCell = Paragraph = Run = Image = TextBox = Shape = Hyperlink = Field = None

from ..compilation_context import CompilationContext
from .pdf import DirectPdfWriter


class PdfBackend:
    """Backend responsible for turning layout pages into a PDF file."""

    def __init__(
        self,
        output_path: str | Path,
        options: Dict[str, Any] | None = None,
        *,
        context: Optional[CompilationContext] = None,
    ) -> None:
        self.output_path = Path(output_path)
        options = options or {}

        # Support both "backend" and "renderer" keys for compatibility
        # Default to "direct" mode for full DOCX fidelity
        self.mode = (options.get("backend") or options.get("renderer") or "direct").lower()
        page_size = options.get("page_size") or "A4"
        margins = options.get("margins") or DEFAULT_MARGINS
        dpi = float(options.get("dpi") or DEFAULT_DPI)

        self.reportlab_renderer: PdfRenderer | None = None
        self.direct_writer: DirectPdfWriter | None = None
        self.context = context
        self.logger = logging.getLogger("compiler.pdf_backend")
        self.dpi = dpi

        if self.mode == "direct":
            # In direct mode, prefer DOCX page margins; only use provided margins as fallback
            if margins is not None and margins != DEFAULT_MARGINS:
                parsed_cli_margins = self._parse_margins(margins)
                self.logger.warning(
                    f"Margins from CLI options (will be used as fallback if DOCX margins unavailable): "
                    f"top={parsed_cli_margins[0]:.2f}, right={parsed_cli_margins[1]:.2f}, "
                    f"bottom={parsed_cli_margins[2]:.2f}, left={parsed_cli_margins[3]:.2f} pt"
                )
                self.margins = parsed_cli_margins
            else:
                self.logger.warning(f"Using default margins as CLI fallback: {DEFAULT_MARGINS}")
                # margins is either None or DEFAULT_MARGINS at this point, so parse it directly
                self.margins = self._parse_margins(margins) if margins is not None else self._parse_margins(DEFAULT_MARGINS)
        else:
            self.reportlab_renderer = PdfRenderer(page_size=page_size, margins=margins, dpi=dpi)

    def render(self, layout_pages: Sequence[LayoutPage] | Any) -> None:
        pages = layout_pages
        if hasattr(layout_pages, "pages"):
            pages = getattr(layout_pages, "pages")

        if self.mode == "direct":
            self._render_direct(pages)
        else:
            assert self.reportlab_renderer is not None
            self.reportlab_renderer.render(pages, self.output_path)

    def save(self) -> None:
        if self.mode == "direct" and self.direct_writer is not None:
            self.direct_writer.write()

    # ------------------------------------------------------------------
    # Direct rendering helpers
    # ------------------------------------------------------------------
    def _convert_layout_y_to_pdf(self, layout_y_bottom: float, layout_height: float, page: Optional[LayoutPage] = None) -> float:
        """Convert Y coordinate from layout engine (top-down) to PDF (bottom-up).
        
        Layout engine uses top-down coordinates (Y increases downward from top):
        - frame.y is the BOTTOM edge of the block
        - frame.y + frame.height is the TOP edge of the block
        
        PDF uses bottom-up coordinates (Y increases upward from bottom):
        - Origin (0,0) is at bottom-left corner
        - Y increases upward
        - Bottom edge: pdf_y = page_height - (layout_y_bottom + layout_height)
        
        Args:
            layout_y_bottom: Bottom edge Y coordinate in layout coordinates
            layout_height: Height of the block in layout coordinates
            page: LayoutPage object (for page height)
            
        Returns:
            Bottom edge Y coordinate in PDF coordinates
        """
        page_height = page.size.height if page and hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
        # Convert: pdf_y = page_height - (layout_y_bottom + layout_height)
        pdf_y_bottom = page_height - (layout_y_bottom + layout_height)
        return pdf_y_bottom
    
    def _parse_margins(self, margins: Any) -> Tuple[float, float, float, float]:
        """Parse margins from various formats and return (top, right, bottom, left).
        
        Supports:
        - 4-tuple: (top, right, bottom, left)
        - 2-tuple: (top, bottom) - assumes equal left/right = 50
        - 1-tuple: (value,) - uses value for all margins
        - Single numeric value: float or int
        - Default: DEFAULT_MARGINS if invalid format
        
        Args:
            margins: Margins in various formats
            
        Returns:
            Tuple of (top, right, bottom, left) margins
        """
        def _norm(value: float) -> float:
            # Heuristic unit normalization: points by default
            v = float(value)
            if v > 10000:  # likely EMU
                return v / 12700.0
            if v > 1000:   # likely twips (1/20 pt)
                return v / 20.0
            return v
        
        if isinstance(margins, (tuple, list)):
            if len(margins) >= 4:
                # Format: (top, right, bottom, left)
                return tuple(_norm(m) for m in margins[:4])
            elif len(margins) == 2:
                # Format: (top, bottom) - assume equal left/right
                top = _norm(margins[0])
                bottom = _norm(margins[1])
                return (top, DEFAULT_MARGIN_PT, bottom, DEFAULT_MARGIN_PT)
            elif len(margins) == 1:
                # Single value - use for all
                margin_value = _norm(margins[0])
                return (margin_value, margin_value, margin_value, margin_value)
            else:
                # Empty tuple/list - use default
                return DEFAULT_MARGINS
        elif isinstance(margins, (int, float)):
            # Single numeric value
            margin_value = _norm(margins)
            return (margin_value, margin_value, margin_value, margin_value)
        elif isinstance(margins, dict):
            # Dict with possible units and sides
            top = margins.get("top")
            right = margins.get("right")
            bottom = margins.get("bottom")
            left = margins.get("left")
            unit = (margins.get("unit") or margins.get("units") or "pt").lower()
            def conv(val: Any) -> float:
                if val is None:
                    return 50.0
                v = float(val)
                if unit in ("twip", "twips"):
                    return v / 20.0
                if unit in ("emu", "emus"):
                    return v / 12700.0
                if unit in ("inch", "in"):
                    return v * 72.0
                if unit in ("mm", "millimeter", "millimeters"):
                    return v * 72.0 / 25.4
                # default points
                return v
            return (
                conv(top),
                conv(right),
                conv(bottom),
                conv(left),
            )
        else:
            # Invalid format - use default
            self.logger.warning(f"Invalid margins format: {type(margins)}, using default {DEFAULT_MARGINS}")
            return DEFAULT_MARGINS
    
    def _get_page_margins(self, page: Any, log_once: bool = False) -> Tuple[float, float, float, float]:
        """Extract and normalize margins from a LayoutPage if available, otherwise fallback.
        
        Args:
            page: LayoutPage object
            log_once: If True, log margin source only once per page (cached by page number)
        
        Returns:
            Tuple of (top, right, bottom, left) margins in points
        """
        # Cache logged pages to avoid duplicate logging
        if not hasattr(self, '_logged_margin_pages'):
            self._logged_margin_pages = set()
        
        page_num = getattr(page, "number", None) if hasattr(page, "number") else None
        should_log = log_once and (page_num is None or page_num not in self._logged_margin_pages)
        
        try:
            if hasattr(page, "margins") and page.margins is not None:
                m = page.margins
                # Object with attributes
                if hasattr(m, "top") and hasattr(m, "right") and hasattr(m, "bottom") and hasattr(m, "left"):
                    raw = (getattr(m, "top"), getattr(m, "right"), getattr(m, "bottom"), getattr(m, "left"))
                    parsed = self._parse_margins(raw)
                    if should_log:
                        self.logger.warning(
                            f"Page {page_num}: Using margins from DOCX - "
                            f"top={parsed[0]:.2f}, right={parsed[1]:.2f}, "
                            f"bottom={parsed[2]:.2f}, left={parsed[3]:.2f} pt"
                        )
                        if page_num is not None:
                            self._logged_margin_pages.add(page_num)
                    return parsed
                # dict-like
                if isinstance(m, dict):
                    parsed = self._parse_margins(m)
                    if should_log:
                        self.logger.warning(
                            f"Page {page_num}: Using margins from DOCX (dict) - "
                            f"top={parsed[0]:.2f}, right={parsed[1]:.2f}, "
                            f"bottom={parsed[2]:.2f}, left={parsed[3]:.2f} pt"
                        )
                        if page_num is not None:
                            self._logged_margin_pages.add(page_num)
                    return parsed
                # tuple/list
                if isinstance(m, (tuple, list)):
                    parsed = self._parse_margins(m)
                    if should_log:
                        self.logger.warning(
                            f"Page {page_num}: Using margins from DOCX (tuple/list) - "
                            f"top={parsed[0]:.2f}, right={parsed[1]:.2f}, "
                            f"bottom={parsed[2]:.2f}, left={parsed[3]:.2f} pt"
                        )
                        if page_num is not None:
                            self._logged_margin_pages.add(page_num)
                    return parsed
            # Fallback to backend margins if set, else default
            if hasattr(self, "margins") and isinstance(self.margins, (tuple, list)):
                parsed = self._parse_margins(self.margins)
                if should_log:
                    self.logger.warning(
                        f"Page {page_num}: DOCX margins not available, falling back to CLI margins - "
                        f"top={parsed[0]:.2f}, right={parsed[1]:.2f}, "
                        f"bottom={parsed[2]:.2f}, left={parsed[3]:.2f} pt"
                    )
                    if page_num is not None:
                        self._logged_margin_pages.add(page_num)
                return parsed
        except Exception as e:
            self.logger.debug(f"Error extracting margins from page: {e}", exc_info=True)
        if should_log:
            self.logger.warning(
                f"Page {page_num}: DOCX margins not available, using default margins - "
                f"top={DEFAULT_MARGINS[0]:.2f}, right={DEFAULT_MARGINS[1]:.2f}, "
                f"bottom={DEFAULT_MARGINS[2]:.2f}, left={DEFAULT_MARGINS[3]:.2f} pt"
            )
            if page_num is not None:
                self._logged_margin_pages.add(page_num)
        return DEFAULT_MARGINS
    
    def _render_direct(self, pages: Sequence[LayoutPage]) -> None:
        if not pages:
            self.direct_writer = DirectPdfWriter(self.output_path, dpi=self.dpi)
            return

        self.direct_writer = DirectPdfWriter(self.output_path, dpi=self.dpi)
        if self.context:
            self.direct_writer.set_metadata(Title=f"Document ({len(pages)} pages)")

        for page in pages:
            if self.context:
                self.logger.debug("Rendering page %d", page.number)
            pdf_page = self.direct_writer.add_page(page.size.width, page.size.height)
            
            # Separate blocks by type for proper rendering order
            # Regular blocks (paragraphs, tables, headers) render top to bottom
            # Footer blocks render bottom to top (reverse order)
            regular_blocks = []
            footer_blocks = []
            absolutely_positioned = []  # Graphics, smartart, textboxes, etc.
            
            # Normalize margins (prefer those from DOCX page)
            # Log margins only once per page
            page_margins = self._get_page_margins(page, log_once=True)
            
            for block in page.blocks:
                # Diagnostics: detect blocks positioned with negative Y (outside page)
                try:
                    if hasattr(block, "block_type") and hasattr(block, "frame") and hasattr(block.frame, "y"):
                        if float(getattr(block.frame, "y", 0.0)) < 0.0:
                            self.logger.warning(
                                f"Negative Y detected for block_type={getattr(block, 'block_type', 'unknown')} "
                                f"on page {getattr(page, 'number', 'N/A')}: y={getattr(block.frame, 'y', 'N/A')}, "
                                f"height={getattr(block.frame, 'height', 'N/A')}, x={getattr(block.frame, 'x', 'N/A')}"
                            )
                        # Width diagnostics: element wider than content area
                        page_width = page.size.width if hasattr(page.size, "width") else DEFAULT_PAGE_SIZE_PT[0]
                        # _get_page_margins already returns parsed margins as (top, right, bottom, left)
                        top_m, right_m, bottom_m, left_m = self._get_page_margins(page)
                        content_left = float(left_m)
                        content_right = float(page_width - right_m)
                        x = float(getattr(block.frame, 'x', 0.0))
                        w = float(getattr(block.frame, 'width', 0.0))
                        if x < content_left - 0.1 or (x + w) > content_right + 0.1:
                            self.logger.warning(
                                f"Block exceeds page content width (page {getattr(page, 'number', 'N/A')}): "
                                f"type={getattr(block, 'block_type', 'unknown')}, x={x:.2f}, w={w:.2f}, "
                                f"content_area=[{content_left:.2f}, {content_right:.2f}]"
                            )
                except Exception as e:
                    self.logger.debug(f"Error in block width diagnostics: {e}", exc_info=True)
                # Check if block is in footer area (low Y position in PDF coordinates)
                # Footer blocks are at the bottom of the page
                # Footer area: y < margins.bottom + FOOTER_AREA_EXTRA_PT
                page_height = page.size.height if hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
                # page_margins is already parsed as (top, right, bottom, left) tuple
                _, _, bottom_margin, _ = page_margins
                footer_area_threshold = bottom_margin + FOOTER_AREA_EXTRA_PT
                is_footer_area = block.frame.y < footer_area_threshold
                
                if block.block_type == "footer":
                    footer_blocks.append(block)
                elif block.block_type == "table" and is_footer_area:
                    # Table in footer area - treat as footer block
                    self.logger.debug(f"Found table block in footer area (y={block.frame.y:.2f}, threshold={footer_area_threshold:.2f}), adding to footer_blocks")
                    footer_blocks.append(block)
                elif hasattr(block, "absolute_position") and getattr(block, "absolute_position", False):
                    # Absolutely positioned elements (graphics, smartart, textboxes)
                    absolutely_positioned.append(block)
                else:
                    regular_blocks.append(block)
            
            # Render regular blocks first (top to bottom)
            for block in regular_blocks:
                self._render_block_direct(pdf_page, block, page)
            
            # Render footer blocks in reverse order (bottom to top)
            # Start from footer height (bottom margin) and work upward
            if footer_blocks:
                self._render_footers_bottom_to_top(pdf_page, footer_blocks, page)
            
            # Render absolutely positioned elements last (they overlay everything)
            for block in absolutely_positioned:
                self._render_block_direct(pdf_page, block, page)

    def _render_block_direct(self, pdf_page: Any, block: LayoutBlock, page: Optional[LayoutPage], _recursion_depth: int = 0) -> None:
        """Main dispatcher for rendering layout blocks based on content type.
        
        This method uses a type-based dispatch system:
        1. First, tries to detect the element type from block.content
        2. If element is a model class (Table, Paragraph, etc.), uses dedicated render methods
        3. Falls back to legacy block_type-based rendering for backwards compatibility
        
        Args:
            pdf_page: PDF page object
            block: LayoutBlock to render
            page: LayoutPage (optional, None for nested content like table cells)
            _recursion_depth: Internal parameter to prevent infinite recursion (max depth: 2)
        """
        # Prevent infinite recursion
        if _recursion_depth > 2:
            self.logger.error(f"Maximum recursion depth exceeded in _render_block_direct. Block type: {block.block_type}, content type: {type(block.content)}")
            return
        
        # Try to get the original element from block content
        element = None
        content = block.content
        
        # Check if content is already an element object (Table, Paragraph, etc.)
        if hasattr(content, "__class__"):
            element_class_name = content.__class__.__name__
            # Check if it's one of our model classes
            if Table is not None and isinstance(content, Table):
                self.logger.debug(f"Dispatching to _render_table_element for Table object")
                self._render_table_element(pdf_page, content, block, page)
                return
            elif TableCell is not None and isinstance(content, TableCell):
                # TableCell rendering is handled within table rendering
                self.logger.debug(f"TableCell found in block.content - this should be handled by table rendering")
            elif Paragraph is not None and isinstance(content, Paragraph):
                # Check if block.content is dict with layout info (lines) - if so, use legacy rendering
                # Layout engine stores layout info as dict in block.content, not as Paragraph object
                # So if content is Paragraph object, we should check if block.content is dict
                if isinstance(block.content, dict) and block.content.get("lines"):
                    self.logger.debug(f"Paragraph object found but block.content is dict with lines - using legacy rendering")
                    # Don't dispatch to _render_paragraph_element, fall through to legacy rendering
                else:
                    # block.content is Paragraph object, not dict - use paragraph element renderer
                    self.logger.debug(f"Dispatching to _render_paragraph_element for Paragraph object")
                    self._render_paragraph_element(pdf_page, content, block, page)
                    return
            elif Image is not None and isinstance(content, Image):
                self.logger.debug(f"Dispatching to _render_image_element for Image object")
                self._render_image_element(pdf_page, content, block, page)
                return
            elif TextBox is not None and isinstance(content, TextBox):
                self.logger.debug(f"Dispatching to _render_textbox_element for TextBox object")
                self._render_textbox_element(pdf_page, content, block, page)
                return
            elif Shape is not None and isinstance(content, Shape):
                self.logger.debug(f"Dispatching to _render_shape_element for Shape object")
                self._render_shape_element(pdf_page, content, block, page)
                return
        
        # Check if content is a dict that might contain element object
        if isinstance(content, dict):
            # Try to get element from dict (some parsers store element in "object" key)
            element = content.get("object") or content.get("element")
            if element is not None and hasattr(element, "__class__"):
                if Table is not None and isinstance(element, Table):
                    self.logger.debug(f"Dispatching to _render_table_element for Table from dict")
                    self._render_table_element(pdf_page, element, block, page)
                    return
                elif Paragraph is not None and isinstance(element, Paragraph):
                    self.logger.debug(f"Dispatching to _render_paragraph_element for Paragraph from dict")
                    self._render_paragraph_element(pdf_page, element, block, page)
                    return
                elif Image is not None and isinstance(element, Image):
                    self.logger.debug(f"Dispatching to _render_image_element for Image from dict")
                    self._render_image_element(pdf_page, element, block, page)
                    return
                elif TextBox is not None and isinstance(element, TextBox):
                    self.logger.debug(f"Dispatching to _render_textbox_element for TextBox from dict")
                    self._render_textbox_element(pdf_page, element, block, page)
                    return
                elif Shape is not None and isinstance(element, Shape):
                    self.logger.debug(f"Dispatching to _render_shape_element for Shape from dict")
                    self._render_shape_element(pdf_page, element, block, page)
                    return
        
        # Fallback to block_type-based rendering (for backwards compatibility)
        if block.block_type == "table":
            self._render_table_direct(pdf_page, block, page)
            return
        
        # Allow image and textbox blocks to be rendered as well
        if block.block_type not in {"paragraph", "header", "footer", "image", "textbox"}:
            return

        # Fallback to legacy paragraph rendering
        # CRITICAL FIX: block.content should be dict with layout info (lines) from ParagraphEngine
        # If block.content is not a dict, it might be a model object (Paragraph, etc.)
        # In that case, we should try to render it using the appropriate renderer
        payload = block.content if isinstance(block.content, dict) else None
        if not payload:
            # block.content is not a dict - check if it's a model object we can render
            # But only if we haven't already checked it above (prevents infinite recursion)
            if hasattr(block.content, "__class__") and content == block.content:
                # We've already checked this content above - don't recurse
                self.logger.warning(f"Block content is {block.content.__class__.__name__} object but not a recognized model type. Skipping render.")
            else:
                self.logger.warning(f"Block content is neither dict nor model object: {type(block.content)}")
            return

        lines = payload.get("lines")
        if not lines:
            payload_keys = list(payload.keys()) if isinstance(payload, dict) else 'not a dict'
            print(f"[WARNING] Paragraph block has no lines in payload. Payload keys: {payload_keys}")
            self.logger.warning(f"Paragraph block has no lines in payload. Payload keys: {payload_keys}")
            return
        
        # CRITICAL: Log ALL paragraphs to diagnose line breaking
        style = block.style or {}
        pad_top, pad_right, pad_bottom, pad_left = resolve_padding(style)
        
        # Calculate content width (frame width minus padding) - this is the actual usable width
        # usable_width from payload may not account for padding, so we calculate it here
        content_width = max(0.0, block.frame.width - pad_left - pad_right)
        
        # Get usable_width from payload for reference, but prefer content_width for actual rendering
        # usable_width from paragraph engine accounts for indents but may not account for padding
        usable_width_from_payload = payload.get("usable_width")
        if usable_width_from_payload is not None:
            # Verify that usable_width from payload is reasonable (should be <= content_width)
            usable_width_from_payload = float(usable_width_from_payload)
            if usable_width_from_payload > content_width + 0.1:  # Allow small floating point differences
                self.logger.warning(
                    f"usable_width from payload ({usable_width_from_payload:.2f}) > content_width ({content_width:.2f}). "
                    f"Using content_width for rendering."
                )
                usable_width = content_width
            else:
                # usable_width from payload is valid, but we still use content_width for rendering
                # as it accounts for padding correctly
                usable_width = usable_width_from_payload
        else:
            usable_width = content_width
        
        full_text = payload.get("text", "")
        
        if len(lines) > 1:
            print(f"[INFO] MULTI-LINE PARAGRAPH: {len(lines)} lines, content_width={content_width:.2f}, usable_width={usable_width:.2f}, full_text_length={len(full_text)}")
            self.logger.warning(
                f"MULTI-LINE PARAGRAPH: {len(lines)} lines, "
                f"content_width={content_width:.2f}, usable_width={usable_width:.2f}, full_text_length={len(full_text)} - "
                f"block.frame.y={block.frame.y:.2f}, block.frame.height={block.frame.height:.2f}"
            )
            # Log first few lines to see what we're working with
            for i, line_entry in enumerate(lines[:3]):
                line_text = str(line_entry.get("text", ""))[:50] if isinstance(line_entry, dict) else str(line_entry)[:50]
                line_layout = line_entry.get("layout") if isinstance(line_entry, dict) else None
                line_width = line_layout.width if line_layout and hasattr(line_layout, "width") else None
                line_width_str = f"{line_width:.2f}" if line_width is not None else "N/A"
                self.logger.warning(f"  Line {i}: '{line_text}...' (width={line_width_str})")
        else:
            # Single line - log to see if it should have been broken
            line_text = str(lines[0].get("text", ""))[:100] if lines and isinstance(lines[0], dict) else str(lines[0])[:100] if lines else "empty"
            line_layout = lines[0].get("layout") if lines and isinstance(lines[0], dict) else None
            line_width = line_layout.width if line_layout and hasattr(line_layout, "width") else None
            should_break = len(line_text) > 50 and content_width > 0 and (line_width is None or line_width > content_width)
            line_width_str = f"{line_width:.2f}" if line_width is not None else "N/A"
            if len(line_text) > 80:  # Only print long paragraphs that might need breaking
                print(f"[INFO] SINGLE-LINE paragraph (long): length={len(line_text)}, content_width={content_width:.2f}, line_width={line_width_str}, should_break={should_break}")
            self.logger.warning(
                f"SINGLE-LINE paragraph: '{line_text[:80]}...' "
                f"(length={len(line_text)}, content_width={content_width:.2f}, line_width={line_width_str}, "
                f"should_break={should_break})"
            )

        # CRITICAL FIX: block_top should be the top of the FIRST line, not the top of the block
        # Layout engine uses top-down coordinates (Y increases downward from top)
        # PDF uses bottom-up coordinates (Y increases upward from bottom, origin at bottom-left)
        # block.frame.y is the BOTTOM edge of the block in layout coordinates
        # block.frame.height is the total height of the block (should include all lines)
        # For multi-line paragraphs, block.frame.height should be sum of all line heights
        # But we need block_top to be the top of the first line for rendering
        
        # Convert from layout coordinates to PDF coordinates
        # PDF Y increases upward from bottom, so we need to convert
        pdf_y_bottom = self._convert_layout_y_to_pdf(block.frame.y, block.frame.height, page)
        # Top edge in PDF coordinates
        pdf_y_top = pdf_y_bottom + block.frame.height
        initial_block_top = pdf_y_top - pad_top
        block_top = initial_block_top  # Keep track of initial position for offset_baseline calculations
        
        # Log initial block_top for ALL paragraphs to diagnose collapsed text
        # Check if this paragraph might be collapsing with previous ones
        if len(lines) > 1:
            self.logger.warning(
                f"📄 MULTI-LINE Paragraph ({len(lines)} lines) - initial block_top: {block_top:.2f}, "
                f"frame.y: {block.frame.y:.2f}, frame.height: {block.frame.height:.2f}, "
                f"pad_top: {pad_top:.2f}"
            )
            # Calculate expected total height from all lines
            total_line_height = 0.0
            for line_idx, entry in enumerate(lines):
                line_layout = entry.get("layout") if isinstance(entry, dict) else None
                if line_layout and hasattr(line_layout, "height"):
                    line_height = float(getattr(line_layout, "height"))
                    total_line_height += line_height
            if abs(total_line_height - block.frame.height) > 0.1:
                self.logger.warning(
                    f"⚠️ Paragraph height mismatch: block.frame.height={block.frame.height:.2f} "
                    f"vs sum of line heights={total_line_height:.2f}"
                )
        line_spacing = float(payload.get("line_spacing", 1.0) or 1.0)
        # Get font size from style - DOCX may store in half-points
        font_size_raw = style.get("font_size")
        if font_size_raw is None:
            font_size = 11.0  # Default fallback
        else:
            font_size = float(font_size_raw) if font_size_raw else 11.0
            # DOCX commonly stores font size in half-points (e.g., 18 for 9pt)
            # Normalize: if > 15 and integer, it's likely half-points
            if font_size > 15 and float(font_size).is_integer():
                font_size = font_size / 2.0
        x_origin = block.frame.x + pad_left

        # REQUIRED: font_path must come from DOCX document
        font_path = style.get("font_path")
        if isinstance(font_path, dict):
            font_path = font_path.get("path")
        
        # Remove test-only Helvetica forcing; rely on document-provided fonts
        
        # If font_path is not available, try to resolve from font_name
        if not isinstance(font_path, str):
            font_name = style.get("font_name") or style.get("font_pdf_name")
            if font_name:
                from docx_interpreter.engine.font_resolver import resolve_font_path
                bold = bool(style.get("bold") or style.get("font_weight") == "bold")
                italic = bool(style.get("italic") or style.get("font_style") == "italic")
                resolved = resolve_font_path(str(font_name), bold=bold, italic=italic)
                if resolved:
                    _, font_path = resolved
                else:
                    self.logger.error(
                        f"Failed to resolve font_path for font_name={font_name!r} "
                        f"from DOCX paragraph style. Font must be available in system or embedded."
                    )
                    raise ValueError(f"Font path not found for font: {font_name}")
            else:
                self.logger.error(
                    f"Font path is required but not available from DOCX paragraph style. "
                    f"Neither font_path nor font_name is present. "
                    f"Font must be resolved from DOCX document."
                )
                raise ValueError("Font path is required but not available from DOCX paragraph style")

        assert self.direct_writer is not None

        self._render_block_background(pdf_page, block, style)

        # Get alignment from style
        # DOCX uses 'justification' key, but also check 'alignment'
        alignment = style.get("justification") or style.get("alignment") or "left"
        
        # Normalize alignment values from DOCX format to PDF format
        # DOCX values: left, center, right, both, distribute, start, end
        # PDF values: left, center, right, justify
        if alignment in {"both", "distribute"}:
            alignment = "justify"
        elif alignment in {"end"}:
            alignment = "right"
        elif alignment in {"start"}:
            alignment = "left"
        # 'center' and 'right' stay as is

        for line_idx, entry in enumerate(lines):
            text = str(entry.get("text") or "")
            if not text:
                # CRITICAL: Even for empty lines, we must update block_top to maintain spacing
                # Update block_top for empty lines to prevent next line from collapsing
                if line_idx < len(lines) - 1:  # Not the last line
                    line_layout = entry.get("layout") if isinstance(entry, dict) else None
                    line_height = None
                    if line_layout and hasattr(line_layout, "height"):
                        line_height = float(getattr(line_layout, "height"))
                    if isinstance(line_height, float) and line_height > 0:
                        effective_line_height = max(line_height, font_size * 0.8)
                        line_delta = effective_line_height * line_spacing
                        block_top = block_top - line_delta
                    else:
                        line_delta = font_size * line_spacing
                        block_top = block_top - line_delta
                continue
            
            # Normalize text to NFC (composed form) for consistent encoding
            import unicodedata
            text = unicodedata.normalize("NFC", text)
            
            line_layout = entry.get("layout") if isinstance(entry, dict) else None
            ascent = None
            line_height = None
            layout_baseline = None
            
            if line_layout:
                try:
                    if hasattr(line_layout, "ascent"):
                        ascent = float(getattr(line_layout, "ascent"))
                    if hasattr(line_layout, "height"):
                        line_height = float(getattr(line_layout, "height"))
                    if hasattr(line_layout, "baseline"):
                        layout_baseline = float(getattr(line_layout, "baseline"))
                except Exception:
                    pass
            
            # Log line_height and ascent for ALL lines in multi-line paragraphs to diagnose collapsed text
            if len(lines) > 1:  # Only log for multi-line paragraphs
                self.logger.warning(
                    f"🔍 Line {line_idx}: block_top={block_top:.2f}, ascent={ascent}, "
                    f"line_height={line_height}, layout_baseline={layout_baseline}, line_spacing={line_spacing:.2f}"
                )
            
            # Calculate baseline for this line
            # CRITICAL: Use layout metrics relative to current block_top for accurate positioning
            # block_top is updated after each line to account for line_spacing
            # This ensures each line is positioned correctly relative to the previous one
            if isinstance(ascent, float):
                # Use ascent directly: baseline is ascent below block_top
                baseline = block_top - ascent
            elif isinstance(layout_baseline, float):
                # Use layout.baseline directly: baseline is layout.baseline below block_top
                baseline = block_top - layout_baseline
            else:
                # Fallback: estimate baseline from font_size
                # Use a standard ascent factor (typically 0.8 * font_size)
                default_ascent = font_size * 0.8
                baseline = block_top - default_ascent
            
            # Log baseline calculation for ALL lines to diagnose collapsed text
            if len(lines) > 1:  # Only log for multi-line paragraphs
                self.logger.warning(
                    f"📍 Line {line_idx}/{len(lines)-1}: baseline={baseline:.2f} (block_top={block_top:.2f}, "
                    f"ascent={ascent}, layout_baseline={layout_baseline}, line_height={line_height}, text='{text[:30]}')"
                )
            elif line_idx == 0:  # Log first line even for single-line paragraphs
                self.logger.warning(
                    f"📍 Line 0: baseline={baseline:.2f} (block_top={block_top:.2f}, "
                    f"ascent={ascent}, layout_baseline={layout_baseline}, line_height={line_height})"
                )
            
            # Get line width from layout
            layout = entry.get("layout")
            line_width = layout.width if layout and hasattr(layout, "width") else None
            
            # Calculate X position based on alignment
            # Now that we have /Widths[] in CIDFontType2, alignment should work correctly
            x_start = x_origin
            
            # Calculate word spacing for justified text
            # IMPORTANT: If layout has glyph positions from HarfBuzz, word spacing is NOT needed
            # because HarfBuzz already accounts for kerning/ligatures in advance_x.
            # Using word spacing with HarfBuzz positions would cause double-adjustment and incorrect spacing.
            word_spacing = 0.0
            layout_has_glyphs = layout and hasattr(layout, "glyphs") and layout.glyphs and len(layout.glyphs) > 0
            
            if alignment == "justify" and line_width is not None and content_width > 0 and line_width > 0:
                # Only apply word spacing if we DON'T have HarfBuzz glyph positions
                # HarfBuzz positions already include proper kerning/ligatures
                if not layout_has_glyphs:
                    # Count spaces in text (excluding trailing spaces)
                    space_count = len([c for c in text.rstrip() if c.isspace()])
                    if space_count > 0:
                        # Distribute extra space between words
                        remaining_space = content_width - line_width
                        word_spacing = remaining_space / space_count if space_count > 0 else 0.0
                        # Only apply word spacing if there's actual space to distribute
                        if word_spacing < 0:
                            word_spacing = 0.0
                else:
                    # With HarfBuzz glyph positions, kerning is already in advance_x
                    # So we should NOT use word spacing - it would cause double-adjustment
                    # Instead, we'll rely on glyph positions for accurate rendering
                    word_spacing = 0.0
                    self.logger.debug(
                        f"Justified text with HarfBuzz glyph positions - skipping word spacing "
                        f"(line_width={line_width}, content_width={content_width})"
                    )
            
            # For center/right/justify, we need line_width to be available
            # line_width is in points (from layout engine), content_width is also in points
            if line_width is not None and content_width > 0 and line_width > 0:
                if alignment == "center":
                    # Center: text starts at origin + half of remaining space
                    remaining_space = max(0, content_width - line_width)
                    x_start = x_origin + remaining_space / 2.0
                elif alignment == "right":
                    # Right: text starts at origin + all remaining space
                    remaining_space = max(0, content_width - line_width)
                    x_start = x_origin + remaining_space
                elif alignment == "justify":
                    # Justify uses left alignment with word spacing
                    x_start = x_origin
                else:
                    # left alignment
                    x_start = x_origin
            else:
                # Fallback: if line_width is not available, use left alignment
                if alignment != "left":
                    # Log warning if alignment is requested but line_width is missing
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.debug(
                        f"Alignment '{alignment}' requested but line_width not available "
                        f"(line_width={line_width}, content_width={content_width}). "
                        "Using left alignment."
                    )
                x_start = x_origin
            
            # Render runs individually only if they have different styles
            # Otherwise draw entire line as one piece for better spacing
            # BUT: if layout has glyphs (from HarfBuzz), we must use glyph positions
            # to match the exact spacing, even for single runs
            runs = entry.get("runs", [])
            
            # Check if layout has glyphs (indicates HarfBuzz shaping was used)
            # Note: layout_has_glyphs was already checked above for word spacing calculation
            
            # CRITICAL: Get layout_glyphs BEFORE the if/else branches so it's available in both
            layout_glyphs = []
            if layout_has_glyphs and layout and hasattr(layout, "glyphs"):
                layout_glyphs = layout.glyphs if layout.glyphs else []
            
            # Check if runs have different styles (need separate rendering)
            has_different_styles = False
            if len(runs) > 1:
                first_run_font = runs[0].get("style", {}).get("font_name") if runs else None
                first_run_size = runs[0].get("style", {}).get("font_size") if runs else None
                for run_info in runs[1:]:
                    run_style = run_info.get("style", {})
                    if (run_style.get("font_name") != first_run_font or
                        run_style.get("font_size") != first_run_size):
                        has_different_styles = True
                        break
            
            if layout_has_glyphs or (runs and has_different_styles):
                # Layout has glyphs OR multiple runs with different styles
                # Use glyph positions if available for accurate spacing
                
                if layout_glyphs and len(layout_glyphs) > 0:
                    # Layout has glyphs - but kerning is disabled for now
                    # Use standard rendering without character position adjustments
                    
                    if not runs or len(runs) == 0:
                        # Single run - render without kerning adjustments
                        if not isinstance(font_path, str):
                            raise ValueError("Font path is required but not resolved from DOCX paragraph style")
                        
                        # KERNING DISABLED: Render without character position adjustments
                        # Adjust starting X with first glyph x if needed
                        first_x = getattr(layout_glyphs[0], "x", 0.0) if layout_glyphs else 0.0
                        adjusted_x = x_start + (first_x if alignment in ("left", "justify") else 0.0)
                        
                        # Log baseline for HarfBuzz rendering to diagnose collapsed text
                        if len(lines) > 1:  # Only log for multi-line paragraphs
                            self.logger.debug(
                                f"✏️ Rendering line {line_idx} with HarfBuzz (kerning disabled): baseline={baseline:.2f}, "
                                f"block_top={block_top:.2f}, adjusted_x={adjusted_x:.2f}, text='{text[:30]}'"
                            )
                        
                        self.direct_writer.add_text(
                            pdf_page,
                            adjusted_x,
                            baseline,
                            text,
                            font_size,
                            font_path,
                            word_spacing=0.0,
                            character_positions=None,  # Kerning disabled
                        )
                    else:
                        # Multiple runs - use glyph positions for each run's start (kerning disabled)
                        glyph_idx = 0
                        for run_info in runs:
                            run_text = str(run_info.get("text", ""))
                            if not run_text:
                                continue
                            
                            run_style = run_info.get("style", {})
                            # Get font size from run style, using paragraph font_size as fallback
                            run_font_size_raw = run_style.get("font_size")
                            if run_font_size_raw is None:
                                run_font_size = font_size
                            else:
                                run_font_size = float(run_font_size_raw) if run_font_size_raw else font_size
                                # DOCX commonly stores font size in half-points (e.g., 18 for 9pt)
                                # Normalize: if > 15 and integer, it's likely half-points
                                if run_font_size > 15 and float(run_font_size).is_integer():
                                    run_font_size = run_font_size / 2.0
                            run_font_path = None
                             
                            # REQUIRED: Each run must have its own font_path from DOCX
                            run_font_path = run_style.get("font_path")
                            if isinstance(run_font_path, dict):
                                run_font_path = run_font_path.get("path")
                            
                            # If run doesn't have font_path, try to resolve from font_name
                            if not isinstance(run_font_path, str):
                                run_font_name = run_style.get("font_name") or run_style.get("font_pdf_name")
                                if run_font_name:
                                    from docx_interpreter.engine.font_resolver import resolve_font_path
                                    bold = bool(run_style.get("bold") or run_style.get("font_weight") == "bold")
                                    italic = bool(run_style.get("italic") or run_style.get("font_style") == "italic")
                                    resolved = resolve_font_path(str(run_font_name), bold=bold, italic=italic)
                                    if resolved:
                                        _, run_font_path = resolved
                                    else:
                                        self.logger.error(
                                            f"Failed to resolve font_path for font_name={run_font_name!r} "
                                            f"from DOCX run. Font must be available in system or embedded."
                                        )
                                        raise ValueError(f"Font path not found for font: {run_font_name}")
                                else:
                                    # Last resort: use paragraph font_path (but log warning)
                                    if isinstance(font_path, str):
                                        self.logger.warning(
                                            f"Run missing font_path and font_name, using paragraph font_path: {font_path}"
                                        )
                                        run_font_path = font_path
                                    else:
                                        self.logger.error(
                                            f"Run missing font_path and font_name, and paragraph font_path is also missing. "
                                            f"Font must be resolved from DOCX document."
                                        )
                                        raise ValueError("Font path is required but not available from DOCX run or paragraph")
                             
                            # Compute TJ adjustments for this run from HarfBuzz advances
                            run_length = len(run_text)
                            run_character_positions = None
                            
                            # Use first glyph's x position for this run's start
                            if layout_has_glyphs and glyph_idx < len(layout_glyphs):
                                glyph_x = getattr(layout_glyphs[glyph_idx], "x", 0.0)
                                # For center/right alignment, x_start is already calculated correctly
                                # Only add glyph_x offset for left/justify alignment
                                if alignment in ("left", "justify") and glyph_x > 0:
                                    x_cursor = x_start + glyph_x
                                else:
                                    # For center/right, use x_start as calculated
                                    x_cursor = x_start
                            else:
                                # Fallback if no more glyphs
                                x_cursor = x_start
                            
                            # For justified text with multiple runs, word spacing is applied per run
                            # BUT: if layout has HarfBuzz glyph positions, word spacing should be 0
                            run_word_spacing = 0.0
                            if alignment == "justify" and not layout_has_glyphs and word_spacing > 0:
                                # Count spaces in this run
                                run_space_count = len([c for c in run_text if c.isspace()])
                                if run_space_count > 0:
                                    # Apply proportional word spacing
                                    run_word_spacing = word_spacing
                            
                            # REQUIRED: run_font_path must be resolved from DOCX run (already done above)
                            if not isinstance(run_font_path, str):
                                raise ValueError(f"Font path is required but not resolved from DOCX run style")
                            
                            if layout_has_glyphs and glyph_idx + run_length <= len(layout_glyphs):
                                # KERNING DISABLED: Don't calculate character position adjustments
                                run_character_positions = None
                                run_word_spacing = 0.0

                            self.direct_writer.add_text(
                                pdf_page,
                                x_cursor,
                                baseline,
                                run_text,
                                run_font_size,
                                run_font_path,
                                word_spacing=run_word_spacing,
                                character_positions=None,  # Kerning disabled
                            )

                            # Advance glyph index by run length
                            glyph_idx += run_length
                else:
                    # No layout_glyphs - fallback: draw runs sequentially with estimated widths
                    x_cursor = x_start
                    for run_info in runs:
                        run_text = str(run_info.get("text", ""))
                        if not run_text:
                            continue
                        
                        run_style = run_info.get("style", {})
                        # Get font size from run style, using paragraph font_size as fallback
                        run_font_size_raw = run_style.get("font_size")
                        if run_font_size_raw is None:
                            run_font_size = font_size
                        else:
                            run_font_size = float(run_font_size_raw) if run_font_size_raw else font_size
                            # DOCX commonly stores font size in half-points (e.g., 18 for 9pt)
                            # Normalize: if > 15 and integer, it's likely half-points
                            if run_font_size > 15 and float(run_font_size).is_integer():
                                run_font_size = run_font_size / 2.0
                        # REQUIRED: Each run must have its own font_path from DOCX
                        run_font_path = run_style.get("font_path")
                        if isinstance(run_font_path, dict):
                            run_font_path = run_font_path.get("path")
                        
                        # If run doesn't have font_path, try to resolve from font_name
                        if not isinstance(run_font_path, str):
                            run_font_name = run_style.get("font_name") or run_style.get("font_pdf_name")
                            if run_font_name:
                                from docx_interpreter.engine.font_resolver import resolve_font_path
                                bold = bool(run_style.get("bold") or run_style.get("font_weight") == "bold")
                                italic = bool(run_style.get("italic") or run_style.get("font_style") == "italic")
                                resolved = resolve_font_path(str(run_font_name), bold=bold, italic=italic)
                                if resolved:
                                    _, run_font_path = resolved
                                else:
                                    self.logger.error(
                                        f"Failed to resolve font_path for font_name={run_font_name!r} "
                                        f"from DOCX run. Font must be available in system or embedded."
                                    )
                                    raise ValueError(f"Font path not found for font: {run_font_name}")
                            else:
                                # Last resort: use paragraph font_path (but log warning)
                                if isinstance(font_path, str):
                                    self.logger.warning(
                                        f"Run missing font_path and font_name, using paragraph font_path: {font_path}"
                                    )
                                    run_font_path = font_path
                                else:
                                    self.logger.error(
                                        f"Run missing font_path and font_name, and paragraph font_path is also missing. "
                                        f"Font must be resolved from DOCX document."
                                    )
                                    raise ValueError("Font path is required but not available from DOCX run or paragraph")
                        
                        # Estimate width more accurately
                        # Use layout width proportionally if available
                        if layout and hasattr(layout, "width") and text:
                            char_ratio = len(run_text) / len(text) if text else 0
                            run_width = line_width * char_ratio if line_width else 0
                        else:
                            # Estimate: ~0.5-0.6 * font_size per character
                            run_width = len(run_text) * run_font_size * 0.55
                        
                        # Apply word spacing for justified text (only if no HarfBuzz glyph positions)
                        run_word_spacing = 0.0
                        if alignment == "justify" and not layout_has_glyphs and word_spacing > 0:
                            run_space_count = len([c for c in run_text if c.isspace()])
                            if run_space_count > 0:
                                run_word_spacing = word_spacing
                        
                        # REQUIRED: run_font_path must be resolved from DOCX run (already done above)
                        if not isinstance(run_font_path, str):
                            raise ValueError(f"Font path is required but not resolved from DOCX run style")
                        
                        self.direct_writer.add_text(
                            pdf_page,
                            x_cursor,
                            baseline,
                            run_text,
                            run_font_size,
                            run_font_path,
                            word_spacing=run_word_spacing,
                        )
                        
                        x_cursor += run_width
            else:
                # Single run or same style - draw entire line as one piece
                # CRITICAL: Even for single run, if we have HarfBuzz glyphs, we MUST use them for kerning!
                if layout_has_glyphs and layout_glyphs and len(layout_glyphs) > 0:
                    # We have HarfBuzz glyphs - use them for accurate kerning even for single run
                    if not isinstance(font_path, str):
                        raise ValueError("Font path is required but not resolved from DOCX paragraph style")
                    
                    # KERNING DISABLED: Render without character position adjustments
                    # Adjust starting X with first glyph x if needed
                    first_x = getattr(layout_glyphs[0], "x", 0.0) if layout_glyphs else 0.0
                    adjusted_x = x_start + (first_x if alignment in ("left", "justify") else 0.0)
                    
                    self.direct_writer.add_text(
                        pdf_page,
                        adjusted_x,
                        baseline,
                        text,
                        font_size,
                        font_path,
                        word_spacing=0.0,
                        character_positions=None,  # Kerning disabled
                    )
                else:
                    # Glyph count mismatch - fallback to standard rendering
                    effective_word_spacing = word_spacing if alignment == "justify" else 0.0
                    self.direct_writer.add_text(
                        pdf_page,
                        x_start,
                        baseline,
                        text,
                        font_size,
                        font_path,
                        word_spacing=effective_word_spacing,
                    )
            if layout and hasattr(layout, "width") and line_width:
                # No HarfBuzz glyphs - use layout width for accurate text rendering
                # The layout engine already calculated the correct width
                # So we can trust it instead of PDF viewer's spacing
                effective_word_spacing = word_spacing if alignment == "justify" else 0.0
                
                # REQUIRED: font_path must be resolved from DOCX (already done above)
                if not isinstance(font_path, str):
                    raise ValueError(f"Font path is required but not resolved from DOCX paragraph style")
                
                # Log baseline before rendering for multi-line paragraphs
                if len(lines) > 1:
                    self.logger.warning(
                        f"✏️ Rendering line {line_idx} (no HarfBuzz): baseline={baseline:.2f}, "
                        f"block_top={block_top:.2f}, text='{text[:30]}'"
                    )
                
                self.direct_writer.add_text(
                    pdf_page,
                    x_start,
                    baseline,
                    text,
                    font_size,
                    font_path,
                    word_spacing=effective_word_spacing,
                )
            else:
                # Fallback: draw entire line as one piece
                # PDF viewer will handle spacing (may cause issues with CID fonts)
                effective_word_spacing = word_spacing if alignment == "justify" else 0.0
                
                # REQUIRED: font_path must be resolved from DOCX (already done above)
                if not isinstance(font_path, str):
                    raise ValueError(f"Font path is required but not resolved from DOCX paragraph style")
                
                # Log baseline before rendering for multi-line paragraphs
                if len(lines) > 1:
                    self.logger.warning(
                        f"✏️ Rendering line {line_idx} (fallback): baseline={baseline:.2f}, "
                        f"block_top={block_top:.2f}, text='{text[:30]}'"
                    )
                
                self.direct_writer.add_text(
                    pdf_page,
                    x_start,
                    baseline,
                    text,
                    font_size,
                    font_path,
                    word_spacing=effective_word_spacing,
                )
            
            # Update block_top for next line using layout height if available
            # IMPORTANT: Always move block_top down by (line_height * line_spacing) to prevent text from collapsing
            # CRITICAL FIX: line_height from layout engine does NOT include line_spacing, so we must multiply
            block_top_before = block_top
            if isinstance(line_height, float) and line_height > 0:
                # Use line_height with line_spacing: next line starts (line_height * line_spacing) below current block_top
                # Ensure minimum line_height to prevent text from collapsing (at least 80% of font_size)
                min_line_height = font_size * 0.8
                effective_line_height = max(line_height, min_line_height)
                # line_height from layout engine does NOT include line_spacing, so multiply
                line_delta = effective_line_height * line_spacing
                block_top = block_top - line_delta
                
                # Log block_top update for multi-line paragraphs to diagnose collapsed text
                if len(lines) > 1 and line_idx < len(lines) - 1:  # Not the last line
                    self.logger.warning(
                        f"🔄 Line {line_idx}: block_top updated {block_top_before:.2f} -> {block_top:.2f} "
                        f"(line_delta={line_delta:.2f} = line_height={effective_line_height:.2f} * line_spacing={line_spacing:.2f})"
                    )
                
                if effective_line_height != line_height and line_idx < 3:
                    self.logger.warning(
                        f"⚠️ Line {line_idx}: line_height too small ({line_height:.2f}), "
                        f"using minimum ({effective_line_height:.2f}) to prevent collapse"
                    )
            elif isinstance(ascent, float):
                # Fallback: use font_size with line_spacing, accounting for ascent
                # Move down by font_size * line_spacing (not just to baseline)
                line_delta = font_size * line_spacing
                block_top = block_top - line_delta
                
                # Log block_top update for multi-line paragraphs to diagnose collapsed text
                if len(lines) > 1 and line_idx < len(lines) - 1:  # Not the last line
                    self.logger.warning(
                        f"🔄 Line {line_idx}: block_top updated {block_top_before:.2f} -> {block_top:.2f} "
                        f"(ascent fallback, line_delta={line_delta:.2f} = font_size={font_size:.2f} * line_spacing={line_spacing:.2f})"
                    )
                if line_idx < 5:  # Log only first few lines to avoid spam
                    self.logger.warning(
                        f"⚠️ Line {line_idx}: Using ascent fallback (no line_height) - "
                        f"block_top: {block_top_before:.2f} -> {block_top:.2f} "
                        f"(font_size={font_size:.2f}, line_spacing={line_spacing:.2f})"
                    )
            else:
                # Last resort: use default line height with line spacing
                default_line_height = font_size * 1.2 * line_spacing
                block_top = block_top - default_line_height
                if line_idx < 5:  # Log only first few lines to avoid spam
                    self.logger.warning(
                        f"⚠️ Line {line_idx}: Using default fallback (no line_height/ascent) - "
                        f"block_top: {block_top_before:.2f} -> {block_top:.2f} "
                        f"(default_line_height={default_line_height:.2f})"
                    )

            hyperlink = self._extract_hyperlink(style)
            if hyperlink:
                width = line_width if line_width else block.frame.width
                height = font_size * 1.2
                self.direct_writer.add_link(
                    pdf_page,
                    x_start,
                    baseline,
                    x_start + width,
                    baseline + height,
                    hyperlink,
                )

    def _extract_hyperlink(self, style: Dict[str, Any]) -> Optional[str]:
        hyperlink = style.get("hyperlink") if isinstance(style, dict) else None
        if isinstance(hyperlink, dict):
            return hyperlink.get("url") or hyperlink.get("target")
        if isinstance(hyperlink, str):
            return hyperlink
        return None

    def _render_footers_bottom_to_top(
        self, pdf_page: Any, footer_blocks: list[LayoutBlock], page: LayoutPage
    ) -> None:
        """Render footer blocks in reverse order (bottom to top).
        
        Args:
            pdf_page: PDF page object
            footer_blocks: List of footer blocks (in order from top to bottom in layout)
            page: Layout page with size and margins information
        """
        if not footer_blocks:
            self.logger.warning("_render_footers_bottom_to_top: No footer blocks provided")
            return
        
        if not self.direct_writer:
            self.logger.error("_render_footers_bottom_to_top: No direct_writer available!")
            return
        
        self.logger.info(f"_render_footers_bottom_to_top: Rendering {len(footer_blocks)} footer blocks")
        
        # Get page dimensions and margins
        page_width = page.size.width if hasattr(page.size, "width") else 595.0
        page_height = page.size.height if hasattr(page.size, "height") else 842.0
        margins = self._get_page_margins(page)
        
        self.logger.debug(f"_render_footers_bottom_to_top: Page size = {page_width}x{page_height}, margins = {margins}")
        
        # _get_page_margins already returns parsed margins as (top, right, bottom, left) tuple
        # No need to parse again - directly unpack
        if isinstance(margins, (tuple, list)) and len(margins) == 4:
            top_margin, right_margin, bottom_margin, left_margin = float(margins[0]), float(margins[1]), float(margins[2]), float(margins[3])
        else:
            # Fallback: if margins format is unexpected, use defaults
            self.logger.warning(f"Unexpected margins format from _get_page_margins: {type(margins)}, using defaults")
            top_margin = right_margin = bottom_margin = left_margin = 50.0
        
        self.logger.debug(f"_render_footers_bottom_to_top: Parsed margins: top={top_margin}, right={right_margin}, bottom={bottom_margin}, left={left_margin}")
        
        # Layout engine positions footer blocks using frame.y
        # frame.y is already in PDF coordinates (from bottom of page, Y increases upward)
        # Layout engine adds footer blocks in order: first element (lowest Y) first, last element (highest Y) last
        # So we should render them in normal order (not reversed) to maintain correct sequence
        # Sort blocks by Y position (bottom to top) to ensure correct rendering order
        footer_blocks_sorted = sorted(footer_blocks, key=lambda b: b.frame.y)
        for block_idx, block in enumerate(footer_blocks_sorted):
            self.logger.debug(f"Block {block_idx}: block_type={block.block_type}, frame.y={getattr(block.frame, 'y', 'N/A')}, frame.height={getattr(block.frame, 'height', 'N/A')}")
            self.logger.info(f"_render_footers_bottom_to_top: Block {block_idx}: block_type={block.block_type}, frame={block.frame if hasattr(block, 'frame') else None}")
            
            # Check if block is a table (should be handled by _render_table_direct)
            # Tables in footer may have:
            # - block_type == "table"
            # - dict payload with rows/type
            # - direct Table element object from the model
            is_table = (
                block.block_type == "table" or
                (isinstance(block.content, dict) and ("rows" in block.content or block.content.get("type") == "table")) or
                (Table is not None and hasattr(block, "content") and hasattr(block.content, "__class__") and isinstance(block.content, Table))
            )
            
            if is_table:
                self.logger.debug(f"Block {block_idx}: Rendering as TABLE (block_type={block.block_type}, has_rows={'rows' in block.content if isinstance(block.content, dict) else False})")
                self.logger.info(f"_render_footers_bottom_to_top: Block {block_idx}: Rendering as TABLE")
                self._render_table_direct(pdf_page, block, page)
                continue
            
            payload = block.content if isinstance(block.content, dict) else None
            if not payload:
                # If content is a model element (Paragraph, TextBox, Image, etc.), use generic renderer
                if hasattr(block, "content") and hasattr(block.content, "__class__"):
                    self.logger.debug(f"Block {block_idx}: content is model object {block.content.__class__.__name__}, using generic renderer")
                    self._render_block_direct(pdf_page, block, page)
                    continue
                self.logger.debug(f"Block {block_idx}: No payload (content is not dict or None)")
                self.logger.warning(f"_render_footers_bottom_to_top: Block {block_idx}: No payload (content is not dict)")
                continue
            
            lines = payload.get("lines")
            
            # Check if this is a paragraph with textbox content (textbox has absolute positioning)
            # Paragraph may have empty text but textbox content in runs
            has_textbox = False
            textbox_paragraphs = []
            
            if not lines or len(lines) == 0:
                # Check if payload has runs with textbox content
                runs = payload.get("runs", [])
                for run in runs:
                    run_dict = run if isinstance(run, dict) else {}
                    textbox = run_dict.get("textbox") if isinstance(run_dict, dict) else None
                    if not textbox and hasattr(run, "textbox"):
                        textbox = getattr(run, "textbox", None)
                    
                    if textbox:
                        has_textbox = True
                        if isinstance(textbox, list):
                            # Textbox content is a list of paragraphs
                            textbox_paragraphs.extend(textbox)
                        self.logger.debug(f"Block {block_idx}: Found textbox content ({len(textbox) if isinstance(textbox, list) else 1} paragraphs)")
                        break
            
            if not lines and not has_textbox:
                self.logger.debug(f"Block {block_idx}: No lines in payload and no textbox content")
                self.logger.warning(f"_render_footers_bottom_to_top: Block {block_idx}: No lines in payload and no textbox content")
                continue
            
            # If has textbox but no lines, we need to render textbox paragraphs
            # Textbox paragraphs should be rendered using absolute positioning
            if has_textbox and not lines:
                self.logger.debug(f"Block {block_idx}: Has textbox content but no lines - rendering textbox paragraphs")
                self.logger.info(f"_render_footers_bottom_to_top: Block {block_idx}: Has textbox content, rendering textbox")
                
                # Render textbox paragraphs
                for textbox_para in textbox_paragraphs:
                    # Create a block-like structure for textbox paragraph
                    # Use block frame position for textbox rendering
                    textbox_block = LayoutBlock(
                        frame=block.frame,
                        content=textbox_para if hasattr(textbox_para, "__dict__") else {"lines": []},
                        style=block.style,
                        block_type="textbox"
                    )
                    # Render using _render_block_direct which will handle textbox
                    self._render_block_direct(pdf_page, textbox_block, page)
                continue
            
            # Also check for image blocks in footer
            # Check if block content contains image information
            is_image = (
                block.block_type == "image" or
                (isinstance(block.content, dict) and block.content.get("type") == "image") or
                (hasattr(block.content, "__class__") and Image is not None and isinstance(block.content, Image))
            )
            
            if is_image:
                self.logger.debug(f"Block {block_idx}: Rendering as IMAGE in footer")
                self.logger.info(f"_render_footers_bottom_to_top: Block {block_idx}: Rendering as IMAGE")
                # Render image using _render_block_direct which handles images
                self._render_block_direct(pdf_page, block, page)
                continue
            
            if not lines:
                continue
            
            self.logger.debug(f"Block {block_idx}: Found {len(lines)} lines")
            self.logger.info(f"_render_footers_bottom_to_top: Block {block_idx}: Found {len(lines)} lines")
            
            style = block.style or {}
            pad_top, pad_right, pad_bottom, pad_left = resolve_padding(style)
            
            # Calculate block dimensions
            block_height = block.frame.height if hasattr(block.frame, "height") else 0.0
            block_width = block.frame.width if hasattr(block.frame, "width") else page_width
            block_y_bottom = block.frame.y if hasattr(block.frame, "y") else bottom_margin
            block_y_top = block_y_bottom + block_height  # Top edge of block (in PDF coordinates)
            
            self.logger.debug(f"Block {block_idx}: y_bottom={block_y_bottom:.2f}, y_top={block_y_top:.2f}, height={block_height:.2f}, page_height={page_height:.2f}")
            self.logger.info(
                f"_render_footers_bottom_to_top: Block {block_idx}: "
                f"y_bottom={block_y_bottom}, y_top={block_y_top}, height={block_height}, "
                f"width={block_width}, page_height={page_height}"
            )
            
            # Check if block is within visible area
            if block_y_top < 0 or block_y_bottom > page_height:
                self.logger.warning(
                    f"_render_footers_bottom_to_top: Block {block_idx} is OUTSIDE page bounds! "
                    f"y_bottom={block_y_bottom:.2f}, y_top={block_y_top:.2f}, page_height={page_height:.2f}"
                )
            else:
                self.logger.debug(f"Block {block_idx} is within page bounds (y_bottom={block_y_bottom:.2f}, y_top={block_y_top:.2f})")
                self.logger.info(
                    f"_render_footers_bottom_to_top: Block {block_idx} is within page bounds "
                    f"(y_bottom={block_y_bottom}, y_top={block_y_top}, page_height={page_height})"
                )
            
            x_origin = left_margin
            
            # Render background first
            self._render_block_background(pdf_page, block, style)
            
            # Get alignment
            alignment = style.get("justification") or style.get("alignment") or "left"
            if alignment in {"both", "distribute"}:
                alignment = "justify"
            elif alignment in {"end"}:
                alignment = "right"
            elif alignment in {"start"}:
                alignment = "left"
            
            # Calculate content width
            content_width = block_width - pad_left - pad_right
            
            # Get line spacing and font info
            line_spacing = float(payload.get("line_spacing", 1.0) or 1.0)
            # Get font size from style - DOCX may store in half-points
        font_size_raw = style.get("font_size")
        if font_size_raw is None:
            font_size = 11.0  # Default fallback
        else:
            font_size = float(font_size_raw) if font_size_raw else 11.0
            # DOCX commonly stores font size in half-points (e.g., 18 for 9pt)
            # Normalize: if > 15 and integer, it's likely half-points
            if font_size > 15 and float(font_size).is_integer():
                font_size = font_size / 2.0
            
            # Get font path
            font_path = style.get("font_path")
            if isinstance(font_path, dict):
                font_path = font_path.get("path")
            
            # Render lines from bottom to top within the block
            # block_y_bottom is the bottom edge of the block (from layout engine)
            # block_y_top is the top edge of the block
            # We'll render lines from bottom to top within the block
            # Start from top of content area and move downward (decrease Y) for each line
            y_cursor = block_y_top - pad_top  # Top of content area (in PDF coordinates)
            
            self.logger.debug(
                f"_render_footers_bottom_to_top: Block {block_idx}: Starting y_cursor={y_cursor}, "
                f"block_y_top={block_y_top}, pad_top={pad_top}"
            )
            
            # Render lines in normal order (top to bottom within block)
            # Layout engine provides lines in correct order (top to bottom)
            for line_idx, line_entry in enumerate(lines):
                text = str(line_entry.get("text") or "")
                text_original = text  # Keep original for debugging
                
                self.logger.debug(f"Block {block_idx}, line {line_idx}: Raw text='{text[:50]}', length={len(text)}")
                
                # Check if text is empty after normalization
                if not text or not text.strip():
                    self.logger.debug(f"Block {block_idx}, line {line_idx}: Empty or whitespace-only text (original='{text_original[:50]}'), skipping rendering but accounting for height")
                    # Still need to account for line height
                    layout = line_entry.get("layout")
                    line_height = font_size * 1.2 * line_spacing
                    if layout and hasattr(layout, "height"):
                        line_height = layout.height
                    y_cursor -= line_height
                    continue
                
                # Normalize text
                import unicodedata
                text = unicodedata.normalize("NFC", text)
                
                # Get line layout
                layout = line_entry.get("layout")
                line_height = font_size * 1.2 * line_spacing  # Default line height
                line_ascent = font_size * 0.8  # Default ascent
                
                if layout:
                    line_height = layout.height if hasattr(layout, "height") else line_height
                    line_ascent = layout.ascent if hasattr(layout, "ascent") else line_ascent
                
                # Calculate baseline (in PDF coordinates, baseline is below text top)
                # y_cursor is top of line area, baseline should be below it
                baseline = y_cursor - line_ascent
                
                self.logger.debug(f"Block {block_idx}, line {line_idx}: text='{text[:50]}', y_cursor={y_cursor:.2f}, baseline={baseline:.2f}, line_height={line_height:.2f}, font_size={font_size:.2f}")
                self.logger.info(
                    f"_render_footers_bottom_to_top: Block {block_idx}, line {line_idx}: "
                    f"text='{text[:50]}', y_cursor={y_cursor}, baseline={baseline}, "
                    f"line_height={line_height}, line_ascent={line_ascent}, font_size={font_size}"
                )
                
                # Calculate X position based on alignment
                line_width = layout.width if layout and hasattr(layout, "width") else None
                x_start = x_origin + pad_left
                
                # Calculate word spacing for justified text
                word_spacing = 0.0
                if alignment == "justify" and line_width is not None and content_width > 0 and line_width > 0:
                    # Count spaces in text (excluding trailing spaces)
                    space_count = len([c for c in text.rstrip() if c.isspace()])
                    if space_count > 0:
                        # Distribute extra space between words
                        remaining_space = content_width - line_width
                        word_spacing = remaining_space / space_count if space_count > 0 else 0.0
                        # Only apply word spacing if there's actual space to distribute
                        if word_spacing < 0:
                            word_spacing = 0.0
                
                if line_width is not None and content_width > 0:
                    if alignment == "center":
                        remaining_space = max(0, content_width - line_width)
                        x_start = x_origin + pad_left + remaining_space / 2.0
                    elif alignment == "right":
                        remaining_space = max(0, content_width - line_width)
                        x_start = x_origin + pad_left + remaining_space
                    elif alignment == "justify":
                        x_start = x_origin + pad_left
                    else:
                        x_start = x_origin + pad_left
                
                self.logger.debug(f"Block {block_idx}, line {line_idx}: Rendering at x={x_start:.2f}, y={baseline:.2f}, text='{text[:30]}'")
                self.logger.info(
                    f"_render_footers_bottom_to_top: Block {block_idx}, line {line_idx}: "
                    f"Rendering at x={x_start}, y={baseline}, text='{text[:30]}'"
                )
                
                # REQUIRED: font_path must be resolved from DOCX (already done above)
                if not isinstance(font_path, str):
                    raise ValueError(f"Font path is required but not resolved from DOCX paragraph style")
                
                # Render text
                self.direct_writer.add_text(
                    pdf_page, x_start, baseline, text, font_size, font_path,
                    word_spacing=word_spacing if alignment == "justify" else 0.0,
                )
                
                # Move cursor down (decrease Y in PDF coordinates) for next line
                y_cursor -= line_height

    # ===================================================================
    # Type-based rendering methods (using model classes)
    # ===================================================================
    
    def _render_table_element(self, pdf_page: Any, table: Table, block: LayoutBlock, page: LayoutPage) -> None:
        """Render a Table element object using its class structure."""
        self.logger.debug(f"Rendering Table element with {len(table.rows)} rows")
        
        # Extract rows directly from table object
        rows = table.rows if hasattr(table, "rows") else []
        if not rows:
            self.logger.warning("Table has no rows")
            return
        
        # Extract grid from table properties
        grid = []
        if hasattr(table, "properties") and table.properties:
            if hasattr(table.properties, "grid"):
                grid = table.properties.grid or []
        
        # Get style from block or table
        style = block.style or {}
        if hasattr(table, "style") and table.style:
            style = dict(style)
            style.update(table.style)
        
        # Delegate to existing table rendering logic, but pass table object
        # We'll adapt the existing _render_table_direct to work with table object
        self._render_table_from_object(pdf_page, table, rows, grid, block, page, style)
    
    def _render_table_from_object(
        self, pdf_page: Any, table: Table, rows: list, grid: list, 
        block: LayoutBlock, page: Optional[LayoutPage], style: Dict[str, Any]
    ) -> None:
        """Render table using table object structure."""
        # This method contains the table rendering logic, adapted for Table objects
        # It's similar to _render_table_direct but works with Table objects directly
        
        max_cols = max(len(getattr(row, "cells", [])) for row in rows) if rows else 0
        
        col_widths = []
        total_grid_width = 0.0
        
        if grid:
            from docx_interpreter.engine.geometry import twips_to_points
            for entry in grid[:max_cols]:
                width = entry.get("width") if isinstance(entry, dict) else getattr(entry, "width", None)
                if width:
                    try:
                        numeric = float(width)
                        numeric_pts = twips_to_points(numeric)
                        col_widths.append(numeric_pts)
                        total_grid_width += numeric_pts
                    except (TypeError, ValueError):
                        pass
                else:
                    break
        
        # Render table directly using table object
        self._render_table_direct(pdf_page, block, page, table_object=table)
    
    def _render_table_cell_element(
        self, pdf_page: Any, cell: TableCell, cell_x: float, cell_y_top: float, 
        width: float, height: float
    ) -> None:
        """Render a TableCell element object using its class structure.
        
        TableCell inherits from Body, so it can contain Paragraph, Table, Image, TextBox, etc.
        We render it like a micro-Body: background/borders first, then render content recursively.
        
        Args:
            pdf_page: PDF page object
            cell: TableCell element object
            cell_x: X position (left edge) of the cell
            cell_y_top: Y position (top edge) of the cell (in PDF coordinates, Y increases upward)
            width: Width of the cell
            height: Height of the cell
        """
        self.logger.debug(f"Rendering TableCell element (micro-Body approach)")
        
        # Get cell style
        cell_style = {}
        if hasattr(cell, "style") and cell.style:
            cell_style = dict(cell.style)
        if hasattr(cell, "cell_borders"):
            cell_style.setdefault("borders", cell.cell_borders)
        if hasattr(cell, "shading"):
            cell_style.setdefault("shading", cell.shading)
        
        # Create a temporary block for rendering background and borders
        cell_frame = Rect(x=cell_x, y=cell_y_top - height, width=width, height=height)
        cell_block = LayoutBlock(frame=cell_frame, content={}, style=cell_style, block_type="table_cell")
        
        # STEP 1: Render cell background and borders
        # Note: cell_block.frame.y is already in PDF coordinates (cell_y_top - height)
        # So we pass page=None to skip conversion (coordinates already in PDF format)
        self._render_cell_background_and_borders(pdf_page, cell, cell_block, page=None)
        
        # STEP 2: Get cell content - TableCell inherits from Body, so can contain various elements
        cell_content = self._get_cell_content(cell)
        
        if not cell_content:
            self.logger.debug("TableCell has no content")
            return
        
        # STEP 3: Calculate content area (accounting for cell margins)
        cell_margins = getattr(cell, "cell_margins", {}) or {}
        margin_top = self._get_margin_value(cell_margins.get("top", 0))
        margin_right = self._get_margin_value(cell_margins.get("right", 0))
        margin_bottom = self._get_margin_value(cell_margins.get("bottom", 0))
        margin_left = self._get_margin_value(cell_margins.get("left", 0))
        
        # Content area dimensions
        # In PDF coordinates: Y increases upward, cell_y_top is top edge of cell
        content_x = cell_x + margin_left
        content_width = width - margin_left - margin_right
        content_height = height - margin_top - margin_bottom
        # Top of content area = cell top - margin_top (subtract margin, go down)
        content_area_top = cell_y_top - margin_top  # Top of content area (PDF coordinates)
        # Bottom of content area = cell top - cell height + margin_bottom
        content_area_bottom = cell_y_top - height + margin_bottom  # Bottom of content area
        
        # STEP 4: Calculate vertical alignment offset
        # First, calculate total content height
        total_content_height = self._calculate_cell_content_total_height(cell_content, content_width)
        
        # Get vertical alignment
        vertical_align = (
            getattr(cell, "vertical_align", None) or
            cell_style.get("vAlign") or
            cell_style.get("vertical_alignment") or
            "top"
        )
        
        # Calculate starting Y position based on vertical alignment
        if vertical_align in {"center", "middle"}:
            remaining_space = max(0, content_height - total_content_height)
            vertical_offset = remaining_space / 2.0
            content_start_y = content_area_top - vertical_offset
        elif vertical_align == "bottom":
            content_start_y = content_area_bottom + total_content_height
        else:  # top (default)
            content_start_y = content_area_top
        
        # STEP 5: Render cell content recursively (like Body)
        # Each element in cell.content becomes a LayoutBlock and is rendered using _render_block_direct
        y_cursor = content_start_y
        
        for item in cell_content:
            # Calculate item height (simplified - could be improved)
            item_height = self._estimate_element_height(item, content_width)
            
            # Create LayoutBlock for this item
            item_frame = Rect(
                x=content_x,
                y=y_cursor - item_height,
                width=content_width,
                height=item_height
            )
            
            # Detect item type and create appropriate block
            item_block_type = self._detect_block_type_from_element(item)
            
            # Get item style if available
            item_style = {}
            if hasattr(item, "style") and item.style:
                item_style = dict(item.style)
            
            item_block = LayoutBlock(
                frame=item_frame,
                content=item if hasattr(item, "__class__") else {"object": item},
                style=item_style,
                block_type=item_block_type
            )
            
            # Render item recursively using the same dispatch system
            # This will call _render_table_element, _render_paragraph_element, etc.
            # Pass None as page since we're rendering within a cell (not a full page)
            self._render_block_direct(pdf_page, item_block, page=None)
            
            # Move cursor down for next item
            y_cursor -= item_height
    
    def _get_cell_content(self, cell: TableCell) -> list:
        """Get content from TableCell (which inherits from Body) or processed_cell dict.
        
        IMPORTANT: Use only "content" field from processed_cell to avoid duplicates.
        Do NOT use "paragraphs" field if "content" is available, as "paragraphs" is
        extracted from "content" for backward compatibility only.
        
        Args:
            cell: TableCell object or processed_cell dict from table_engine
        """
        content = []
        
        # First check if cell is a dict (processed_cell from table_engine)
        if isinstance(cell, dict):
            # processed_cell dict - use "content" field directly
            if "content" in cell and cell["content"]:
                content_list = cell["content"]
                if isinstance(content_list, list):
                    content = content_list
                    # If content is available, don't check paragraphs (to avoid duplicates)
                    return content
            # Fallback to "elements" if "content" is not available
            elif "elements" in cell and cell["elements"]:
                elements_list = cell["elements"]
                if isinstance(elements_list, list):
                    content = elements_list
                    return content
            # Last resort: check "paragraphs" (but only if content/elements not available)
            elif "paragraphs" in cell and cell["paragraphs"]:
                paragraphs = cell["paragraphs"]
                if isinstance(paragraphs, list):
                    content = paragraphs
            return content
        
        # Try different accessors for cell content (TableCell object)
        # Priority: content > elements > get_paragraphs > children > paragraphs
        # This ensures we use the main "content" field first, avoiding duplicates
        if hasattr(cell, "content") and cell.content:
            content_list = cell.content
            if isinstance(content_list, list):
                content = content_list
                # If content is available, don't check paragraphs (to avoid duplicates)
                return content
        elif hasattr(cell, "elements") and cell.elements:
            # Check "elements" alias if "content" is not available
            elements_list = cell.elements
            if isinstance(elements_list, list):
                content = elements_list
                # If elements is available, don't check paragraphs (to avoid duplicates)
                return content
        elif hasattr(cell, "get_paragraphs"):
            # Body method - get all paragraphs
            paragraphs = cell.get_paragraphs()
            if paragraphs:
                content = list(paragraphs)
        elif hasattr(cell, "children"):
            # Models base class - get all children
            children = getattr(cell, "children", [])
            if children:
                content = list(children)
        elif hasattr(cell, "paragraphs"):
            # Only check paragraphs if content/elements are not available (to avoid duplicates)
            paragraphs = cell.paragraphs
            if isinstance(paragraphs, list):
                content = paragraphs
        
        return content
    
    def _render_cell_background_and_borders(self, pdf_page: Any, cell: TableCell, block: LayoutBlock, page: Optional[LayoutPage] = None) -> None:
        """Render cell background and borders.
        
        Note: block.frame.y is in layout coordinates (top-down), but cells are rendered
        within tables which already use PDF coordinates. However, if this method is called
        directly with a block from layout engine, we need to convert coordinates.
        """
        # Render cell background
        fill_color = self._extract_fill_color(block.style)
        if fill_color:
            # Convert from layout coordinates to PDF coordinates if needed
            # Note: In table context, cells are already in PDF coordinates, but this method
            # may be called with layout blocks, so we check if conversion is needed
            # For now, assume block.frame.y is already in PDF coordinates if it's within reasonable bounds
            # Otherwise, convert from layout coordinates
            page_height = page.size.height if page and hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
            # Check if y is already in PDF coordinates (should be < page_height)
            # Layout coordinates would be > page_height typically
            if block.frame.y > page_height:
                # Likely layout coordinates - convert
                cell_y_bottom = self._convert_layout_y_to_pdf(block.frame.y, block.frame.height, page)
            else:
                # Already in PDF coordinates
                cell_y_bottom = block.frame.y
            
            self.direct_writer.add_rect(
                pdf_page, block.frame.x, cell_y_bottom, block.frame.width, block.frame.height,
                fill_color=fill_color, stroke_color=None, stroke_width=0
            )
        
        # Render cell borders
        borders = getattr(cell, "cell_borders", None) or block.style.get("borders", {})
        if borders:
            # Same conversion logic as above
            page_height = page.size.height if page and hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
            if block.frame.y > page_height:
                cell_y_bottom = self._convert_layout_y_to_pdf(block.frame.y, block.frame.height, page)
            else:
                cell_y_bottom = block.frame.y
            self._render_cell_borders(pdf_page, cell, block.frame.x, cell_y_bottom, block.frame.width, block.frame.height, borders)
    
    def _calculate_cell_content_total_height(self, cell_content: list, content_width: float) -> float:
        """Calculate total height of all cell content items."""
        total_height = 0.0
        
        for item in cell_content:
            item_height = self._estimate_element_height(item, content_width)
            total_height += item_height
        
        return total_height
    
    def _estimate_element_height(self, element: Any, available_width: float) -> float:
        """Estimate height of an element (Paragraph, Table, Image, etc.)."""
        # If element has layout information, use it
        if hasattr(element, "content") and isinstance(element.content, dict):
            # Check if it's a paragraph with lines
            lines = element.content.get("lines", [])
            if lines:
                para_style = getattr(element, "style", {}) or {}
                line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                element_height = 0.0
                for line_entry in lines:
                    layout = line_entry.get("layout")
                    if layout and hasattr(layout, "height"):
                        element_height += layout.height * line_spacing
                if element_height > 0:
                    return element_height
        
        # If element is a Paragraph, estimate from text
        if Paragraph is not None and isinstance(element, Paragraph):
            if hasattr(element, "runs") and element.runs:
                # Estimate from runs
                total_text = "".join(run.text for run in element.runs if hasattr(run, "text"))
                para_style = getattr(element, "style", {}) or {}
                font_size = float(para_style.get("font_size", 11.0) or 11.0)
                line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                char_width = font_size * 0.6
                chars_per_line = available_width / char_width if char_width > 0 else 50
                estimated_lines = max(1, len(total_text) / chars_per_line if chars_per_line > 0 else 1)
                return estimated_lines * font_size * 1.2 * line_spacing
        
        # Default: estimate from font size
        element_style = getattr(element, "style", {}) or {}
        font_size = float(element_style.get("font_size", 11.0) or 11.0)
        return font_size * 1.5  # Default line height
    
    def _render_paragraph_element(self, pdf_page: Any, paragraph: Paragraph, block: LayoutBlock, page: Optional[LayoutPage]) -> None:
        """Render a Paragraph element object using its class structure.
        
        This method prioritizes rendering from paragraph.runs directly for better fidelity.
        Falls back to layout-based rendering if layout information is available.
        """
        self.logger.debug(f"Rendering Paragraph element with {len(paragraph.runs)} runs")
        
        # Check if block.content has the layout information we need
        payload = block.content if isinstance(block.content, dict) else None
        if payload and payload.get("lines"):
            # Use existing paragraph rendering logic (with layout information)
            self._render_paragraph_from_layout(pdf_page, paragraph, block, page)
        else:
            # Render from paragraph.runs directly (implemented)
            self._render_paragraph_from_runs(pdf_page, paragraph, block, page)
    
    def _render_paragraph_from_layout(
        self, pdf_page: Any, paragraph: Paragraph, block: LayoutBlock, page: Optional[LayoutPage]
    ) -> None:
        """Render paragraph using layout information from block.content.
        
        This method uses the layout information computed by ParagraphEngine,
        which includes line breaks, glyph positions, and run information.
        """
        payload = block.content if isinstance(block.content, dict) else None
        if not payload:
            self.logger.warning("Paragraph block has no payload")
            return

        lines = payload.get("lines")
        if not lines:
            self.logger.debug("Paragraph block has no lines")
            return
        
        # Extract paragraph style from block or paragraph object
        style = block.style or {}
        if hasattr(paragraph, "style") and paragraph.style:
            style = dict(style)
            style.update(paragraph.style)
        
        # Calculate padding and positioning
        # Convert from layout coordinates to PDF coordinates
        pad_top, _, _, pad_left = resolve_padding(style)
        pdf_y_bottom = self._convert_layout_y_to_pdf(block.frame.y, block.frame.height, page)
        pdf_y_top = pdf_y_bottom + block.frame.height
        block_top = pdf_y_top - pad_top
        line_spacing = float(payload.get("line_spacing", 1.0) or 1.0)
        # Get font size from style - DOCX may store in half-points
        font_size_raw = style.get("font_size")
        if font_size_raw is None:
            font_size = 11.0  # Default fallback
        else:
            font_size = float(font_size_raw) if font_size_raw else 11.0
            # DOCX commonly stores font size in half-points (e.g., 18 for 9pt)
            # Normalize: if > 15 and integer, it's likely half-points
            if font_size > 15 and float(font_size).is_integer():
                font_size = font_size / 2.0
        x_origin = block.frame.x + pad_left

        font_path = style.get("font_path")
        if isinstance(font_path, dict):
            font_path = font_path.get("path")

        assert self.direct_writer is not None

        # Render background and borders first
        self._render_block_background(pdf_page, block, style)

        # Get alignment from style
        alignment = style.get("justification") or style.get("alignment") or "left"
        
        # Normalize alignment values from DOCX format to PDF format
        if alignment in {"both", "distribute"}:
            alignment = "justify"
        elif alignment in {"end"}:
            alignment = "right"
        elif alignment in {"start"}:
            alignment = "left"
        
        # Calculate content width (frame width minus padding)
        pad_right = resolve_padding(style)[1] if isinstance(style, dict) else 0
        content_width = block.frame.width - pad_left - pad_right

        # Render numbering marker if present (before first line)
        marker_info = payload.get("marker")
        if marker_info and lines:
            self._render_numbering_marker(
                pdf_page, marker_info, block_top, line_spacing, font_size, font_path, block
            )

        # Render each line
        for line_idx, entry in enumerate(lines):
            text = str(entry.get("text") or "")
            if not text:
                # Still need to update block_top for empty lines to maintain spacing
                line_layout = entry.get("layout") if isinstance(entry, dict) else None
                line_height = None
                if line_layout and hasattr(line_layout, "height"):
                    try:
                        line_height = float(getattr(line_layout, "height"))
                    except Exception as e:
                        self.logger.debug(f"Error extracting line height: {e}", exc_info=True)
                
                # Update block_top even for empty lines
                if isinstance(line_height, float) and line_height > 0:
                    min_line_height = font_size * 0.8
                    effective_line_height = max(line_height, min_line_height)
                    block_top = block_top - effective_line_height
                elif line_spacing > 1.0:
                    block_top = block_top - font_size * line_spacing
                continue
            
            # Normalize text to NFC (composed form) for consistent encoding
            import unicodedata
            text = unicodedata.normalize("NFC", text)
            
            line_layout = entry.get("layout") if isinstance(entry, dict) else None
            ascent = None
            line_height = None
            layout_baseline = None
            
            if line_layout:
                try:
                    if hasattr(line_layout, "ascent"):
                        ascent = float(getattr(line_layout, "ascent"))
                    if hasattr(line_layout, "height"):
                        line_height = float(getattr(line_layout, "height"))
                    if hasattr(line_layout, "baseline"):
                        layout_baseline = float(getattr(line_layout, "baseline"))
                except Exception as e:
                    self.logger.debug(f"Error extracting line layout metrics: {e}", exc_info=True)
            
            # Calculate baseline for this line - use layout metrics relative to current block_top
            if isinstance(ascent, float):
                baseline = block_top - ascent
            elif isinstance(layout_baseline, float):
                baseline = block_top - layout_baseline
            else:
                # Fallback: use offset_baseline (cumulative from block start)
                offset_baseline = float(entry.get("offset_baseline", 0.0) or 0.0)
                # For line_idx > 0, offset_baseline is cumulative, so use current block_top
                # Calculate baseline from current block_top minus line's relative baseline
                if line_idx == 0:
                    baseline = block_top - offset_baseline * line_spacing
                else:
                    # Use layout baseline or default ascent for subsequent lines
                    default_ascent = font_size * 0.8
                    baseline = block_top - default_ascent
            
            # Get line width from layout
            layout = entry.get("layout")
            line_width = layout.width if layout and hasattr(layout, "width") else None
            
            # Calculate X position based on alignment
            x_start = self._calculate_line_x_position(
                alignment, x_origin, line_width, content_width
            )
            
            # Render runs with proper styling
            runs = entry.get("runs", [])
            layout_has_glyphs = layout and hasattr(layout, "glyphs") and layout.glyphs and len(layout.glyphs) > 0
            
            # Check if runs have different styles
            has_different_styles = self._runs_have_different_styles(runs)
            
            if layout_has_glyphs or (runs and has_different_styles):
                # Use glyph positions or render runs separately
                self._render_line_with_glyphs_or_runs(
                    pdf_page, entry, x_start, baseline, font_size, font_path, 
                    layout, runs, alignment, content_width, text
                )
            else:
                # Single run or same style - draw entire line as one piece
                # REQUIRED: font_path must be resolved from DOCX (already done above)
                if not isinstance(font_path, str):
                    raise ValueError(f"Font path is required but not resolved from DOCX paragraph style")
                
                self.direct_writer.add_text(
                    pdf_page,
                    x_start,
                    baseline,
                    text,
                    font_size,
                    font_path,
                )
            
            # Render hyperlink if present
            hyperlink = self._extract_hyperlink(style)
            if hyperlink:
                width = line_width if line_width else block.frame.width
                height = font_size * 1.2
                self.direct_writer.add_link(
                    pdf_page,
                    x_start,
                    baseline,
                    x_start + width,
                    baseline + height,
                    hyperlink,
                )
            
            # Update block_top for next line using layout height if available
            # IMPORTANT: Always move block_top down by line_height to prevent text from collapsing
            block_top_before = block_top
            if isinstance(line_height, float) and line_height > 0:
                # Use line_height directly: next line starts line_height below current block_top
                # Ensure minimum line_height to prevent text from collapsing (at least 80% of font_size)
                min_line_height = font_size * 0.8
                effective_line_height = max(line_height, min_line_height)
                block_top = block_top - effective_line_height
                
                if effective_line_height != line_height and line_idx < 3:
                    self.logger.warning(
                        f"⚠️ Line {line_idx}: line_height too small ({line_height:.2f}), "
                        f"using minimum ({effective_line_height:.2f}) to prevent collapse"
                    )
            elif isinstance(ascent, float):
                # Fallback: use font_size with line_spacing, accounting for ascent
                # Move down by font_size * line_spacing (not just to baseline)
                line_delta = font_size * line_spacing
                block_top = block_top - line_delta
                if line_idx < 5:  # Log only first few lines to avoid spam
                    self.logger.warning(
                        f"⚠️ Line {line_idx}: Using ascent fallback (no line_height) - "
                        f"block_top: {block_top_before:.2f} -> {block_top:.2f} "
                        f"(font_size={font_size:.2f}, line_spacing={line_spacing:.2f})"
                    )
            else:
                # Last resort: use default line height with line spacing
                default_line_height = font_size * 1.2 * line_spacing
                block_top = block_top - default_line_height
                if line_idx < 5:  # Log only first few lines to avoid spam
                    self.logger.warning(
                        f"⚠️ Line {line_idx}: Using default fallback (no line_height/ascent) - "
                        f"block_top: {block_top_before:.2f} -> {block_top:.2f} "
                        f"(default_line_height={default_line_height:.2f})"
                    )
    
    def _render_numbering_marker(
        self, pdf_page: Any, marker_info: Dict[str, Any], 
        block_top: float, line_spacing: float, default_font_size: float, 
        default_font_path: Optional[str], block: LayoutBlock
    ) -> None:
        """Render numbering marker (e.g., "1.", "a)", "•") before paragraph text.
        
        Args:
            pdf_page: PDF page object
            marker_info: Marker information dict with:
                - text: Marker text (e.g., "1.", "a)", "•")
                - style: Font style dict for marker
                - x: X position for marker
                - baseline_offset: Baseline offset for first line
            block_top: Top Y position of paragraph block
            line_spacing: Line spacing multiplier
            default_font_size: Default font size to use if marker style doesn't specify
            default_font_path: Default font path to use if marker style doesn't specify
        """
        marker_text = marker_info.get("text", "")
        if not marker_text:
            return
        
        # Get marker position
        marker_x = marker_info.get("x", block.frame.x)
        baseline_offset = marker_info.get("baseline_offset", 0.0)
        
        # Calculate marker baseline position (same as first line)
        marker_baseline = block_top - baseline_offset * line_spacing
        
        # Get marker style
        marker_style = marker_info.get("style", {}) or {}
        
        # Get font size - priority: marker style > default
        marker_font_size = float(
            marker_style.get("font_size") or 
            marker_style.get("fontSize") or 
            default_font_size
        )
        
        # Get font path - try to resolve from marker style
        marker_font_path = None
        if marker_style.get("font_path"):
            marker_font_path = marker_style["font_path"]
            if isinstance(marker_font_path, dict):
                marker_font_path = marker_font_path.get("path")
        elif marker_style.get("font_name") or marker_style.get("fontName"):
            # Try to resolve font from font name
            font_name = marker_style.get("font_name") or marker_style.get("fontName")
            bold = bool(marker_style.get("bold") or marker_style.get("b"))
            italic = bool(marker_style.get("italic") or marker_style.get("i"))
            try:
                from docx_interpreter.engine.font_resolver import resolve_font_path
                resolved = resolve_font_path(font_name, bold=bold, italic=italic)
                if resolved:
                    _, marker_font_path = resolved
            except Exception as e:
                self.logger.debug(f"Failed to resolve marker font '{font_name}': {e}")
        
        # Fallback to default font path if marker style doesn't specify one
        if not marker_font_path:
            marker_font_path = default_font_path
        
        # Normalize marker text (NFC)
        import unicodedata
        marker_text = unicodedata.normalize("NFC", marker_text)
        
        # Render marker text
        assert self.direct_writer is not None
        self.direct_writer.add_text(
            pdf_page,
            marker_x,
            marker_baseline,
            marker_text,
            marker_font_size,
            marker_font_path if isinstance(marker_font_path, str) else None,
        )
        
        self.logger.debug(
            f"Rendered numbering marker '{marker_text}' at x={marker_x:.2f}, "
            f"baseline={marker_baseline:.2f}, font_size={marker_font_size:.2f}"
        )
    
    def _render_paragraph_from_runs(
        self, pdf_page: Any, paragraph: Paragraph, block: LayoutBlock, page: Optional[LayoutPage]
    ) -> None:
        """Render paragraph directly from paragraph.runs (fallback method).
        
        This method is used when layout information is not available.
        It performs basic text rendering from paragraph.runs without line breaking.
        """
        self.logger.debug("Rendering paragraph from runs (no layout info available)")
        
        if not paragraph.runs:
            self.logger.debug("Paragraph has no runs")
            return
        
        # Get paragraph style
        style = block.style or {}
        if hasattr(paragraph, "style") and paragraph.style:
            style = dict(style)
            style.update(paragraph.style)
        
        # Calculate positioning
        pad_top, _, _, pad_left = resolve_padding(style)
        block_top = block.frame.y + block.frame.height - pad_top
        # Get font size from style - DOCX may store in half-points
        font_size_raw = style.get("font_size")
        if font_size_raw is None:
            font_size = 11.0  # Default fallback
        else:
            font_size = float(font_size_raw) if font_size_raw else 11.0
            # DOCX commonly stores font size in half-points (e.g., 18 for 9pt)
            # Normalize: if > 15 and integer, it's likely half-points
            if font_size > 15 and float(font_size).is_integer():
                font_size = font_size / 2.0
        x_origin = block.frame.x + pad_left
        
        # Render background
        self._render_block_background(pdf_page, block, style)
        
        # Get alignment
        alignment = style.get("justification") or style.get("alignment") or "left"
        if alignment in {"both", "distribute"}:
            alignment = "justify"
        elif alignment in {"end"}:
            alignment = "right"
        elif alignment in {"start"}:
            alignment = "left"
        
        # Render runs sequentially
        x_cursor = x_origin
        y_cursor = block_top
        
        for run in paragraph.runs:
            if not hasattr(run, "text") or not run.text:
                continue
            
            # Normalize text
            import unicodedata
            run_text = unicodedata.normalize("NFC", run.text)
            
            # Get run style
            run_style = {}
            if hasattr(run, "style") and run.style:
                run_style = dict(run.style)
            
            # Get font size from run style, using paragraph font_size as fallback
            run_font_size_raw = run_style.get("font_size")
            if run_font_size_raw is None:
                run_font_size = font_size
            else:
                run_font_size = float(run_font_size_raw) if run_font_size_raw else font_size
                # DOCX commonly stores font size in half-points (e.g., 18 for 9pt)
                # Normalize: if > 15 and integer, it's likely half-points
                if run_font_size > 15 and float(run_font_size).is_integer():
                    run_font_size = run_font_size / 2.0
            
            # REQUIRED: font_path must come from DOCX document
            run_font_path = run_style.get("font_path")
            if isinstance(run_font_path, dict):
                run_font_path = run_font_path.get("path")
            
            # If font_path is not available, try to resolve from font_name
            if not isinstance(run_font_path, str):
                # Try to resolve font name
                font_name = (
                    run_style.get("font_hAnsi") or 
                    run_style.get("font_ascii") or 
                    run_style.get("font_name") or
                    run_style.get("font_pdf_name")
                )
                if font_name:
                    from docx_interpreter.engine.font_resolver import resolve_font_path
                    bold = bool(run_style.get("bold") or run_style.get("font_weight") == "bold")
                    italic = bool(run_style.get("italic") or run_style.get("font_style") == "italic")
                    resolved = resolve_font_path(str(font_name), bold=bold, italic=italic)
                    if resolved:
                        _, run_font_path = resolved
                    else:
                        self.logger.error(
                            f"Failed to resolve font_path for font_name={font_name!r} "
                            f"from DOCX run. Font must be available in system or embedded."
                        )
                        raise ValueError(f"Font path not found for font: {font_name}")
                else:
                    # Last resort: use paragraph font_path or resolve from paragraph font_name
                    paragraph_font_path = style.get("font_path")
                    if isinstance(paragraph_font_path, dict):
                        paragraph_font_path = paragraph_font_path.get("path")
                    
                    if not isinstance(paragraph_font_path, str):
                        # Try to resolve from paragraph font_name
                        paragraph_font_name = style.get("font_name") or style.get("font_pdf_name")
                        if paragraph_font_name:
                            from docx_interpreter.engine.font_resolver import resolve_font_path
                            paragraph_bold = bool(style.get("bold") or style.get("font_weight") == "bold")
                            paragraph_italic = bool(style.get("italic") or style.get("font_style") == "italic")
                            resolved = resolve_font_path(str(paragraph_font_name), bold=paragraph_bold, italic=paragraph_italic)
                            if resolved:
                                _, paragraph_font_path = resolved
                    
                    if isinstance(paragraph_font_path, str):
                        self.logger.warning(
                            f"Run missing font_path and font_name, using paragraph font_path: {paragraph_font_path}"
                        )
                        run_font_path = paragraph_font_path
                    else:
                        # Try to use default DOCX fonts with alias mapping (prefer Liberation to match LibreOffice)
                        # These are standard DOCX fonts defined in DOCX specification
                        alias_map = {
                            "Calibri": "Liberation Sans",
                            "Calibri Light": "Liberation Sans",
                            "Arial": "Liberation Sans",
                            "Times New Roman": "Liberation Serif",
                            "Cambria": "Liberation Serif",
                            "Tahoma": "Liberation Sans",
                            "Helvetica": "Liberation Sans",
                        }
                        default_fonts = ["Calibri", "Arial", "Times New Roman"]
                        resolved_font = None
                        for default_font in default_fonts:
                            from docx_interpreter.engine.font_resolver import resolve_font_path
                            mapped = alias_map.get(default_font, default_font)
                            resolved = resolve_font_path(mapped)
                            if resolved:
                                _, resolved_font = resolved
                                self.logger.warning(
                                    f"Using DOCX standard default font '{default_font}' (mapped to '{mapped}') as last resort for run. "
                                    f"Run style keys: {list(run_style.keys()) if run_style else 'None'}, "
                                    f"Paragraph style keys: {list(style.keys()) if style else 'None'}"
                                )
                                run_font_path = resolved_font
                                break
                        
                        if not isinstance(run_font_path, str):
                            self.logger.error(
                                f"Font path is required but not available. "
                                f"Run style keys: {list(run_style.keys()) if run_style else 'None'}, "
                                f"Paragraph style keys: {list(style.keys()) if style else 'None'}"
                            )
                            raise ValueError("Font path is required but not available from DOCX run, paragraph, or standard DOCX fonts")
            
            # Calculate baseline: no layout here; approximate with ascent factor
            line_layout = None
            line_ascent = None
            if line_layout and hasattr(line_layout, "ascent"):
                try:
                    line_ascent = float(getattr(line_layout, "ascent"))
                except Exception as e:
                    self.logger.debug(f"Error extracting line ascent: {e}", exc_info=True)
                    line_ascent = None
            ascent = line_ascent if isinstance(line_ascent, float) else (run_font_size * 0.8)
            baseline = y_cursor - ascent
            
            # REQUIRED: run_font_path must be resolved from DOCX (already done above)
            if not isinstance(run_font_path, str):
                raise ValueError(f"Font path is required but not resolved from DOCX run style")
            
            # Render run
            self.direct_writer.add_text(
                pdf_page,
                x_cursor,
                baseline,
                run_text,
                run_font_size,
                run_font_path,
            )
            
            # Advance cursor
            char_width = run_font_size * 0.6
            x_cursor += len(run_text) * char_width
        
        # Render hyperlink if present
        hyperlink = self._extract_hyperlink(style)
        if hyperlink:
            width = x_cursor - x_origin
            height = font_size * 1.2
            self.direct_writer.add_link(
                pdf_page,
                x_origin,
                block_top - font_size * 0.75,
                x_origin + width,
                block_top - font_size * 0.75 + height,
                hyperlink,
            )
    
    # ===================================================================
    # Helper methods for paragraph rendering
    # ===================================================================
    
    def _calculate_line_x_position(
        self, alignment: str, x_origin: float, line_width: Optional[float], content_width: float
    ) -> float:
        """Calculate X position for a line based on alignment."""
        if line_width is None or content_width <= 0 or line_width <= 0:
            return x_origin
        
        if alignment == "center":
            remaining_space = max(0, content_width - line_width)
            return x_origin + remaining_space / 2.0
        elif alignment == "right":
            remaining_space = max(0, content_width - line_width)
            return x_origin + remaining_space
        else:  # left or justify
            return x_origin
    
    def _runs_have_different_styles(self, runs: list) -> bool:
        """Check if runs have different styles that require separate rendering."""
        if not runs or len(runs) <= 1:
            return False
        
        first_run = runs[0]
        first_run_style = first_run.get("style", {}) if isinstance(first_run, dict) else (first_run.style if hasattr(first_run, "style") else {})
        first_font = first_run_style.get("font_name") if isinstance(first_run_style, dict) else None
        first_size = first_run_style.get("font_size") if isinstance(first_run_style, dict) else None
        
        for run_info in runs[1:]:
            run_style = run_info.get("style", {}) if isinstance(run_info, dict) else (run_info.style if hasattr(run_info, "style") else {})
            if (run_style.get("font_name") != first_font or
                run_style.get("font_size") != first_size):
                return True
        
        return False
    
    def _render_line_with_glyphs_or_runs(
        self, pdf_page: Any, entry: dict, x_start: float, baseline: float,
        font_size: float, font_path: Optional[str], layout: Any, runs: list,
        alignment: str, content_width: float, text: str
    ) -> None:
        """Render a line using glyph positions or individual runs."""
        layout_glyphs = layout.glyphs if layout and hasattr(layout, "glyphs") else []
        
        if layout_glyphs and len(layout_glyphs) > 0:
            # Use glyph positions for accurate spacing
            if not runs or len(runs) == 0:
                # Single run - use first glyph X for offset
                if len(layout_glyphs) > 0:
                    first_glyph_x = getattr(layout_glyphs[0], "x", 0.0)
                    adjusted_x = x_start + (first_glyph_x if alignment in ("left", "justify") and first_glyph_x > 0 else 0)
                else:
                    adjusted_x = x_start
                
                # REQUIRED: font_path must be resolved from DOCX (already done above)
                if not isinstance(font_path, str):
                    raise ValueError(f"Font path is required but not resolved from DOCX paragraph style")
                
                self.direct_writer.add_text(
                    pdf_page, adjusted_x, baseline, text, font_size, font_path
                )
            else:
                # Multiple runs - use glyph positions for each run
                glyph_idx = 0
                for run_info in runs:
                    run_text = str(run_info.get("text", "") if isinstance(run_info, dict) else (run_info.text if hasattr(run_info, "text") else ""))
                    if not run_text:
                        continue
                    
                    run_style = run_info.get("style", {}) if isinstance(run_info, dict) else (run_info.style if hasattr(run_info, "style") else {})
                    run_font_size = float(run_style.get("font_size", font_size) if isinstance(run_style, dict) else (run_style.font_size if hasattr(run_style, "font_size") else font_size) or font_size)
                    
                    run_font_path_raw = run_style.get("font_path") if isinstance(run_style, dict) else (run_style.font_path if hasattr(run_style, "font_path") else None)
                    if isinstance(run_font_path_raw, dict):
                        run_font_path = run_font_path_raw.get("path")
                    else:
                        run_font_path = run_font_path_raw if isinstance(run_font_path_raw, str) else font_path
                    
                    # Find glyph position for this run
                    if glyph_idx < len(layout_glyphs):
                        glyph_x = getattr(layout_glyphs[glyph_idx], "x", 0.0)
                        x_cursor = x_start + (glyph_x if alignment in ("left", "justify") and glyph_x > 0 else 0)
                    else:
                        x_cursor = x_start
                    
                    self.direct_writer.add_text(
                        pdf_page, x_cursor, baseline, run_text, run_font_size,
                        run_font_path if isinstance(run_font_path, str) else None
                    )
                    
                    glyph_idx += len(run_text)
        else:
            # Fallback: draw runs sequentially with estimated widths
            x_cursor = x_start
            for run_info in runs:
                run_text = str(run_info.get("text", "") if isinstance(run_info, dict) else (run_info.text if hasattr(run_info, "text") else ""))
                if not run_text:
                    continue
                
                run_style = run_info.get("style", {}) if isinstance(run_info, dict) else (run_info.style if hasattr(run_info, "style") else {})
                run_font_size = float(run_style.get("font_size", font_size) if isinstance(run_style, dict) else (run_style.font_size if hasattr(run_style, "font_size") else font_size) or font_size)
                
                run_font_path_raw = run_style.get("font_path") if isinstance(run_style, dict) else (run_style.font_path if hasattr(run_style, "font_path") else None)
                if isinstance(run_font_path_raw, dict):
                    run_font_path = run_font_path_raw.get("path")
                else:
                    run_font_path = run_font_path_raw if isinstance(run_font_path_raw, str) else font_path
                
                # Estimate width
                run_width = len(run_text) * run_font_size * 0.55
                
                self.direct_writer.add_text(
                    pdf_page, x_cursor, baseline, run_text, run_font_size,
                    run_font_path if isinstance(run_font_path, str) else None
                )
                
                x_cursor += run_width
    
    # ===================================================================
    # Image rendering methods
    # ===================================================================
    
    def _render_image_element(self, pdf_page: Any, image: Image, block: LayoutBlock, page: Optional[LayoutPage]) -> None:
        """Render an Image element object using its class structure."""
        self.logger.debug(f"Rendering Image element (rel_id={image.rel_id}, width={image.width}, height={image.height})")
        
        if not image.rel_id:
            self.logger.warning("Image has no relationship ID, cannot render")
            return
        
        # Calculate image position from block frame
        # Layout engine uses top-down coordinates (Y increases downward)
        # PDF uses bottom-up coordinates (Y increases upward from bottom)
        # block.frame.y is the BOTTOM edge in layout coordinates
        # In PDF, we need to convert: pdf_y = page_height - (layout_y + height)
        x = block.frame.x
        layout_y_bottom = block.frame.y
        layout_height = block.frame.height
        
        # Get page height for coordinate conversion
        page_height = page.size.height if page and hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
        
        # Convert layout Y (bottom edge) to PDF Y (bottom edge)
        # Layout: Y increases downward, frame.y is bottom edge
        # PDF: Y increases upward, y is bottom edge
        # Conversion: pdf_y = page_height - (layout_y_bottom + layout_height)
        # But wait: if layout_y_bottom is already the bottom edge, then:
        # pdf_y = page_height - (layout_y_bottom + layout_height)
        # However, for anchored images, layout_y_bottom might already be in PDF coordinates
        # Let's check if we need conversion by looking at the anchor type
        
        # Get image dimensions
        width = image.width if image.width > 0 else block.frame.width
        height = image.height if image.height > 0 else block.frame.height
        
        # Convert from EMU to points if needed (DOCX uses EMUs for dimensions)
        # 1 point = 12700 EMU
        if width > 10000:  # Likely EMU units
            width = width / 12700.0
        if height > 10000:  # Likely EMU units
            height = height / 12700.0
        
        # Use block dimensions if image dimensions are not available
        if width <= 0:
            width = block.frame.width
        if height <= 0:
            height = block.frame.height
        
        # Layout engine uses top-down coordinates (Y increases downward from top)
        # PDF uses bottom-up coordinates (Y increases upward from bottom)
        # block.frame.y is the BOTTOM edge in layout coordinates (Y increases downward)
        # In PDF, we need bottom edge: pdf_y = page_height - (layout_y_bottom + layout_height)
        # This applies to both anchored and inline images - layout engine always uses top-down coordinates
        
        # Convert from layout coordinates to PDF coordinates
        # Layout: frame.y is bottom edge (Y increases downward from top)
        # PDF: y is bottom edge (Y increases upward from bottom)
        # Conversion: pdf_y = page_height - (layout_y_bottom + layout_height)
        y = page_height - (layout_y_bottom + layout_height)
        
        # Load image data from relationship ID
        image_data = self._load_image_data(image.rel_id)
        
        if image_data and self.direct_writer:
            # Determine image type from data
            image_type = None
            if image_data[:2] == b'\xff\xd8':
                image_type = "JPEG"
            elif image_data[:8] == b'\x89PNG\r\n\x1a\n':
                image_type = "PNG"
            
            if image_type:
                # Register image and render it
                try:
                    image_alias = self.direct_writer.register_image(image_data, width, height, image_type)
                    self.direct_writer.add_image(pdf_page, image_alias, x, y, width, height)
                    self.logger.debug(f"Rendered {image_type} image ({len(image_data)} bytes) at ({x:.2f}, {y:.2f})")
                except Exception as e:
                    self.logger.error(f"Failed to render image: {e}, using placeholder")
                    self._render_image_placeholder(pdf_page, x, y, width, height)
            else:
                self.logger.warning(f"Unknown image type for rel_id={image.rel_id}, using placeholder")
                self._render_image_placeholder(pdf_page, x, y, width, height)
        else:
            if not image_data:
                self.logger.warning(f"Could not load image data for rel_id={image.rel_id}, using placeholder")
            if not self.direct_writer:
                self.logger.warning("DirectPdfWriter not available, using placeholder")
            self._render_image_placeholder(pdf_page, x, y, width, height)
    
    def _load_image_data(self, rel_id: str) -> Optional[bytes]:
        """Load image data from relationship ID.
        
        Args:
            rel_id: Relationship ID from DOCX document
            
        Returns:
            Image data bytes or None if not found
        """
        if not rel_id:
            return None
        
        # Get package_reader from context
        package_reader = None
        if self.context:
            if hasattr(self.context, "package_reader"):
                package_reader = self.context.package_reader
            elif hasattr(self.context, "variables"):
                package_reader = self.context.variables.get("package_reader")
        
        if not package_reader:
            self.logger.warning(f"No package_reader available to load image rel_id={rel_id}")
            return None
        
        try:
            # Get relationship from document
            relationships = None
            if hasattr(package_reader, "get_relationships"):
                relationships = package_reader.get_relationships("document")
            
            if not relationships:
                # Try alternative method
                if hasattr(package_reader, "get_rels"):
                    relationships = package_reader.get_rels("document")
            
            if relationships and isinstance(relationships, dict):
                relationship = relationships.get(rel_id)
                if relationship:
                    target_path = relationship.get("target") or relationship.get("Target")
                    if target_path:
                        # Normalize path (remove leading slash, ensure word/ prefix if needed)
                        if target_path.startswith("/"):
                            target_path = target_path[1:]
                        if not target_path.startswith("word/"):
                            target_path = f"word/{target_path}"
                        
                        # Load image data using get_binary_content
                        if hasattr(package_reader, "get_binary_content"):
                            image_data = package_reader.get_binary_content(target_path)
                            if image_data:
                                self.logger.debug(f"Loaded image from {target_path} ({len(image_data)} bytes)")
                                return image_data
                        
                        # Fallback: try extracted files
                        if hasattr(package_reader, "_extracted_files"):
                            extracted_files = package_reader._extracted_files
                            if isinstance(extracted_files, dict):
                                candidate_path = extracted_files.get(target_path)
                                if candidate_path:
                                    from pathlib import Path
                                    if Path(candidate_path).exists():
                                        image_data = Path(candidate_path).read_bytes()
                                        if image_data:
                                            self.logger.debug(f"Loaded image from extracted file {candidate_path} ({len(image_data)} bytes)")
                                            return image_data
            
            self.logger.warning(f"Could not find relationship or image data for rel_id={rel_id}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error loading image data for rel_id={rel_id}: {e}", exc_info=True)
            return None
    
    def _render_image_placeholder(self, pdf_page: Any, x: float, y: float, width: float, height: float) -> None:
        """Render a placeholder for an image (until full image rendering is implemented)."""
        # Draw a light gray rectangle as placeholder
        if self.direct_writer:
            self.direct_writer.add_rect(
                pdf_page, x, y, width, height,
                fill_color=(0.9, 0.9, 0.9),
                stroke_color=(0.7, 0.7, 0.7),
                stroke_width=1.0
            )
    
    # ===================================================================
    # TextBox rendering methods
    # ===================================================================
    
    def _render_textbox_element(self, pdf_page: Any, textbox: TextBox, block: LayoutBlock, page: Optional[LayoutPage]) -> None:
        """Render a TextBox element object using its class structure."""
        self.logger.debug(f"Rendering TextBox element (width={textbox.width}, height={textbox.height})")
        
        # Get textbox position - check for absolute positioning
        if hasattr(textbox, "position") and textbox.position:
            # Absolute positioning
            pos = textbox.position
            if isinstance(pos, (tuple, list)) and len(pos) >= 2:
                # Convert from EMU to points
                x = pos[0] / 12700.0 if pos[0] > 10000 else pos[0]
                # If page is available, use page height; otherwise use a default A4 height
                page_height = page.size.height if page and hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
                y = page_height - (pos[1] / 12700.0 if pos[1] > 10000 else pos[1])
            else:
                # Use block frame position
                x = block.frame.x
                y = block.frame.y
        else:
            # Use block frame position
            x = block.frame.x
            y = block.frame.y
        
        # Get textbox dimensions
        if textbox.width > 0 and textbox.height > 0:
            # Convert from EMU to points if needed
            width = textbox.width / 12700.0 if textbox.width > 10000 else textbox.width
            height = textbox.height / 12700.0 if textbox.height > 10000 else textbox.height
        else:
            width = block.frame.width
            height = block.frame.height
        
        # Get textbox style
        style = block.style or {}
        if hasattr(textbox, "style") and textbox.style:
            style = dict(style)
            style.update(textbox.style)
        
        # Render textbox background and borders
        self._render_block_background(pdf_page, block, style)
        
        # Render textbox content
        # TextBox inherits from Body, so it can contain Paragraph, Table, etc.
        content_x = x
        content_y = y + height  # Top of content area (PDF coordinates)
        
        # Get content from textbox
        if hasattr(textbox, "content") and textbox.content:
            # TextBox.content is a list of models (Paragraph, Table, etc.)
            y_cursor = content_y
            content_items = textbox.content if isinstance(textbox.content, list) else []
            item_height = height / len(content_items) if content_items else height
            
            for item in content_items:
                # Create a temporary block for this item
                item_frame = Rect(
                    x=content_x,
                    y=y_cursor - item_height,
                    width=width,
                    height=item_height
                )
                item_block = LayoutBlock(
                    frame=item_frame,
                    content=item if hasattr(item, "__class__") else {"object": item},
                    style=style,
                    block_type=self._detect_block_type_from_element(item)
                )
                
                # Render item recursively
                self._render_block_direct(pdf_page, item_block, page)
                
                # Move cursor down
                y_cursor -= item_height
        elif hasattr(textbox, "textbox_content") and textbox.textbox_content:
            # Old-style textbox content (list of Run objects)
            # Render as a single paragraph with run-based rendering
            self.logger.debug(f"Rendering textbox with {len(textbox.textbox_content)} runs")
            
            # Render runs sequentially
            runs = textbox.textbox_content if isinstance(textbox.textbox_content, list) else []
            current_x = content_x
            current_y = content_y
            
            for run in runs:
                if not hasattr(run, "text") or not run.text:
                    continue
                
                # Get run style
                run_style = {}
                if hasattr(run, "style") and run.style:
                    run_style = run.style if isinstance(run.style, dict) else {}
                
                # Get font properties
                font_name = run_style.get("font_name") or style.get("font_name") or "Arial"
                font_size = run_style.get("font_size") or style.get("font_size") or 12.0
                font_path = self._resolve_font_path(font_name, run_style.get("bold", False), run_style.get("italic", False))
                
                # Get text color
                text_color = run_style.get("color") or style.get("color")
                
                # Render run text
                if self.direct_writer and font_path:
                    self.direct_writer.add_text(
                        pdf_page,
                        current_x,
                        current_y,
                        run.text,
                        font_size,
                        font_path,
                    )
                    
                    # Calculate text width for next run position
                    if hasattr(self.direct_writer, "get_nominal_advances"):
                        advances = self.direct_writer.get_nominal_advances(run.text, font_path, font_size)
                        text_width = sum(advances) if advances else len(run.text) * font_size * 0.6
                    else:
                        text_width = len(run.text) * font_size * 0.6
                    
                    current_x += text_width
    
    def _detect_block_type_from_element(self, element: Any) -> str:
        """Detect block type from element object."""
        if hasattr(element, "__class__"):
            class_name = element.__class__.__name__
            if class_name == "Table":
                return "table"
            elif class_name == "Paragraph":
                return "paragraph"
            elif class_name == "Image":
                return "image"
            elif class_name == "TextBox":
                return "textbox"
            elif class_name == "Shape":
                return "shape"
        return "paragraph"  # Default
    
    # ===================================================================
    # Shape rendering methods
    # ===================================================================
    
    def _render_shape_element(self, pdf_page: Any, shape: Shape, block: LayoutBlock, page: Optional[LayoutPage]) -> None:
        """Render a Shape element object using its class structure."""
        self.logger.debug(f"Rendering Shape element (type={shape.shape_type})")
        
        # Get shape position
        x = block.frame.x
        y = block.frame.y
        width = block.frame.width
        height = block.frame.height
        
        # Get position from shape if available
        if hasattr(shape, "position") and shape.position:
            pos = shape.position
            if isinstance(pos, dict):
                pos_x = pos.get("x", x)
                pos_y = pos.get("y", y)
                # Convert from EMU to points if needed
                x = pos_x / 12700.0 if pos_x > 10000 else pos_x
                # If page is available, use page height; otherwise use a default A4 height
                page_height = page.size.height if page and hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
                y = page_height - (pos_y / 12700.0 if pos_y > 10000 else pos_y)
        
        # Get size from shape if available
        if hasattr(shape, "size") and shape.size:
            size = shape.size
            if isinstance(size, dict):
                size_w = size.get("width", width)
                size_h = size.get("height", height)
                # Convert from EMU to points if needed
                width = size_w / 12700.0 if size_w > 10000 else size_w
                height = size_h / 12700.0 if size_h > 10000 else size_h
        
        # Get shape style
        style = block.style or {}
        if hasattr(shape, "style") and shape.style:
            style = dict(style)
            style.update(shape.style)
        
        # Render shape based on type
        shape_type = shape.shape_type if hasattr(shape, "shape_type") else "rectangle"
        
        if shape_type == "rectangle" or shape_type == "rect":
            self._render_rectangle_shape(pdf_page, x, y, width, height, style)
        elif shape_type == "circle" or shape_type == "ellipse":
            self._render_circle_shape(pdf_page, x, y, width, height, style)
        elif shape_type == "line":
            self._render_line_shape(pdf_page, x, y, width, height, style)
        else:
            # Default: render as rectangle
            self.logger.debug(f"Unknown shape type '{shape_type}', rendering as rectangle")
            self._render_rectangle_shape(pdf_page, x, y, width, height, style)
        
        # Render shape content if available
        if hasattr(shape, "content") and shape.content:
            self._render_shape_content(pdf_page, shape, x, y, width, height, page)
    
    def _render_rectangle_shape(
        self, pdf_page: Any, x: float, y: float, width: float, height: float, style: Dict[str, Any]
    ) -> None:
        """Render a rectangle shape with optional transparency and border radius."""
        fill_color = self._extract_fill_color(style)
        stroke_color, stroke_width = self._extract_border_from_style(style)
        
        # Extract transparency/alpha
        fill_alpha = float(style.get("fill_alpha", style.get("opacity", 1.0)))
        stroke_alpha = float(style.get("stroke_alpha", style.get("opacity", 1.0)))
        
        # Extract border radius
        radius = float(style.get("border_radius", style.get("radius", 0.0)))
        
        if self.direct_writer:
            self.direct_writer.add_rect(
                pdf_page, x, y, width, height,
                fill_color=fill_color,
                stroke_color=stroke_color,
                stroke_width=stroke_width or 1.0,
                fill_alpha=fill_alpha,
                stroke_alpha=stroke_alpha,
                radius=radius,
            )
    
    def _render_circle_shape(
        self, pdf_page: Any, x: float, y: float, width: float, height: float, style: Dict[str, Any]
    ) -> None:
        """Render a circle/ellipse shape."""
        fill_color = self._extract_fill_color(style)
        stroke_color, stroke_width = self._extract_border_from_style(style)
        
        # Calculate center and radius
        center_x = x + width / 2.0
        center_y = y + height / 2.0
        radius = min(width, height) / 2.0
        
        # Extract transparency/alpha
        fill_alpha = float(style.get("fill_alpha", style.get("opacity", 1.0)))
        stroke_alpha = float(style.get("stroke_alpha", style.get("opacity", 1.0)))
        
        # Render ellipse using DirectPdfWriter
        if self.direct_writer:
            self.direct_writer.add_ellipse(
                pdf_page, x, y, width, height,
                fill_color=fill_color,
                stroke_color=stroke_color,
                stroke_width=stroke_width or 1.0,
                fill_alpha=fill_alpha,
                stroke_alpha=stroke_alpha,
            )
    
    def _render_line_shape(
        self, pdf_page: Any, x: float, y: float, width: float, height: float, style: Dict[str, Any]
    ) -> None:
        """Render a line shape with optional dash patterns."""
        stroke_color, stroke_width = self._extract_border_from_style(style)
        
        # Calculate line endpoints
        x1 = x
        y1 = y
        x2 = x + width
        y2 = y + height
        
        # Extract transparency/alpha
        stroke_alpha = float(style.get("stroke_alpha", style.get("opacity", 1.0)))
        
        # Extract dash pattern from style
        dash_pattern = style.get("dash_pattern") or style.get("dash") or style.get("stroke_dash")
        dash_array = None
        dash_phase = 0.0
        
        if dash_pattern:
            if isinstance(dash_pattern, (list, tuple)):
                # Direct array: [dash_length, gap_length, ...]
                dash_array = [float(d) for d in dash_pattern]
            elif isinstance(dash_pattern, str):
                # String format: "5,3" or "5 3" or "dashed" / "dotted"
                if dash_pattern.lower() == "dashed":
                    dash_array = [5.0, 3.0]
                elif dash_pattern.lower() == "dotted":
                    dash_array = [1.0, 3.0]
                else:
                    # Parse comma or space-separated values
                    parts = dash_pattern.replace(",", " ").split()
                    dash_array = [float(p) for p in parts if p]
        
        # Render line using Bezier curve
        if self.direct_writer:
            # Line from (x1, y1) to (x2, y2)
            path = [
                (x1, y1),  # Start point
                (x2, y2),  # End point
            ]
            
            # Use add_bezier with dash pattern if supported
            if hasattr(self.direct_writer, "add_bezier_with_dash") and dash_array:
                self.direct_writer.add_bezier_with_dash(
                    pdf_page,
                    path,
                    fill_color=None,
                    stroke_color=stroke_color,
                    stroke_width=stroke_width or 1.0,
                    fill_alpha=1.0,
                    stroke_alpha=stroke_alpha,
                    dash_array=dash_array,
                    dash_phase=dash_phase,
                )
            else:
                # Render with dash pattern support (now fully implemented)
                self.direct_writer.add_bezier(
                    pdf_page,
                    path,
                    fill_color=None,
                    stroke_color=stroke_color,
                    stroke_width=stroke_width or 1.0,
                    fill_alpha=1.0,
                    stroke_alpha=stroke_alpha,
                    dash_array=dash_array,
                    dash_phase=dash_phase,
                )
    
    def _render_shape_content(
        self, pdf_page: Any, shape: Any, x: float, y: float, width: float, height: float, page: Optional[LayoutPage]
    ) -> None:
        """Render shape content (paragraphs, tables, etc.) inside shape.
        
        Args:
            pdf_page: PDF page object
            shape: Shape object with content
            x: Shape X position
            y: Shape Y position
            width: Shape width
            height: Shape height
            page: LayoutPage object (optional)
        """
        if not hasattr(shape, "content") or not shape.content:
            return
        
        content_items = shape.content if isinstance(shape.content, list) else [shape.content]
        self.logger.debug(f"Rendering {len(content_items)} content items in shape")
        
        # Calculate content area with padding
        padding = 5.0  # Default padding
        content_x = x + padding
        content_y = y + height - padding  # Top of content area (PDF coordinates)
        content_width = width - 2 * padding
        content_height = height - 2 * padding
        
        # Render each content item
        y_cursor = content_y
        item_height = content_height / len(content_items) if content_items else content_height
        
        for item in content_items:
            # Detect item type
            item_type = "paragraph"  # Default
            if hasattr(item, "__class__"):
                class_name = item.__class__.__name__
                if class_name == "Paragraph":
                    item_type = "paragraph"
                elif class_name == "Table":
                    item_type = "table"
                elif class_name == "Image":
                    item_type = "image"
            
            # Create temporary block for item
            item_frame = Rect(
                x=content_x,
                y=y_cursor - item_height,
                width=content_width,
                height=item_height
            )
            
            item_block = LayoutBlock(
                frame=item_frame,
                content=item if hasattr(item, "__class__") else {"object": item},
                style=shape.style if hasattr(shape, "style") else {},
                block_type=item_type
            )
            
            # Render item recursively
            self._render_block_direct(pdf_page, item_block, page)
            
            # Move cursor down
            y_cursor -= item_height
    
    def _extract_border_from_style(self, style: Dict[str, Any]) -> Tuple[Optional[Tuple[float, float, float]], float]:
        """Extract border color and width from style."""
        borders = style.get("borders", {})
        if isinstance(borders, dict):
            # Try to get any border
            for side in ["top", "right", "bottom", "left"]:
                border_info = borders.get(side, {})
                if isinstance(border_info, dict):
                    border_width = border_info.get("width", 0)
                    border_color = border_info.get("color", "#000000")
                    if border_width and border_width > 0:
                        color = to_color(border_color, fallback="#000000")
                        # Convert twips to points if needed
                        if border_width > 1000:
                            from docx_interpreter.engine.geometry import twips_to_points
                            border_width = twips_to_points(border_width)
                        return (color.red, color.green, color.blue), border_width
        return None, 0.0

    # ===================================================================
    # Legacy rendering methods (for backwards compatibility)
    # ===================================================================

    def _render_block_background(self, pdf_page: Any, block: LayoutBlock, style: Dict[str, Any]) -> None:
        """Render block background with optional shadow, gradient, and transparency."""
        # Check for shadow first
        shadow = style.get("shadow")
        if shadow:
            shadow_color = (0.5, 0.5, 0.5)  # Default gray
            shadow_offset_x = 2.0
            shadow_offset_y = -2.0
            shadow_blur = 2.0
            shadow_alpha = 0.5
            
            if isinstance(shadow, dict):
                from docx_interpreter.renderers.render_utils import to_color
                shadow_color_obj = to_color(shadow.get("color", "#888888"))
                shadow_color = (shadow_color_obj.red, shadow_color_obj.green, shadow_color_obj.blue)
                shadow_offset_x = float(shadow.get("offset_x", 2.0))
                shadow_offset_y = float(shadow.get("offset_y", -2.0))
                shadow_blur = float(shadow.get("blur", 2.0))
                shadow_alpha = float(shadow.get("alpha", 0.5))
            
            assert self.direct_writer is not None
            self.direct_writer.add_shadow(
                pdf_page,
                block.frame.x,
                block.frame.y,
                block.frame.width,
                block.frame.height,
                shadow_color,
                shadow_offset_x,
                shadow_offset_y,
                shadow_blur,
                shadow_alpha,
            )
        
        # Check for gradient
        gradient = style.get("gradient")
        if gradient:
            from docx_interpreter.renderers.render_utils import to_color
            start_color_obj = to_color(gradient.get("start_color", "#FFFFFF"))
            end_color_obj = to_color(gradient.get("end_color", "#000000"))
            start_color = (start_color_obj.red, start_color_obj.green, start_color_obj.blue)
            end_color = (end_color_obj.red, end_color_obj.green, end_color_obj.blue)
            direction = gradient.get("direction", "vertical")
            alpha = float(gradient.get("alpha", 1.0))
            
            assert self.direct_writer is not None
            self.direct_writer.add_gradient(
                pdf_page,
                block.frame.x,
                block.frame.y,
                block.frame.width,
                block.frame.height,
                start_color,
                end_color,
                direction,
                alpha,
            )
            return  # Gradient replaces fill
        
        # Regular fill with optional transparency
        fill_color = self._extract_fill_color(style)
        
        # Extract transparency/alpha
        fill_alpha = float(style.get("fill_alpha", style.get("opacity", 1.0)))
        stroke_alpha = float(style.get("stroke_alpha", style.get("opacity", 1.0)))
        
        # Extract border radius
        radius = float(style.get("border_radius", style.get("radius", 0.0)))
        
        # Handle borders - render individually for each side (top, right, bottom, left)
        borders_dict = style.get("borders", {})
        if isinstance(borders_dict, dict) and borders_dict:
            # Render borders individually for each side
            self._render_paragraph_borders(pdf_page, block, borders_dict, fill_color, fill_alpha)
            # If we have fill color, render it
            if fill_color:
                assert self.direct_writer is not None
                self.direct_writer.add_rect(
                    pdf_page,
                    block.frame.x,
                    block.frame.y,
                    block.frame.width,
                    block.frame.height,
                    fill_color,
                    None,  # No stroke (borders rendered separately)
                    0.0,
                    fill_alpha=fill_alpha,
                    stroke_alpha=1.0,
                    radius=radius,
                )
        else:
            # Simple border (all sides same) - use old method
            stroke_color, stroke_width = self._extract_border(style)
            if not fill_color and not stroke_color:
                return
            
            assert self.direct_writer is not None
            self.direct_writer.add_rect(
                pdf_page,
                block.frame.x,
                block.frame.y,
                block.frame.width,
                block.frame.height,
                fill_color,
                stroke_color,
                stroke_width,
                fill_alpha=fill_alpha,
                stroke_alpha=stroke_alpha,
                radius=radius,
            )

    def _render_paragraph_borders(
        self, pdf_page: Any, block: LayoutBlock, borders: Dict[str, Any],
        fill_color: Optional[Tuple[float, float, float]], fill_alpha: float
    ) -> None:
        """Render paragraph borders individually for each side (top, right, bottom, left)."""
        from docx_interpreter.renderers.render_utils import to_color, _normalize_border_spec
        
        x = block.frame.x
        y = block.frame.y
        width = block.frame.width
        height = block.frame.height
        
        # Render borders for each side
        for side in ["top", "right", "bottom", "left"]:
            border_spec = _normalize_border_spec(borders.get(side))
            if not border_spec:
                continue
            
            border_color = to_color(border_spec.get("color", "#000000"))
            border_width = border_spec.get("width", 1.0)
            border_style = border_spec.get("style", "solid")
            
            # Convert twips to points if needed
            if border_width > 1000:
                from docx_interpreter.engine.geometry import twips_to_points
                border_width = twips_to_points(border_width)
            
            color_tuple = (border_color.red, border_color.green, border_color.blue)
            
            # Calculate border line coordinates
            if side == "top":
                # Top border: from (x, y+height) to (x+width, y+height)
                x1, y1 = x, y + height
                x2, y2 = x + width, y + height
            elif side == "bottom":
                # Bottom border: from (x, y) to (x+width, y)
                x1, y1 = x, y
                x2, y2 = x + width, y
            elif side == "left":
                # Left border: from (x, y) to (x, y+height)
                x1, y1 = x, y
                x2, y2 = x, y + height
            else:  # right
                # Right border: from (x+width, y) to (x+width, y+height)
                x1, y1 = x + width, y
                x2, y2 = x + width, y + height
            
            # Render border as line with dash pattern support
            dash_pattern = border_spec.get("dash") or border_spec.get("dash_pattern") or border_spec.get("style")
            dash_array = None
            if dash_pattern:
                if isinstance(dash_pattern, str) and dash_pattern.lower() in ["dashed", "dash"]:
                    dash_array = [5.0, 3.0]
                elif isinstance(dash_pattern, str) and dash_pattern.lower() in ["dotted", "dot"]:
                    dash_array = [1.0, 3.0]
                elif isinstance(dash_pattern, (list, tuple)):
                    dash_array = [float(d) for d in dash_pattern]
                elif isinstance(dash_pattern, str):
                    parts = dash_pattern.replace(",", " ").split()
                    dash_array = [float(p) for p in parts if p]
            
            # Render as line using Bezier curve
            if side in ["top", "bottom"]:
                # Horizontal border
                path = [(x1, y1), (x2, y2)]
                self.direct_writer.add_bezier(
                    pdf_page,
                    path,
                    fill_color=None,
                    stroke_color=color_tuple,
                    stroke_width=border_width,
                    dash_array=dash_array,
                )
            else:
                # Vertical border
                path = [(x1, y1), (x2, y2)]
                self.direct_writer.add_bezier(
                    pdf_page,
                    path,
                    fill_color=None,
                    stroke_color=color_tuple,
                    stroke_width=border_width,
                    dash_array=dash_array,
                )
    
    def _extract_fill_color(self, style: Dict[str, Any]) -> Optional[Tuple[float, float, float]]:
        shading = style.get("shading") if isinstance(style, dict) else None
        fill_value = None
        if isinstance(shading, dict):
            fill_value = shading.get("fill") or shading.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}fill")
        if not fill_value:
            fill_value = style.get("background_color") or style.get("bg_color")
        if not fill_value or str(fill_value).lower() == "auto":
            return None
        color = to_color(fill_value, fallback="#FFFFFF")
        return (color.red, color.green, color.blue)

    def _render_table_direct(self, pdf_page: Any, block: LayoutBlock, page: LayoutPage, table_object: Optional[Any] = None) -> None:
        """Render table block directly to PDF.
        
        Args:
            pdf_page: PDF page object
            block: LayoutBlock with table content
            page: LayoutPage object
            table_object: Optional Table object (if provided, uses it directly instead of block.content)
        """
        # Extract rows and grid from table_object or block.content
        rows = []
        grid = []
        
        if table_object:
            # Use table object directly
            if hasattr(table_object, "rows"):
                rows = table_object.rows
            if hasattr(table_object, "grid"):
                grid = table_object.grid
            elif hasattr(table_object, "table_grid"):
                grid = table_object.table_grid
        else:
            # Fall back to block.content (dict format)
            if not isinstance(block.content, dict):
                self.logger.debug(f"Block content is not dict: {type(block.content)}")
                return
            
            rows = block.content.get("rows", [])
            grid = block.content.get("grid", [])
        
        if not rows:
            self.logger.debug(f"No rows in table")
            return
        
        self.logger.debug(f"Rendering table with {len(rows)} rows")
        
        style = block.style or {}
        
        # Calculate column widths from grid (parsed directly from DOCX)
        max_cols = max(len(getattr(row, "cells", [])) for row in rows) if rows else 0
        
        col_widths = []
        total_grid_width = 0.0
        
        if grid and isinstance(grid, list):
            # Get widths from grid - convert twips to points
            # Grid is parsed directly from DOCX tblGrid/gridCol elements
            from docx_interpreter.engine.geometry import twips_to_points
            
            for entry in grid[:max_cols]:
                width = entry.get("width") if isinstance(entry, dict) else None
                if width:
                    try:
                        # Width is stored as string from XML (e.g., "3810" or "410")
                        # DOCX always stores column widths in twips (1/20th of a point)
                        numeric = float(width)
                        # Always convert twips to points (1 twip = 1/20 pt)
                        numeric_pts = twips_to_points(numeric)
                        col_widths.append(numeric_pts)
                        total_grid_width += numeric_pts
                    except (TypeError, ValueError):
                        pass
                else:
                    break
        
        # If we have column widths from grid, use them directly from DOCX
        # Only scale if they exceed available content width (to prevent page overflow)
        if col_widths and total_grid_width > 0:
            # Get page width and margins to calculate max available width
            page_width = pdf_page.size.width if hasattr(pdf_page, 'size') else DEFAULT_PAGE_SIZE_PT[0]
            # Prefer margins from current layout page
            page_margins = self._get_page_margins(page) if 'page' in locals() and page is not None else DEFAULT_MARGINS
            top_m, right_m, bottom_m, left_m = self._parse_margins(page_margins)
            max_content_width = page_width - left_m - right_m  # left and right margins
            
            # Use grid total width directly from DOCX (preserve original proportions)
            # Only scale if grid total exceeds available content width
            if total_grid_width > max_content_width:
                # Scale to fit within content width
                scale = max_content_width / total_grid_width
                col_widths = [w * scale for w in col_widths]
            else:
                # Grid total fits within content width - use as-is
                # This preserves the original column proportions from DOCX
                # col_widths already correct - no scaling needed
                pass
        else:
            # No grid data - fill remaining columns with equal width
            if len(col_widths) < max_cols:
                remaining_width = block.frame.width - sum(col_widths)
                remaining_cols = max_cols - len(col_widths)
                if remaining_cols > 0 and remaining_width > 0:
                    col_widths.extend([remaining_width / remaining_cols] * remaining_cols)
            
            # If still no widths, use equal distribution
            if not col_widths or len(col_widths) < max_cols:
                col_widths = [block.frame.width / max_cols] * max_cols if max_cols > 0 else []
        
        # Ensure we have the correct number of column widths
        if len(col_widths) < max_cols:
            # Fill missing columns with average width
            avg_width = sum(col_widths) / len(col_widths) if col_widths else block.frame.width / max_cols
            col_widths.extend([avg_width] * (max_cols - len(col_widths)))
        
        # Calculate row heights first (before rendering) to get accurate dimensions
        # We need cell widths for calculating paragraph heights
        row_heights = []
        for row in rows:
            cells = getattr(row, "cells", [])
            if not cells:
                row_heights.append(DEFAULT_TABLE_ROW_HEIGHT_PT)  # Default height
                continue
            
            # Calculate row height with actual cell widths
            max_cell_height = 0.0
            col_idx = 0
            
            for cell in cells:
                if col_idx >= len(col_widths):
                    break
                
                # Calculate cell width (accounting for grid_span)
                grid_span = getattr(cell, "grid_span", 1) or 1
                grid_span = int(grid_span) if grid_span else 1
                
                cell_width = 0.0
                for i in range(grid_span):
                    if col_idx + i < len(col_widths):
                        cell_width += col_widths[col_idx + i]
                
                # Calculate cell content height with actual width
                cell_height = self._calculate_cell_height(cell, cell_width)
                max_cell_height = max(max_cell_height, cell_height)
                
                col_idx += grid_span
            
            row_height = max(max_cell_height, DEFAULT_TABLE_ROW_MIN_HEIGHT_PT) if max_cell_height > 0 else DEFAULT_TABLE_ROW_HEIGHT_PT
            row_heights.append(row_height)
        
        # Calculate actual table width from column widths
        # This ensures table width matches the sum of column widths
        actual_table_width = sum(col_widths) if col_widths else block.frame.width
        
        # Calculate table position - use page margins, not frame.x (frame.x might be wrong)
        page_width = pdf_page.size.width if hasattr(pdf_page, 'size') else DEFAULT_PAGE_SIZE_PT[0]
        page_margins = self._get_page_margins(page) if 'page' in locals() and page is not None else DEFAULT_MARGINS
        top_m, right_m, bottom_m, left_m = self._parse_margins(page_margins)
        max_content_width = page_width - left_m - right_m  # left and right margins
        
        # Position table at left margin
        # Frame.x might be positioned incorrectly, so use margins directly
        table_x = left_m  # Start at left margin
        
        # Ensure table doesn't exceed page width
        if table_x + actual_table_width > max_content_width + left_m:
            # Table is too wide - shift left to fit
            table_x = max(left_m, page_width - right_m - actual_table_width)
        
        # Calculate total table height from all row heights
        total_table_height = sum(row_heights) if row_heights else block.frame.height
        
        # Convert from layout coordinates to PDF coordinates
        # Layout engine uses top-down coordinates (Y increases downward from top)
        # PDF uses bottom-up coordinates (Y increases upward from bottom)
        # block.frame.y is the BOTTOM edge in layout coordinates
        # In PDF, we need bottom edge: pdf_y = page_height - (layout_y_bottom + layout_height)
        page_height = page.size.height if hasattr(page.size, "height") else DEFAULT_PAGE_SIZE_PT[1]
        layout_y_bottom = block.frame.y
        layout_height = block.frame.height
        
        # Convert to PDF coordinates
        table_bottom = page_height - (layout_y_bottom + layout_height)  # Bottom edge in PDF coordinates
        table_top = table_bottom + total_table_height  # Top edge in PDF coordinates
        table_left = table_x
        table_right = table_x + actual_table_width
        
        # STEP 1: Render table outer border (if table has borders)
        table_borders = style.get("borders", {})
        if table_borders:
            self._render_table_outer_border(pdf_page, table_left, table_bottom, actual_table_width, total_table_height, table_borders)
        
        # STEP 2: Render cell backgrounds and borders, then content
        # Start from top of table (table_top is now in PDF coordinates)
        # In PDF, y increases upward, so table_top is the top edge
        # We need to render from top to bottom (decreasing Y)
        y_top = table_top  # Start from top of table (in PDF coordinates)
        
        for row_idx, row in enumerate(rows):
            cells = getattr(row, "cells", [])
            if not cells:
                continue
            
            # Use calculated row height
            row_height = row_heights[row_idx] if row_idx < len(row_heights) else DEFAULT_TABLE_ROW_HEIGHT_PT
            
            # Calculate y position: start from top, go down
            # y_top is the top edge of the current row
            # For first row, it's table_top; for subsequent rows, subtract previous row heights
            if row_idx == 0:
                y_row_top = y_top
            else:
                # Subtract all previous row heights
                y_row_top = y_top - sum(row_heights[i] for i in range(row_idx))
            
            # Bottom edge of current row
            y_row_bottom = y_row_top - row_height
            
            # Render cells in this row
            # Use adjusted table_x if we calculated it, otherwise use frame.x
            x_cursor = table_x
            col_idx = 0
            for cell in cells:
                if col_idx >= len(col_widths):
                    break
                
                # Check for vertical merge - skip cells that are continuation of merged cells
                vertical_merge = getattr(cell, "vertical_merge", False)
                vertical_merge_type = getattr(cell, "vertical_merge_type", None)
                
                # If cell has vertical_merge=True and type="continue", it's part of a merged cell
                # from previous row - skip rendering (it's already rendered)
                if vertical_merge and vertical_merge_type == "continue":
                    # Still need to advance col_idx and x_cursor for proper positioning
                    grid_span = getattr(cell, "grid_span", 1) or 1
                    grid_span = int(grid_span) if grid_span else 1
                    cell_width = 0.0
                    for i in range(grid_span):
                        if col_idx + i < len(col_widths):
                            cell_width += col_widths[col_idx + i]
                    x_cursor += cell_width
                    col_idx += grid_span
                    continue
                
                # Handle grid span (horizontal merged cells)
                grid_span = getattr(cell, "grid_span", 1) or 1
                grid_span = int(grid_span) if grid_span else 1
                
                # Calculate cell width (span multiple columns if needed)
                cell_width = 0.0
                for i in range(grid_span):
                    if col_idx + i < len(col_widths):
                        cell_width += col_widths[col_idx + i]
                
                # Calculate cell height - if vertical merge starts here, calculate total height
                cell_height = row_height
                if vertical_merge_type == "restart":
                    # Calculate total height for merged rows
                    merged_height = row_height
                    for next_row_idx in range(row_idx + 1, len(rows)):
                        next_row = rows[next_row_idx]
                        next_cells = getattr(next_row, "cells", [])
                        if col_idx < len(next_cells):
                            next_cell = next_cells[col_idx]
                            next_vmerge = getattr(next_cell, "vertical_merge", False)
                            next_vmerge_type = getattr(next_cell, "vertical_merge_type", None)
                            if next_vmerge and next_vmerge_type == "continue":
                                # This row is part of the merge - add its height
                                next_row_height = row_heights[next_row_idx] if next_row_idx < len(row_heights) else DEFAULT_TABLE_ROW_HEIGHT_PT
                                merged_height += next_row_height
                            else:
                                # Merge ends here
                                break
                    cell_height = merged_height
                
                # Calculate cell top position (for merged cells, this includes all rows)
                # Start from row top, but for merged cells we need to account for merged height
                y_cell_top = y_row_top
                
                # Render cell: y_cell_top is the top edge of the cell
                # For merged cells, cell_height already includes all merged rows
                self.logger.debug(f"Row {row_idx}, Cell {col_idx}: Rendering at x={x_cursor:.2f}, y={y_cell_top:.2f}, width={cell_width:.2f}, height={cell_height:.2f}")
                cell_content = getattr(cell, "content", [])
                self.logger.debug(f"Row {row_idx}, Cell {col_idx}: Cell has {len(cell_content) if cell_content else 0} content items")
                if not cell_content:
                    # Try alternative ways to get cell content
                    if hasattr(cell, "get_paragraphs"):
                        paragraphs = cell.get_paragraphs()
                        self.logger.debug(f"Row {row_idx}, Cell {col_idx}: Cell.get_paragraphs() returned {len(paragraphs) if paragraphs else 0} paragraphs")
                    if hasattr(cell, "paragraphs"):
                        paragraphs = cell.paragraphs
                        self.logger.debug(f"Row {row_idx}, Cell {col_idx}: Cell.paragraphs has {len(paragraphs) if isinstance(paragraphs, list) else 'not a list'} items")
                    if isinstance(cell, dict):
                        cell_dict_content = cell.get("content", [])
                        self.logger.debug(f"Row {row_idx}, Cell {col_idx}: Cell (dict) has {len(cell_dict_content) if cell_dict_content else 0} content items")
                self._render_cell_direct(pdf_page, cell, x_cursor, y_cell_top, cell_width, cell_height)
                
                # Advance cursor by cell width (including spanned columns)
                x_cursor += cell_width
                col_idx += grid_span
    
    def _render_table_outer_border(self, pdf_page: Any, x: float, y: float, width: float, height: float, borders: Dict[str, Any]) -> None:
        """Render outer border of the table."""
        from docx_interpreter.renderers.render_utils import to_color
        from docx_interpreter.engine.geometry import twips_to_points
        
        # Get border style for each side
        for side in ["top", "right", "bottom", "left"]:
            border_info = borders.get(side, {})
            if isinstance(border_info, dict):
                border_width = border_info.get("width", 0)
                border_color = border_info.get("color", "#000000")
                border_style = border_info.get("style", "single")
                
                if border_width and border_width > 0 and border_style not in ("none", "nil"):
                    color = to_color(border_color, fallback="#000000")
                    stroke_color = (color.red, color.green, color.blue)
                    
                    # Convert twips to points
                    border_width_pt = twips_to_points(border_width) if border_width > 1000 else float(border_width)
                    
                    # Draw border using rect (no fill, only stroke)
                    # In PDF coordinates: x=left, y=bottom, width goes right, height goes up
                    if side == "top":
                        # Top border: horizontal line at y + height
                        self.direct_writer.add_rect(
                            pdf_page, x, y + height - border_width_pt, width, border_width_pt,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width_pt
                        )
                    elif side == "right":
                        # Right border: vertical line at x + width
                        self.direct_writer.add_rect(
                            pdf_page, x + width - border_width_pt, y, border_width_pt, height,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width_pt
                        )
                    elif side == "bottom":
                        # Bottom border: horizontal line at y
                        self.direct_writer.add_rect(
                            pdf_page, x, y, width, border_width_pt,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width_pt
                        )
                    elif side == "left":
                        # Left border: vertical line at x
                        self.direct_writer.add_rect(
                            pdf_page, x, y, border_width_pt, height,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width_pt
                        )
    
    def _calculate_cell_height(self, cell: Any, cell_width: float) -> float:
        """Calculate cell height based on content and cell width."""
        cell_content = getattr(cell, "content", [])
        if not cell_content:
            return 0.0
        
        # Calculate cell margins
        cell_margins = getattr(cell, "cell_margins", {}) or {}
        margin_top = self._get_margin_value(cell_margins.get("top", 0))
        margin_bottom = self._get_margin_value(cell_margins.get("bottom", 0))
        
        total_height = 0.0
        
        # Calculate available width for text (cell width minus left/right margins)
        margin_left = self._get_margin_value(cell_margins.get("left", 0))
        margin_right = self._get_margin_value(cell_margins.get("right", 0))
        available_width = cell_width - margin_left - margin_right
        
        for item in cell_content:
            if hasattr(item, "block_type") and item.block_type == "paragraph":
                # Check if paragraph has layout (lines)
                para_content = getattr(item, "content", {})
                if isinstance(para_content, dict):
                    lines = para_content.get("lines", [])
                    if lines:
                        # Paragraph is already laid out - use layout heights
                        para_style = getattr(item, "style", {}) or {}
                        line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                        
                        for line_entry in lines:
                            layout = line_entry.get("layout")
                            if layout and hasattr(layout, "height"):
                                line_height = layout.height * line_spacing
                                total_height += line_height
                        if len(lines) > 0:
                            total_height += 2.0  # Paragraph spacing
                    else:
                        # Paragraph not laid out - calculate from text
                        total_height += self._estimate_paragraph_height(item, available_width)
                elif hasattr(item, "text"):
                    # Paragraph has text but no content dict
                    total_height += self._estimate_paragraph_height(item, available_width)
        
        # Add cell margins
        total_height += margin_top + margin_bottom
        
        return total_height
    
    def _estimate_paragraph_height(self, para: Any, available_width: float) -> float:
        """Estimate paragraph height from text and font size."""
        para_text = getattr(para, "text", "") or ""
        if not para_text:
            return 0.0
        
        para_style = getattr(para, "style", {}) or {}
        font_size = float(para_style.get("font_size", 11.0) or 11.0)
        line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
        
        # Estimate character width (~0.6 * font_size for typical fonts)
        char_width = font_size * 0.6
        
        # Calculate how many characters fit per line
        chars_per_line = available_width / char_width if char_width > 0 else 50
        
        # Estimate number of lines needed
        if chars_per_line > 0:
            estimated_lines = max(1, len(para_text) / chars_per_line)
        else:
            estimated_lines = 1
        
        # Line height = font_size * 1.2 * line_spacing
        line_height = font_size * 1.2 * line_spacing
        
        return estimated_lines * line_height
    
    def _get_row_height(self, row: Any, block: LayoutBlock) -> float:
        """Get row height in points based on cell content."""
        # First try explicit row height
        if hasattr(row, "height") and row.height:
            try:
                height = float(row.height)
                # Convert twips to points if needed
                if height > 1000:
                    from docx_interpreter.engine.geometry import twips_to_points
                    height = twips_to_points(height)
                if height > 0:
                    return height
            except (TypeError, ValueError):
                pass
        
        # Calculate row height from cell content
        cells = getattr(row, "cells", [])
        max_height = 0.0
        
        for cell in cells:
            cell_content = getattr(cell, "content", [])
            cell_height = 0.0
            
            # Calculate cell margins
            cell_margins = getattr(cell, "cell_margins", {}) or {}
            margin_top = self._get_margin_value(cell_margins.get("top", 0))
            margin_bottom = self._get_margin_value(cell_margins.get("bottom", 0))
            
            # Calculate height from paragraphs
            for item in cell_content:
                if hasattr(item, "block_type") and item.block_type == "paragraph":
                    # Check if paragraph has layout (lines)
                    para_content = getattr(item, "content", {})
                    if isinstance(para_content, dict):
                        lines = para_content.get("lines", [])
                        if lines:
                            # Paragraph is already laid out - use layout heights
                            para_style = getattr(item, "style", {}) or {}
                            line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                            
                            # Sum up heights of all lines with line spacing
                            for line_entry in lines:
                                layout = line_entry.get("layout")
                                if layout and hasattr(layout, "height"):
                                    # Apply line spacing multiplier
                                    line_height = layout.height * line_spacing
                                    cell_height += line_height
                            # Add spacing between paragraphs
                            if len(lines) > 0:
                                cell_height += 2.0  # Small spacing between paragraphs
                        else:
                            # Paragraph not laid out - calculate height from text and font size
                            para_text = getattr(item, "text", "") or ""
                            if para_text:
                                para_style = getattr(item, "style", {}) or {}
                                font_size = float(para_style.get("font_size", 11.0) or 11.0)
                                line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                                
                                # Estimate line height based on font size
                                # Typical line height = font_size * 1.2 (with line spacing)
                                line_height = font_size * 1.2 * line_spacing
                                
                                # Estimate number of lines (rough approximation)
                                # For now, assume text wraps based on cell width
                                # This is a simple estimate - could be improved with actual text measurement
                                estimated_lines = max(1, len(para_text) / 50)  # Rough estimate
                                cell_height += estimated_lines * line_height
                    
                    # If paragraph has text but no content dict, use text length
                    elif hasattr(item, "text"):
                        para_text = getattr(item, "text", "") or ""
                        if para_text:
                            para_style = getattr(item, "style", {}) or {}
                            font_size = float(para_style.get("font_size", 11.0) or 11.0)
                            line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                            
                            # Estimate line height
                            line_height = font_size * 1.2 * line_spacing
                            estimated_lines = max(1, len(para_text) / 50)
                            cell_height += estimated_lines * line_height
            
            # Add cell margins
            cell_height += margin_top + margin_bottom
            
            # Track maximum height
            max_height = max(max_height, cell_height)
        
        # Minimum row height
        if max_height > 0:
            return max(max_height, DEFAULT_TABLE_ROW_MIN_HEIGHT_PT)  # Minimum
        
        # Default row height if no content
        return DEFAULT_TABLE_ROW_HEIGHT_PT
    
    def _render_cell_direct(
        self, pdf_page: Any, cell: Any, cell_x: float, cell_y_top: float, width: float, height: float
    ) -> None:
        """Render a single table cell.
        
        Args:
            cell_x: X position (left edge) of the cell
            cell_y_top: Y position (top edge) of the cell (in PDF coordinates, Y increases upward)
            width: Width of the cell
            height: Height of the cell
        """
        # Check if cell is a TableCell object and use type-based rendering
        if TableCell is not None and isinstance(cell, TableCell):
            self._render_table_cell_element(pdf_page, cell, cell_x, cell_y_top, width, height)
            return
        
        # Legacy rendering for dict-based or other cell representations
        cell_style = getattr(cell, "style", {}) or {}
        
        # Render cell background
        fill_color = self._extract_fill_color(cell_style)
        if fill_color:
            # In PDF, rect is drawn with bottom-left corner at (x, y)
            # So we need y_bottom = y_top - height
            cell_y_bottom = cell_y_top - height
            self.direct_writer.add_rect(
                pdf_page, cell_x, cell_y_bottom, width, height, fill_color=fill_color, stroke_color=None, stroke_width=0
            )
        
        # Render cell borders
        borders = getattr(cell, "cell_borders", None) or cell_style.get("borders", {})
        if borders:
            cell_y_bottom = cell_y_top - height
            self._render_cell_borders(pdf_page, cell, cell_x, cell_y_bottom, width, height, borders)
        
        # Render cell content (paragraphs)
        # Try different ways to get cell content
        cell_content = getattr(cell, "content", [])
        if not cell_content:
            # Try get_paragraphs() method (used by footer table cells)
            if hasattr(cell, "get_paragraphs"):
                paragraphs = cell.get_paragraphs()
                if paragraphs:
                    cell_content = list(paragraphs)
            # Try paragraphs attribute
            elif hasattr(cell, "paragraphs"):
                paragraphs = getattr(cell, "paragraphs", [])
                if isinstance(paragraphs, list) and paragraphs:
                    cell_content = paragraphs
            # Try dict access
            elif isinstance(cell, dict):
                cell_content = cell.get("content", [])
        
        if cell_content:
            # Get cell vertical alignment
            vertical_align = (
                getattr(cell, "vertical_align", None) or
                cell_style.get("vAlign") or
                cell_style.get("vertical_alignment") or
                "top"
            )
            
            # Calculate cell margins
            cell_margins = getattr(cell, "cell_margins", {}) or {}
            margin_top = self._get_margin_value(cell_margins.get("top", 0))
            margin_right = self._get_margin_value(cell_margins.get("right", 0))
            margin_bottom = self._get_margin_value(cell_margins.get("bottom", 0))
            margin_left = self._get_margin_value(cell_margins.get("left", 0))
            
            # Calculate content area dimensions
            content_x = cell_x + margin_left
            content_width = width - margin_left - margin_right
            content_height = height - margin_top - margin_bottom
            
            # Calculate total content height (sum of all paragraph heights)
            total_content_height = 0.0
            for item in cell_content:
                is_paragraph = False
                if hasattr(item, "block_type"):
                    is_paragraph = item.block_type == "paragraph"
                elif hasattr(item, "__class__"):
                    class_name = item.__class__.__name__
                    is_paragraph = class_name == "Paragraph" or class_name.endswith("Paragraph")
                
                if is_paragraph:
                    para_content = getattr(item, "content", {})
                    if isinstance(para_content, dict):
                        lines = para_content.get("lines", [])
                        if lines:
                            para_style = getattr(item, "style", {}) or {}
                            line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                            for line_entry in lines:
                                layout = line_entry.get("layout")
                                if layout and hasattr(layout, "height"):
                                    total_content_height += layout.height * line_spacing
                        else:
                            # Estimate paragraph height
                            para_style = getattr(item, "style", {}) or {}
                            font_size = float(para_style.get("font_size", 11.0) or 11.0)
                            line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                            para_text = getattr(item, "text", "") or ""
                            if para_text:
                                line_height = font_size * 1.2 * line_spacing
                                # Estimate lines needed
                                char_width = font_size * 0.6
                                chars_per_line = content_width / char_width if char_width > 0 else 50
                                estimated_lines = max(1, len(para_text) / chars_per_line if chars_per_line > 0 else 1)
                                total_content_height += estimated_lines * line_height
            
            # Calculate vertical alignment offset
            # In PDF coordinates: y increases upward, cell_y_top is top edge
            # content_area_top is top of content area (after margin_top)
            # content_area_bottom is bottom of content area (after margin_bottom)
            content_area_top = cell_y_top - margin_top
            content_area_bottom = cell_y_top - height + margin_bottom
            content_area_height = content_area_top - content_area_bottom  # Actual content height
            
            if vertical_align == "center" or vertical_align == "middle":
                # Center: position content in middle of available space
                # content_y should be at top of content block
                # remaining_space = content_area_height - total_content_height
                # offset = remaining_space / 2.0
                # content_y = content_area_top - offset (but we render downward, so subtract)
                remaining_space = max(0, content_area_height - total_content_height)
                vertical_offset = remaining_space / 2.0
                content_y = content_area_top - vertical_offset
            elif vertical_align == "bottom":
                # Bottom: position content at bottom of available space
                # content_y should be at top of content block, which is above bottom by total_content_height
                content_y = content_area_bottom + total_content_height
            else:
                # Top (default): position content at top of available space
                content_y = content_area_top
            
            # Render each paragraph in the cell
            # Start from calculated content_y and render downward (decrease Y)
            y_cursor = content_y
            
            for item in cell_content:
                # Check if item is a paragraph - either by block_type or by type name
                is_paragraph = False
                if hasattr(item, "block_type"):
                    is_paragraph = item.block_type == "paragraph"
                elif hasattr(item, "__class__"):
                    # Check by class name (Paragraph objects in cells don't have block_type)
                    class_name = item.__class__.__name__
                    is_paragraph = class_name == "Paragraph" or class_name.endswith("Paragraph")
                
                if is_paragraph:
                    # Render paragraph as a block - similar to paragraph rendering
                    para_content = getattr(item, "content", {})
                    if isinstance(para_content, dict):
                        lines = para_content.get("lines", [])
                        if lines:
                            # Get paragraph style
                            para_style = getattr(item, "style", {}) or {}
                            
                            # Render all lines in paragraph
                            for line_entry in lines:
                                text = str(line_entry.get("text", ""))
                                if not text:
                                    continue
                                
                                # Normalize text
                                import unicodedata
                                text = unicodedata.normalize("NFC", text)
                                
                                layout = line_entry.get("layout")
                                if layout:
                                    font_size = float(para_style.get("font_size", 11.0) or 11.0)
                                    baseline = y_cursor - layout.ascent
                                    
                                    # Get alignment for this line
                                    # Priority: paragraph style > cell style (jc) > default (left)
                                    alignment = (
                                        para_style.get("justification") or 
                                        para_style.get("alignment") or
                                        cell_style.get("jc") or  # Cell-level horizontal alignment from tcPr/jc
                                        cell_style.get("alignment") or
                                        "left"
                                    )
                                    
                                    # Normalize alignment values
                                    if alignment in {"both", "distribute"}:
                                        alignment = "justify"
                                    elif alignment in {"end"}:
                                        alignment = "right"
                                    elif alignment in {"start"}:
                                        alignment = "left"
                                    
                                    # Calculate X position based on alignment
                                    line_width = layout.width if hasattr(layout, "width") else None
                                    line_x = content_x
                                    
                                    if alignment == "center" and line_width:
                                        remaining_space = max(0, content_width - line_width)
                                        line_x = content_x + remaining_space / 2.0
                                    elif alignment == "right" and line_width:
                                        remaining_space = max(0, content_width - line_width)
                                        line_x = content_x + remaining_space
                                    elif alignment == "justify" and line_width:
                                        # Justify uses left alignment (word spacing is handled separately)
                                        line_x = content_x
                                    else:
                                        # Left alignment (default)
                                        line_x = content_x
                                    
                                    font_path = para_style.get("font_path")
                                    if isinstance(font_path, dict):
                                        font_path = font_path.get("path")
                                    
                                    self.direct_writer.add_text(
                                        pdf_page, line_x, baseline, text, font_size, font_path
                                    )
                                    
                                    # Advance cursor for next line
                                    y_cursor -= layout.height
                        else:
                            # Paragraph not laid out - render from text and runs
                            para_text = getattr(item, "text", "") or ""
                            para_style = getattr(item, "style", {}) or {}
                            runs = getattr(item, "runs", []) or []
                            
                            # Get alignment - priority: paragraph style > cell style > default
                            alignment = (
                                para_style.get("justification") or 
                                para_style.get("alignment") or
                                cell_style.get("jc") or  # Cell-level horizontal alignment
                                cell_style.get("alignment") or
                                "left"
                            )
                            
                            # Normalize alignment values
                            if alignment in {"both", "distribute"}:
                                alignment = "justify"
                            elif alignment in {"end"}:
                                alignment = "right"
                            elif alignment in {"start"}:
                                alignment = "left"
                            
                            # Estimate line height
                            default_font_size = float(para_style.get("font_size", 11.0) or 11.0)
                            line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                            line_height = default_font_size * 1.2 * line_spacing
                            
                            # Prefer rendering runs if available (more accurate formatting)
                            if runs:
                                # Render runs individually for better formatting
                                # Baseline should be below y_cursor (since we render downward)
                                # y_cursor is at top of cell content area
                                # In PDF, Y increases upward, so to move down we subtract
                                # Baseline should be positioned below y_cursor for text
                                # But first, ensure font_size is correctly converted
                                # If font_size > 12, it's likely in half-points (18 = 9pt), so divide by 2
                                if default_font_size > 12:
                                    default_font_size = default_font_size / 2.0
                                
                                # Position baseline: y_cursor is top of content area
                                # In PDF, text is positioned by baseline, and we need to move down from top
                                # Baseline should be positioned most of the font_size below y_cursor
                                # Use font_size * 0.75 to position baseline correctly (similar to ascent)
                                baseline = y_cursor - default_font_size * 0.75
                                
                                # Get horizontal alignment for runs
                                # Priority: paragraph style > cell style > default (left)
                                run_alignment = (
                                    para_style.get("justification") or 
                                    para_style.get("alignment") or
                                    cell_style.get("jc") or  # Cell-level horizontal alignment
                                    cell_style.get("alignment") or
                                    "left"
                                )
                                
                                # Normalize alignment
                                if run_alignment in {"both", "distribute"}:
                                    run_alignment = "justify"
                                elif run_alignment in {"end"}:
                                    run_alignment = "right"
                                elif run_alignment in {"start"}:
                                    run_alignment = "left"
                                
                                # Calculate starting X position based on alignment
                                # For center/right, we need to calculate total text width first
                                # For now, start at content_x (will adjust after calculating total width)
                                if run_alignment in ("center", "right"):
                                    # Calculate total text width from all runs
                                    total_run_width = 0.0
                                    for r in runs:
                                        r_text = getattr(r, "text", "") or ""
                                        r_style = getattr(r, "style", {}) or {}
                                        r_font_size = float(r_style.get("font_size", default_font_size) or default_font_size)
                                        if r_font_size > 12:
                                            r_font_size = r_font_size / 2.0
                                        total_run_width += len(r_text) * r_font_size * 0.6
                                    
                                    if run_alignment == "center":
                                        remaining_space = max(0, content_width - total_run_width)
                                        x_cursor = content_x + remaining_space / 2.0
                                    else:  # right
                                        remaining_space = max(0, content_width - total_run_width)
                                        x_cursor = content_x + remaining_space
                                else:
                                    # Left or justify
                                    x_cursor = content_x
                                
                                for run in runs:
                                    run_text = getattr(run, "text", "") or ""
                                    if not run_text:
                                        continue
                                    
                                    # Normalize text
                                    import unicodedata
                                    run_text = unicodedata.normalize("NFC", run_text)
                                    
                                    # Get run style
                                    run_style = getattr(run, "style", {}) or {}
                                    
                                    # Get font size - convert from half-points if needed
                                    run_font_size_raw = run_style.get("font_size", default_font_size) or default_font_size
                                    run_font_size = float(run_font_size_raw)
                                    # If font_size > 50, it's likely in half-points (18 = 9pt), so divide by 2
                                    # But also check if it's > 12 (typical point sizes are 8-12pt, half-points are 16-24)
                                    if run_font_size > 12:
                                        run_font_size = run_font_size / 2.0
                                    
                                    # Get font path - try run style first, then para style
                                    run_font_path = run_style.get("font_path")
                                    if not run_font_path:
                                        run_font_path = para_style.get("font_path")
                                    if isinstance(run_font_path, dict):
                                        run_font_path = run_font_path.get("path")
                                    if not isinstance(run_font_path, str):
                                        # Try to resolve font name from font_hAnsi, font_ascii, etc.
                                        font_name = (
                                            run_style.get("font_hAnsi") or 
                                            run_style.get("font_ascii") or 
                                            run_style.get("font_name") or 
                                            para_style.get("font_hAnsi") or 
                                            para_style.get("font_ascii") or 
                                            para_style.get("font_name")
                                        )
                                        # Only resolve if font_name is non-empty string
                                        if font_name and isinstance(font_name, str) and font_name.strip():
                                            from docx_interpreter.engine.font_resolver import resolve_font_path
                                            try:
                                                run_font_path = resolve_font_path(font_name)
                                            except Exception as e:
                                                self.logger.debug(f"Failed to resolve run font in table cell '{font_name}': {e}")
                                                run_font_path = None
                                    
                                    # If still no font path, use fallback
                                    if not isinstance(run_font_path, str):
                                        # Try to get fallback font from direct_writer
                                        fallback_font = self.direct_writer._find_fallback_font()
                                        if fallback_font:
                                            run_font_path = fallback_font
                                    
                                    # Render run - ensure font_path is not None or use None (direct_writer should handle it)
                                    if not isinstance(run_font_path, str):
                                        run_font_path = None  # Let direct_writer use its fallback
                                    
                                    # Render run
                                    self.direct_writer.add_text(
                                        pdf_page, x_cursor, baseline, run_text, run_font_size, run_font_path
                                    )
                                    
                                    # Advance x cursor
                                    char_width = run_font_size * 0.6
                                    x_cursor += len(run_text) * char_width
                                
                                # Advance y cursor after all runs
                                y_cursor -= line_height
                            
                            # Fallback: render para_text if no runs
                            elif para_text:
                                # Normalize text
                                import unicodedata
                                text = unicodedata.normalize("NFC", para_text)
                                
                                # Get font info from style
                                font_size = float(para_style.get("font_size", 11.0) or 11.0)
                                # Convert half-points if needed (typical point sizes are 8-12pt, half-points are 16-24)
                                if font_size > 12:
                                    font_size = font_size / 2.0
                                
                                line_spacing = float(para_style.get("line_spacing", 1.0) or 1.0)
                                line_height = font_size * 1.2 * line_spacing
                                
                                # Get alignment - priority: paragraph style > cell style > default
                                alignment = (
                                    para_style.get("justification") or 
                                    para_style.get("alignment") or
                                    cell_style.get("jc") or  # Cell-level horizontal alignment
                                    cell_style.get("alignment") or
                                    "left"
                                )
                                
                                # Normalize alignment values
                                if alignment in {"both", "distribute"}:
                                    alignment = "justify"
                                elif alignment in {"end"}:
                                    alignment = "right"
                                elif alignment in {"start"}:
                                    alignment = "left"
                                
                                # Get font path
                                font_path = para_style.get("font_path")
                                if isinstance(font_path, dict):
                                    font_path = font_path.get("path")
                                if not isinstance(font_path, str):
                                    # Try to resolve font name
                                    font_name = (
                                        para_style.get("font_hAnsi") or 
                                        para_style.get("font_ascii") or 
                                        para_style.get("font_name")
                                    )
                                    if font_name:
                                        from docx_interpreter.engine.font_resolver import resolve_font_path
                                        try:
                                            font_path = resolve_font_path(font_name)
                                        except Exception as e:
                                            self.logger.debug(f"Failed to resolve paragraph font in table cell '{font_name}': {e}")
                                            font_path = None
                                
                                # Baseline should be below y_cursor (render downward)
                                # Position baseline similar to runs - use font_size * 0.75
                                baseline = y_cursor - font_size * 0.75
                                
                                # Calculate x position based on alignment
                                char_width = font_size * 0.6
                                text_width = len(text) * char_width
                                if alignment == "center" and text_width < content_width:
                                    x_cursor = content_x + (content_width - text_width) / 2.0
                                elif alignment == "right" and text_width < content_width:
                                    x_cursor = content_x + content_width - text_width
                                else:
                                    x_cursor = content_x
                                
                                # Render text
                                self.direct_writer.add_text(
                                    pdf_page, x_cursor, baseline, text, font_size, font_path
                                )
                                
                                # Advance cursor
                                estimated_lines = max(1, len(text) / (content_width / char_width) if char_width > 0 else 1)
                                y_cursor -= estimated_lines * line_height
                    elif hasattr(item, "text"):
                        # Item has text but not block_type paragraph - render it
                        item_text = getattr(item, "text", "") or ""
                        if item_text:
                            import unicodedata
                            text = unicodedata.normalize("NFC", item_text)
                            
                            # Get style from item or cell
                            item_style = getattr(item, "style", {}) or cell_style
                            font_size = float(item_style.get("font_size", 11.0) or 11.0)
                            
                            # Get alignment for item text
                            item_alignment = (
                                item_style.get("justification") or 
                                item_style.get("alignment") or
                                cell_style.get("jc") or  # Cell-level horizontal alignment
                                cell_style.get("alignment") or
                                "left"
                            )
                            
                            # Normalize alignment
                            if item_alignment in {"both", "distribute"}:
                                item_alignment = "justify"
                            elif item_alignment in {"end"}:
                                item_alignment = "right"
                            elif item_alignment in {"start"}:
                                item_alignment = "left"
                            
                            # REQUIRED: font_path must come from DOCX document
                            font_path = item_style.get("font_path")
                            if isinstance(font_path, dict):
                                font_path = font_path.get("path")
                            
                            # If font_path is not available, try to resolve from font_name
                            if not isinstance(font_path, str):
                                font_name = item_style.get("font_name") or item_style.get("font_pdf_name")
                                if font_name:
                                    from docx_interpreter.engine.font_resolver import resolve_font_path
                                    bold = bool(item_style.get("bold") or item_style.get("font_weight") == "bold")
                                    italic = bool(item_style.get("italic") or item_style.get("font_style") == "italic")
                                    resolved = resolve_font_path(str(font_name), bold=bold, italic=italic)
                                    if resolved:
                                        _, font_path = resolved
                                    else:
                                        self.logger.error(
                                            f"Failed to resolve font_path for font_name={font_name!r} "
                                            f"from DOCX table cell item style. Font must be available in system or embedded."
                                        )
                                        raise ValueError(f"Font path not found for font: {font_name}")
                                else:
                                    self.logger.error(
                                        f"Font path is required but not available from DOCX table cell item style. "
                                        f"Neither font_path nor font_name is present. "
                                        f"Font must be resolved from DOCX document."
                                    )
                                    raise ValueError("Font path is required but not available from DOCX table cell item style")
                            
                            # Calculate x position based on alignment
                            char_width = font_size * 0.6
                            text_width = len(text) * char_width
                            if item_alignment == "center" and text_width < content_width:
                                item_x = content_x + (content_width - text_width) / 2.0
                            elif item_alignment == "right" and text_width < content_width:
                                item_x = content_x + content_width - text_width
                            else:
                                item_x = content_x
                            
                            baseline = y_cursor - font_size
                            self.direct_writer.add_text(
                                pdf_page, item_x, baseline, text, font_size, font_path
                            )
                            
                            line_height = font_size * 1.2
                            y_cursor -= line_height
                            
                            # Add spacing between paragraphs
                            y_cursor -= font_size * 0.2
    
    def _get_margin_value(self, value: Any) -> float:
        """Convert margin value to points."""
        if value is None:
            return 0.0
        try:
            numeric = float(value)
            # Convert twips to points if needed
            if numeric > 1000:
                from docx_interpreter.engine.geometry import twips_to_points
                numeric = twips_to_points(numeric)
            return numeric
        except (TypeError, ValueError):
            return 0.0
    
    def _render_cell_borders(
        self, pdf_page: Any, cell: Any, x: float, y: float, width: float, height: float, borders: Dict[str, Any]
    ) -> None:
        """Render cell borders."""
        # Render each border side
        for side in ["top", "right", "bottom", "left"]:
            border_info = borders.get(side, {})
            if isinstance(border_info, dict):
                border_width = border_info.get("width", 0)
                border_color = border_info.get("color", "#000000")
                if border_width and border_width > 0:
                    color = to_color(border_color, fallback="#000000")
                    stroke_color = (color.red, color.green, color.blue)
                    
                    if side == "top":
                        self.direct_writer.add_rect(
                            pdf_page, x, y + height - border_width, width, border_width,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width
                        )
                    elif side == "right":
                        self.direct_writer.add_rect(
                            pdf_page, x + width - border_width, y, border_width, height,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width
                        )
                    elif side == "bottom":
                        self.direct_writer.add_rect(
                            pdf_page, x, y, width, border_width,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width
                        )
                    elif side == "left":
                        self.direct_writer.add_rect(
                            pdf_page, x, y, border_width, height,
                            fill_color=None, stroke_color=stroke_color, stroke_width=border_width
                        )

    def _extract_border(self, style: Dict[str, Any]) -> Tuple[Optional[Tuple[float, float, float]], float]:
        """Extract border from style. Handles both simple and dict formats (top, right, bottom, left)."""
        # First try simple border_color/border_width
        border_color = style.get("border_color")
        border_width = style.get("border_width")
        
        # Then try borders dict (DOCX format)
        borders = style.get("borders", {})
        if isinstance(borders, dict):
            # Try to get any border side
            for side in ["top", "right", "bottom", "left"]:
                border_info = borders.get(side, {})
                if isinstance(border_info, dict):
                    # Check if border is enabled
                    border_val = border_info.get("val") or border_info.get("style")
                    if border_val and border_val.lower() not in {"none", "nil"}:
                        border_width_raw = border_info.get("width", 0)
                        border_color_raw = border_info.get("color", "#000000")
                        if border_color_raw and border_color_raw != "auto":
                            color = to_color(border_color_raw, fallback="#000000")
                            try:
                                width = float(border_width_raw) if border_width_raw else 1.0
                                # Convert twips to points if needed
                                if width > 1000:
                                    from docx_interpreter.engine.geometry import twips_to_points
                                    width = twips_to_points(width)
                            except (TypeError, ValueError):
                                width = 1.0
                            return (color.red, color.green, color.blue), width
        
        # Fallback to simple border_color/border_width
        if not border_color:
            return None, 0.0
        color = to_color(border_color, fallback="#000000")
        try:
            width = float(border_width) if border_width is not None else 1.0
        except (TypeError, ValueError):
            width = 1.0
        return (color.red, color.green, color.blue), width

    # ------------------------------------------------------------------
    # Font resolution helpers
    # ------------------------------------------------------------------
    def _resolve_font_path_from_style(
        self,
        run_style: Dict[str, Any] | None,
        paragraph_style: Dict[str, Any] | None = None,
        fallback_paragraph_font_path: str | None = None,
    ) -> str | None:
        """Resolve a concrete font file path from DOCX run/paragraph styles.

        Tries, in order:
        - explicit run_style["font_path"]
        - run_style font name hints: font_name, font_pdf_name, font_ascii, font_hAnsi, font_eastAsia, font_cs
        - paragraph-level font_path or names
        - provided fallback_paragraph_font_path
        Returns a filesystem path string or None if unresolved.
        """
        try:
            alias_map = {
                # Prefer Liberation family to match LibreOffice default substitutions
                "Calibri": "Liberation Sans",
                "Calibri Light": "Liberation Sans",
                "Arial": "Liberation Sans",
                "Arial Narrow": "Liberation Sans Narrow",
                "Times New Roman": "Liberation Serif",
                "Cambria": "Liberation Serif",
                "Tahoma": "Liberation Sans",
                "Helvetica": "Liberation Sans",
                # East Asia common mappings toward Noto/Liberation (approximate)
                "MS Gothic": "Noto Sans CJK JP",
                "MS Mincho": "Noto Serif CJK JP",
                "SimSun": "Noto Serif CJK SC",
                "SimHei": "Noto Sans CJK SC",
                "PMingLiU": "Noto Serif CJK TC",
                "MingLiU": "Noto Serif CJK TC",
                "Batang": "Noto Serif CJK KR",
                "Gulim": "Noto Sans CJK KR",
                "Yu Gothic": "Noto Sans CJK JP",
                "Yu Mincho": "Noto Serif CJK JP",
            }
            # 1) Direct font_path
            if run_style:
                fp = run_style.get("font_path")
                if isinstance(fp, dict):
                    fp = fp.get("path")
                if isinstance(fp, str):
                    return fp

            # Determine weight/style
            def flags(style: Dict[str, Any] | None) -> tuple[bool, bool]:
                if not style:
                    return False, False
                bold = bool(style.get("bold") or style.get("font_weight") == "bold")
                italic = bool(style.get("italic") or style.get("font_style") == "italic")
                return bold, italic

            bold, italic = flags(run_style)

            # 2) Try run font names in priority order
            name_keys = [
                "font_name",
                "font_pdf_name",
                "font_ascii",
                "font_hAnsi",
                "font_eastAsia",
                "font_cs",
            ]
            from docx_interpreter.engine.font_resolver import resolve_font_path
            if run_style:
                for key in name_keys:
                    val = run_style.get(key)
                    if isinstance(val, dict):
                        val = val.get("name") or val.get("val")
                    if isinstance(val, str) and val.strip():
                        name = val.strip()
                        mapped = alias_map.get(name, name)
                        resolved = resolve_font_path(mapped, bold=bold, italic=italic)
                        if resolved:
                            return resolved[1]

            # 3) Paragraph-level fallbacks
            p_bold, p_italic = flags(paragraph_style)
            if paragraph_style:
                # explicit paragraph font_path
                p_fp = paragraph_style.get("font_path")
                if isinstance(p_fp, dict):
                    p_fp = p_fp.get("path")
                if isinstance(p_fp, str):
                    return p_fp
                for key in name_keys:
                    val = paragraph_style.get(key)
                    if isinstance(val, dict):
                        val = val.get("name") or val.get("val")
                    if isinstance(val, str) and val.strip():
                        name = val.strip()
                        mapped = alias_map.get(name, name)
                        resolved = resolve_font_path(mapped, bold=p_bold, italic=p_italic)
                        if resolved:
                            return resolved[1]

            # 4) Provided fallback
            if isinstance(fallback_paragraph_font_path, str):
                return fallback_paragraph_font_path
        except Exception as e:
            # On any resolver error, return None so caller can decide fallback
            self.logger.debug(f"Error resolving font path: {e}", exc_info=True)
            return None
        return None


__all__ = ["PdfBackend"]

