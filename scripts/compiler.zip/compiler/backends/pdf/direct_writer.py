"""Minimal direct PDF writer used by the compiler backend."""

from __future__ import annotations

import logging
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

logger = logging.getLogger(__name__)


def _escape_text(value: str) -> str:
    return (
        value.replace("\\", r"\\")
        .replace("(", r"\(")
        .replace(")", r"\)")
    )


def _format_color(color: Tuple[float, float, float]) -> str:
    r, g, b = color
    return f"{r:.4f} {g:.4f} {b:.4f}"


@dataclass
class TextCommand:
    x: float
    y: float
    font_size: float
    font_resource: str
    payload: bytes
    unicode: bool
    word_spacing: float = 0.0
    character_positions: list[float] | None = None  # Optional: character position adjustments for TJ operator  # Word spacing for justified text (Tw operator)


@dataclass
class RectCommand:
    x: float
    y: float
    width: float
    height: float
    fill_color: Tuple[float, float, float] | None
    stroke_color: Tuple[float, float, float] | None
    stroke_width: float
    fill_alpha: float = 1.0  # Transparency (0.0 = transparent, 1.0 = opaque)
    stroke_alpha: float = 1.0  # Transparency (0.0 = transparent, 1.0 = opaque)
    radius: float = 0.0  # Border radius for rounded rectangles


@dataclass
class LinkCommand:
    rect: Tuple[float, float, float, float]
    url: str
    internal: bool = False  # Internal link (to page) vs external link (URL)


@dataclass
class ShadowCommand:
    """Command for rendering shadows."""
    x: float
    y: float
    width: float
    height: float
    color: Tuple[float, float, float]
    offset_x: float
    offset_y: float
    blur: float = 2.0
    alpha: float = 0.5


@dataclass
class GradientCommand:
    """Command for rendering gradients."""
    x: float
    y: float
    width: float
    height: float
    start_color: Tuple[float, float, float]
    end_color: Tuple[float, float, float]
    direction: str = "vertical"  # "vertical", "horizontal", "diagonal"
    alpha: float = 1.0


@dataclass
class EllipseCommand:
    """Command for rendering ellipses/circles."""
    x: float
    y: float
    width: float
    height: float
    fill_color: Tuple[float, float, float] | None
    stroke_color: Tuple[float, float, float] | None
    stroke_width: float
    fill_alpha: float = 1.0
    stroke_alpha: float = 1.0


@dataclass
class BezierCommand:
    """Command for rendering Bezier curves."""
    path: List[Tuple[float, float]]  # List of control points (x, y)
    fill_color: Tuple[float, float, float] | None
    stroke_color: Tuple[float, float, float] | None
    stroke_width: float
    fill_alpha: float = 1.0
    stroke_alpha: float = 1.0
    dash_array: List[float] | None = None  # Dash pattern array
    dash_phase: float = 0.0  # Dash phase (offset)


@dataclass
class ImageCommand:
    """Command for rendering images."""
    image_alias: str  # PDF image alias (e.g., "/Im1")
    x: float
    y: float
    width: float
    height: float
    clip_x: float | None = None
    clip_y: float | None = None
    clip_width: float | None = None
    clip_height: float | None = None


@dataclass
class BookmarkCommand:
    """Command for PDF bookmarks (outline)."""
    title: str
    page_number: int
    level: int = 0  # Hierarchy level (0 = top level)
    parent: int | None = None  # Parent bookmark ID


@dataclass
class DirectPdfPage:
    width: float
    height: float
    texts: List[TextCommand] = field(default_factory=list)
    rects: List[RectCommand] = field(default_factory=list)
    ellipses: List[EllipseCommand] = field(default_factory=list)
    bezier_curves: List[BezierCommand] = field(default_factory=list)
    shadows: List[ShadowCommand] = field(default_factory=list)
    gradients: List[GradientCommand] = field(default_factory=list)
    links: List[LinkCommand] = field(default_factory=list)
    images: List[ImageCommand] = field(default_factory=list)
    font_resources: set[str] = field(default_factory=set)
    image_resources: set[str] = field(default_factory=set)

    def add_text(
        self,
        x: float,
        y: float,
        payload: bytes,
        font_size: float,
        font_resource: str,
        unicode: bool,
        word_spacing: float = 0.0,
        character_positions: list[float] | None = None,
    ) -> None:
        if not payload:
            return
        self.texts.append(
            TextCommand(
                x=float(x),
                y=float(y),
                font_size=float(font_size),
                font_resource=font_resource,
                payload=payload,
                unicode=unicode,
                word_spacing=float(word_spacing),
                character_positions=character_positions,
            )
        )
        self.font_resources.add(font_resource)

    def add_rect(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        fill_color: Tuple[float, float, float] | None,
        stroke_color: Tuple[float, float, float] | None,
        stroke_width: float,
        fill_alpha: float = 1.0,
        stroke_alpha: float = 1.0,
        radius: float = 0.0,
    ) -> None:
        """Add rectangle command with optional transparency and border radius."""
        self.rects.append(
            RectCommand(
                x=float(x),
                y=float(y),
                width=float(width),
                height=float(height),
                fill_color=fill_color,
                stroke_color=stroke_color,
                stroke_width=float(stroke_width),
                fill_alpha=float(fill_alpha),
                stroke_alpha=float(stroke_alpha),
                radius=float(radius),
            )
        )

    def add_link(self, x1: float, y1: float, x2: float, y2: float, url: str, internal: bool = False) -> None:
        self.links.append(LinkCommand(rect=(float(x1), float(y1), float(x2), float(y2)), url=url, internal=internal))
    
    def add_shadow(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        color: Tuple[float, float, float],
        offset_x: float,
        offset_y: float,
        blur: float = 2.0,
        alpha: float = 0.5,
    ) -> None:
        """Add shadow command."""
        self.shadows.append(
            ShadowCommand(
                x=float(x),
                y=float(y),
                width=float(width),
                height=float(height),
                color=color,
                offset_x=float(offset_x),
                offset_y=float(offset_y),
                blur=float(blur),
                alpha=float(alpha),
            )
        )
    
    def add_gradient(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        start_color: Tuple[float, float, float],
        end_color: Tuple[float, float, float],
        direction: str = "vertical",
        alpha: float = 1.0,
    ) -> None:
        """Add gradient command."""
        self.gradients.append(
            GradientCommand(
                x=float(x),
                y=float(y),
                width=float(width),
                height=float(height),
                start_color=start_color,
                end_color=end_color,
                direction=direction,
                alpha=float(alpha),
            )
        )
    
    def add_ellipse(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        fill_color: Tuple[float, float, float] | None,
        stroke_color: Tuple[float, float, float] | None,
        stroke_width: float,
        fill_alpha: float = 1.0,
        stroke_alpha: float = 1.0,
    ) -> None:
        """Add ellipse/circle command."""
        self.ellipses.append(
            EllipseCommand(
                x=float(x),
                y=float(y),
                width=float(width),
                height=float(height),
                fill_color=fill_color,
                stroke_color=stroke_color,
                stroke_width=float(stroke_width),
                fill_alpha=float(fill_alpha),
                stroke_alpha=float(stroke_alpha),
            )
        )
    
    def add_bezier(
        self,
        path: List[Tuple[float, float]],
        fill_color: Tuple[float, float, float] | None,
        stroke_color: Tuple[float, float, float] | None,
        stroke_width: float,
        fill_alpha: float = 1.0,
        stroke_alpha: float = 1.0,
        dash_array: List[float] | None = None,
        dash_phase: float = 0.0,
    ) -> None:
        """Add Bezier curve command with optional dash pattern."""
        self.bezier_curves.append(
            BezierCommand(
                path=path,
                fill_color=fill_color,
                stroke_color=stroke_color,
                stroke_width=float(stroke_width),
                fill_alpha=float(fill_alpha),
                stroke_alpha=float(stroke_alpha),
                dash_array=dash_array,
                dash_phase=float(dash_phase),
            )
        )
    
    def add_image(
        self,
        image_alias: str,
        x: float,
        y: float,
        width: float,
        height: float,
        clip_x: float | None = None,
        clip_y: float | None = None,
        clip_width: float | None = None,
        clip_height: float | None = None,
    ) -> None:
        """Add image command."""
        self.images.append(
            ImageCommand(
                image_alias=image_alias,
                x=float(x),
                y=float(y),
                width=float(width),
                height=float(height),
                clip_x=float(clip_x) if clip_x is not None else None,
                clip_y=float(clip_y) if clip_y is not None else None,
                clip_width=float(clip_width) if clip_width is not None else None,
                clip_height=float(clip_height) if clip_height is not None else None,
            )
        )
        self.image_resources.add(image_alias)

    def build_stream(self) -> bytes:
        parts: List[str] = []
        
        # Draw shadows first (behind everything)
        for shadow in self.shadows:
            commands: List[str] = []
            commands.append("q")  # Save graphics state
            # Set shadow color with transparency
            r, g, b = shadow.color
            commands.append(f"{r:.4f} {g:.4f} {b:.4f} rg")  # Fill color
            # Apply blur effect (simple approximation)
            if shadow.blur > 0:
                # Create multiple overlapping rectangles for blur effect
                blur_steps = max(1, int(shadow.blur))
                for step in range(blur_steps):
                    alpha = shadow.alpha * (1.0 - step / blur_steps) * 0.3
                    commands.append(f"/Gs{step} gs")  # Graphics state for alpha
                    offset_factor = step * 0.5
                    x = shadow.x + shadow.offset_x * (1.0 - offset_factor * 0.1)
                    y = shadow.y + shadow.offset_y * (1.0 - offset_factor * 0.1)
                    w = shadow.width * (1.0 + offset_factor * 0.05)
                    h = shadow.height * (1.0 + offset_factor * 0.05)
                    commands.append(f"{x:.2f} {y:.2f} {w:.2f} {h:.2f} re f")
            else:
                # Simple shadow without blur
                x = shadow.x + shadow.offset_x
                y = shadow.y + shadow.offset_y
                commands.append(f"{x:.2f} {y:.2f} {shadow.width:.2f} {shadow.height:.2f} re f")
            commands.append("Q")  # Restore graphics state
            parts.append("\n".join(commands))
        
        # Draw gradients (after shadows, before backgrounds)
        for gradient in self.gradients:
            commands: List[str] = []
            commands.append("q")  # Save graphics state
            # Create gradient pattern (simplified - using shading)
            # For full gradient support, would need ExtGState and Shading dictionaries
            # Here we use a simplified approximation with multiple rectangles
            steps = 10
            r1, g1, b1 = gradient.start_color
            r2, g2, b2 = gradient.end_color
            
            if gradient.direction == "vertical":
                step_height = gradient.height / steps
                for i in range(steps):
                    ratio = i / (steps - 1) if steps > 1 else 0.0
                    r = r1 + (r2 - r1) * ratio
                    g = g1 + (g2 - g1) * ratio
                    b = b1 + (b2 - b1) * ratio
                    y_pos = gradient.y + i * step_height
                    commands.append(f"{r:.4f} {g:.4f} {b:.4f} rg")
                    commands.append(f"{gradient.x:.2f} {y_pos:.2f} {gradient.width:.2f} {step_height:.2f} re f")
            elif gradient.direction == "horizontal":
                step_width = gradient.width / steps
                for i in range(steps):
                    ratio = i / (steps - 1) if steps > 1 else 0.0
                    r = r1 + (r2 - r1) * ratio
                    g = g1 + (g2 - g1) * ratio
                    b = b1 + (b2 - b1) * ratio
                    x_pos = gradient.x + i * step_width
                    commands.append(f"{r:.4f} {g:.4f} {b:.4f} rg")
                    commands.append(f"{x_pos:.2f} {gradient.y:.2f} {step_width:.2f} {gradient.height:.2f} re f")
            else:  # diagonal
                # Diagonal gradient - use vertical as approximation
                step_height = gradient.height / steps
                for i in range(steps):
                    ratio = i / (steps - 1) if steps > 1 else 0.0
                    r = r1 + (r2 - r1) * ratio
                    g = g1 + (g2 - g1) * ratio
                    b = b1 + (b2 - b1) * ratio
                    y_pos = gradient.y + i * step_height
                    commands.append(f"{r:.4f} {g:.4f} {b:.4f} rg")
                    commands.append(f"{gradient.x:.2f} {y_pos:.2f} {gradient.width:.2f} {step_height:.2f} re f")
            
            commands.append("Q")  # Restore graphics state
            parts.append("\n".join(commands))
        
        # Draw rectangles (backgrounds) - now with alpha and radius support
        for rect in self.rects:
            commands: List[str] = []
            commands.append("q")  # Save graphics state
            
            # Apply transparency if needed
            if rect.fill_alpha < 1.0 or rect.stroke_alpha < 1.0:
                # Note: Full transparency support requires ExtGState objects
                # This is a simplified version - actual PDF needs /ExtGState dictionary
                # For now, we'll use basic graphics state (alpha support may be limited)
                if rect.fill_alpha < 1.0:
                    # Approximate alpha with color intensity
                    pass  # Will be handled by color adjustment if needed
            
            if rect.fill_color is not None:
                commands.append(f"{_format_color(rect.fill_color)} rg")
            if rect.stroke_color is not None:
                commands.append(f"{_format_color(rect.stroke_color)} RG")
                commands.append(f"{rect.stroke_width:.2f} w")
            else:
                commands.append("0 w")
            
            # Handle rounded rectangles
            if rect.radius > 0:
                # Draw rounded rectangle using Bezier curves
                # Simplified: use 4 arcs (one per corner)
                x, y, w, h, r = rect.x, rect.y, rect.width, rect.height, min(rect.radius, min(w, h) / 2)
                
                # Path for rounded rectangle
                commands.append(f"{x + r} {y} m")  # Move to first corner
                commands.append(f"{x + w - r} {y} l")  # Line to second corner
                # Top-right corner arc (approximate with Bezier)
                commands.append(f"{x + w} {y + r} {x + w - r} {y} {x + w - r} {y + r} c")
                commands.append(f"{x + w} {y + h - r} l")  # Line to third corner
                # Bottom-right corner arc
                commands.append(f"{x + w - r} {y + h} {x + w} {y + h - r} {x + w - r} {y + h - r} c")
                commands.append(f"{x + r} {y + h} l")  # Line to fourth corner
                # Bottom-left corner arc
                commands.append(f"{x} {y + h - r} {x + r} {y + h} {x + r} {y + h - r} c")
                commands.append(f"{x} {y + r} l")  # Line back to first corner
                # Top-left corner arc
                commands.append(f"{x + r} {y} {x} {y + r} {x + r} {y + r} c")
                commands.append("h")  # Close path
            else:
                commands.append(f"{rect.x:.2f} {rect.y:.2f} {rect.width:.2f} {rect.height:.2f} re")
            
            if rect.fill_color is not None and rect.stroke_color is not None:
                commands.append("B")  # Fill and stroke
            elif rect.fill_color is not None:
                commands.append("f")  # Fill only
            elif rect.stroke_color is not None:
                commands.append("S")  # Stroke only
            
            commands.append("Q")  # Restore graphics state
            parts.append("\n".join(commands))
        
        # Draw ellipses/circles
        for ellipse in self.ellipses:
            commands: List[str] = []
            commands.append("q")  # Save graphics state
            
            # Apply transparency
            if ellipse.fill_alpha < 1.0:
                # Note: Full transparency requires ExtGState - simplified version for now
                pass
            if ellipse.stroke_alpha < 1.0:
                pass
            
            if ellipse.fill_color is not None:
                commands.append(f"{_format_color(ellipse.fill_color)} rg")
            if ellipse.stroke_color is not None:
                commands.append(f"{_format_color(ellipse.stroke_color)} RG")
                commands.append(f"{ellipse.stroke_width:.2f} w")
            else:
                commands.append("0 w")
            
            # Draw ellipse using Bezier curves (approximation)
            center_x = ellipse.x + ellipse.width / 2.0
            center_y = ellipse.y + ellipse.height / 2.0
            rx = ellipse.width / 2.0
            ry = ellipse.height / 2.0
            
            # Magic number for ellipse approximation: 4/3 * (sqrt(2) - 1)
            kappa = 0.5522847498
            
            # Starting point (top of ellipse)
            start_x = center_x
            start_y = ellipse.y + ellipse.height
            
            commands.append(f"{start_x:.2f} {start_y:.2f} m")  # Move to start
            
            # First quadrant (top-right)
            c1x = center_x + rx * kappa
            c1y = start_y
            c2x = center_x + rx
            c2y = center_y + ry * kappa
            end_x = center_x + rx
            end_y = center_y
            commands.append(f"{c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {end_x:.2f} {end_y:.2f} c")
            
            # Second quadrant (bottom-right)
            c1x = end_x
            c1y = center_y - ry * kappa
            c2x = center_x + rx * kappa
            c2y = ellipse.y
            end_x = center_x
            end_y = ellipse.y
            commands.append(f"{c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {end_x:.2f} {end_y:.2f} c")
            
            # Third quadrant (bottom-left)
            c1x = center_x - rx * kappa
            c1y = end_y
            c2x = center_x - rx
            c2y = center_y - ry * kappa
            end_x = center_x - rx
            end_y = center_y
            commands.append(f"{c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {end_x:.2f} {end_y:.2f} c")
            
            # Fourth quadrant (top-left) - back to start
            c1x = end_x
            c1y = center_y + ry * kappa
            c2x = center_x - rx * kappa
            c2y = start_y
            commands.append(f"{c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {start_x:.2f} {start_y:.2f} c")
            
            commands.append("h")  # Close path
            
            if ellipse.fill_color is not None and ellipse.stroke_color is not None:
                commands.append("B")
            elif ellipse.fill_color is not None:
                commands.append("f")
            elif ellipse.stroke_color is not None:
                commands.append("S")
            
            commands.append("Q")  # Restore graphics state
            parts.append("\n".join(commands))
        
        # Draw Bezier curves
        for bezier in self.bezier_curves:
            commands: List[str] = []
            commands.append("q")  # Save graphics state
            
            # Apply transparency
            if bezier.fill_alpha < 1.0:
                pass  # Simplified version
            if bezier.stroke_alpha < 1.0:
                pass
            
            if bezier.fill_color is not None:
                commands.append(f"{_format_color(bezier.fill_color)} rg")
            if bezier.stroke_color is not None:
                commands.append(f"{_format_color(bezier.stroke_color)} RG")
                commands.append(f"{bezier.stroke_width:.2f} w")
            else:
                commands.append("0 w")
            
            # Draw Bezier path
            if bezier.path:
                # Move to first point
                x0, y0 = bezier.path[0]
                commands.append(f"{x0:.2f} {y0:.2f} m")
                
                # Draw curve segments
                # Assume path contains control points in format for cubic Bezier
                i = 1
                while i < len(bezier.path):
                    if i + 2 < len(bezier.path):
                        # Cubic Bezier curve (3 points: control1, control2, end)
                        c1x, c1y = bezier.path[i]
                        c2x, c2y = bezier.path[i + 1]
                        x2, y2 = bezier.path[i + 2]
                        commands.append(f"{c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {x2:.2f} {y2:.2f} c")
                        i += 3
                    elif i + 1 < len(bezier.path):
                        # Quadratic Bezier (2 points: control, end)
                        cx, cy = bezier.path[i]
                        x2, y2 = bezier.path[i + 1]
                        # Convert quadratic to cubic
                        qx, qy = bezier.path[i - 1]
                        c1x = qx + 2/3 * (cx - qx)
                        c1y = qy + 2/3 * (cy - qy)
                        c2x = x2 + 2/3 * (cx - x2)
                        c2y = y2 + 2/3 * (cy - y2)
                        commands.append(f"{c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {x2:.2f} {y2:.2f} c")
                        i += 2
                    else:
                        # Line to point
                        x2, y2 = bezier.path[i]
                        commands.append(f"{x2:.2f} {y2:.2f} l")
                        i += 1
                
                commands.append("h")  # Close path
                
                if bezier.fill_color is not None and bezier.stroke_color is not None:
                    commands.append("B")
                elif bezier.fill_color is not None:
                    commands.append("f")
                elif bezier.stroke_color is not None:
                    # Apply dash pattern if specified
                    if bezier.dash_array:
                        dash_str = " ".join(f"{d:.2f}" for d in bezier.dash_array)
                        commands.append(f"[{dash_str}] {bezier.dash_phase:.2f} d")  # Set dash pattern
                    commands.append("S")
            
            commands.append("Q")  # Restore graphics state
            parts.append("\n".join(commands))
        
        # Draw images
        for image in self.images:
            commands: List[str] = []
            commands.append("q")  # Save graphics state
            
            # If clipping is needed
            if image.clip_x is not None and image.clip_y is not None and image.clip_width is not None and image.clip_height is not None:
                commands.append(f"{image.clip_x:.2f} {image.clip_y:.2f} {image.clip_width:.2f} {image.clip_height:.2f} re")
                commands.append("W")  # Clip
                commands.append("n")  # New path
            
            # Transformation matrix: [width 0 0 height x y]
            commands.append(f"{image.width:.2f} 0 0 {image.height:.2f} {image.x:.2f} {image.y:.2f} cm")
            commands.append(f"{image.image_alias} Do")  # Draw image
            commands.append("Q")  # Restore graphics state
            parts.append("\n".join(commands))

        # Draw text on top
        for command in self.texts:
            # Set word spacing if specified (for justified text)
            word_spacing_cmd = f"{command.word_spacing:.2f} Tw" if command.word_spacing != 0.0 else ""
            
            # Use TJ operator with character positions if available (for proper kerning)
            if command.character_positions and len(command.character_positions) > 0:
                # Use TJ operator for character position adjustments (proper kerning)
                # Format: TJ [text1 adj1 text2 adj2 ...] where adj is position adjustment
                if command.unicode:
                    # For CID fonts: split payload into individual CIDs and add position adjustments
                    hex_bytes = command.payload.hex().upper()
                    # CID fonts use 2 bytes per character
                    cid_count = len(command.payload) // 2
                    if len(command.character_positions) == cid_count:
                        # Build TJ array: [<cid1> adj1 <cid2> adj2 ...]
                        tj_array_parts = []
                        for i in range(cid_count):
                            cid_start = i * 4  # 2 bytes = 4 hex chars
                            cid_end = (i + 1) * 4
                            cid_hex = hex_bytes[cid_start:cid_end]
                            position_adj = command.character_positions[i] if i < len(command.character_positions) else 0.0
                            # Convert position adjustment from points to font units (1/1000 of font size)
                            adj_in_font_units = position_adj * (1000.0 / command.font_size) if command.font_size > 0 else 0.0
                            tj_array_parts.append(f"<{cid_hex}>")
                            tj_array_parts.append(f"{adj_in_font_units:.2f}")
                        tj_array = f"[{' '.join(tj_array_parts)}]"
                        text_commands = f"BT /{command.font_resource} {command.font_size:.2f} Tf"
                        if word_spacing_cmd:
                            text_commands += f" {word_spacing_cmd}"
                        text_commands += f" 1 0 0 1 {command.x:.2f} {command.y:.2f} Tm {tj_array} TJ ET"
                        parts.append(text_commands)
                    else:
                        # Fallback to Tj if position count doesn't match
                        hex_text = f'<{hex_bytes}>'
                        text_commands = f"BT /{command.font_resource} {command.font_size:.2f} Tf"
                        if word_spacing_cmd:
                            text_commands += f" {word_spacing_cmd}"
                        text_commands += f" 1 0 0 1 {command.x:.2f} {command.y:.2f} Tm {hex_text} Tj ET"
                        parts.append(text_commands)
                else:
                    # ASCII text with position adjustments - use TJ operator
                    text_str = command.payload.decode("latin-1", errors="ignore")
                    if len(command.character_positions) == len(text_str):
                        tj_array_parts = []
                        for i, char in enumerate(text_str):
                            escaped_char = _escape_text(char)
                            position_adj = command.character_positions[i] if i < len(command.character_positions) else 0.0
                            # Convert position adjustment from points to font units
                            adj_in_font_units = position_adj * (1000.0 / command.font_size) if command.font_size > 0 else 0.0
                            tj_array_parts.append(f"({escaped_char})")
                            tj_array_parts.append(f"{adj_in_font_units:.2f}")
                        tj_array = f"[{' '.join(tj_array_parts)}]"
                        text_commands = f"BT /{command.font_resource} {command.font_size:.2f} Tf"
                        if word_spacing_cmd:
                            text_commands += f" {word_spacing_cmd}"
                        text_commands += f" 1 0 0 1 {command.x:.2f} {command.y:.2f} Tm {tj_array} TJ ET"
                        parts.append(text_commands)
                    else:
                        # Fallback to Tj
                        escaped = _escape_text(text_str)
                        text_commands = f"BT /{command.font_resource} {command.font_size:.2f} Tf"
                        if word_spacing_cmd:
                            text_commands += f" {word_spacing_cmd}"
                        text_commands += f" 1 0 0 1 {command.x:.2f} {command.y:.2f} Tm ({escaped}) Tj ET"
                        parts.append(text_commands)
            else:
                # No character positions - use standard Tj operator
                if command.unicode:
                    hex_bytes = command.payload.hex().upper()
                    hex_text = f'<{hex_bytes}>'
                    text_commands = f"BT /{command.font_resource} {command.font_size:.2f} Tf"
                    if word_spacing_cmd:
                        text_commands += f" {word_spacing_cmd}"
                    text_commands += f" 1 0 0 1 {command.x:.2f} {command.y:.2f} Tm {hex_text} Tj ET"
                    parts.append(text_commands)
                else:
                    escaped = _escape_text(command.payload.decode("latin-1", errors="ignore"))
                    text_commands = f"BT /{command.font_resource} {command.font_size:.2f} Tf"
                    if word_spacing_cmd:
                        text_commands += f" {word_spacing_cmd}"
                    text_commands += f" 1 0 0 1 {command.x:.2f} {command.y:.2f} Tm ({escaped}) Tj ET"
                    parts.append(text_commands)
        if not parts:
            return b""
        return "\n".join(parts).encode("latin-1", errors="ignore") + b"\n"


@dataclass
class FontSubset:
    path: Path
    resource_name: str
    codes: Dict[str, int] = field(default_factory=dict)
    code_to_unicode: Dict[int, int] = field(default_factory=dict)
    code_to_gid: Dict[int, int] = field(default_factory=dict)
    next_code: int = 1
    fontfile_id: int = 0
    descriptor_id: int = 0
    cidfont_id: int = 0
    cidtogid_id: int = 0
    tounicode_id: int = 0
    type0_id: int = 0

    def encode(self, text: str) -> bytes:
        """Encode text as CID codes for this font subset, tracking Unicode and GID mappings."""
        from fontTools.ttLib import TTFont
        
        # Load font to get Unicode → GID mapping
        if not hasattr(self, '_font_cmap') or not hasattr(self, '_font_unicode_to_gid'):
            try:
                font = TTFont(str(self.path))
                self._font = font
                
                # Get Unicode → glyph name mapping
                cmap = font.getBestCmap()
                self._font_cmap = cmap
                
                # Build glyph name → GID mapping from font tables
                glyph_name_to_gid = {}
                if 'cmap' in font:
                    # Find Unicode BMP table (format 4)
                    for table in font['cmap'].tables:
                        if table.platformID == 3 and table.platEncID == 1:  # Unicode BMP
                            if hasattr(table, 'cmap'):
                                # table.cmap maps Unicode → glyph name
                                # We need to map glyph name → GID
                                # Get glyph order from font
                                if 'glyf' in font:
                                    glyph_order = font.getGlyphOrder()
                                    for i, glyph_name in enumerate(glyph_order):
                                        glyph_name_to_gid[glyph_name] = i
                                elif 'CFF ' in font:
                                    # For CFF fonts, use CFF table
                                    cff = font['CFF ']
                                    top_dict = cff.cff.topDictIndex[0]
                                    char_strings = top_dict.CharStrings
                                    for i, glyph_name in enumerate(char_strings.keys()):
                                        glyph_name_to_gid[glyph_name] = i
                                break
                
                # Build Unicode → GID mapping
                self._font_unicode_to_gid = {}
                for uni_code, glyph_name in cmap.items():
                    gid = glyph_name_to_gid.get(glyph_name, 0)
                    self._font_unicode_to_gid[uni_code] = gid
                    
            except Exception as e:
                logger.debug(f"Failed to load font '{font_path}': {e}")
                self._font_cmap = {}
                self._font_unicode_to_gid = {}
                self._font = None
        
        data = bytearray()
        for char in text:
            code = self.codes.get(char)
            if code is None:
                code = self.next_code
                if code > 0xFFFF:
                    code = 0xFFFF
                self.codes[char] = code
                self.code_to_unicode[code] = ord(char)
                
                # Map CID code to GID (glyph index) from font
                uni_code = ord(char)
                if hasattr(self, '_font_unicode_to_gid') and self._font_unicode_to_gid:
                    gid = self._font_unicode_to_gid.get(uni_code, 0)
                else:
                    gid = 0
                
                # Ensure GID is integer
                self.code_to_gid[code] = int(gid) if isinstance(gid, (int, float)) else 0
                
                # Store character for width calculation
                if not hasattr(self, '_characters'):
                    self._characters = []
                if char not in self._characters:
                    self._characters.append(char)
                
                self.next_code = min(code + 1, 0xFFFF)
            data.extend(code.to_bytes(2, "big"))
        return bytes(data)
    
    def get_glyph_width(self, char: str, font_size: float = 1000.0) -> int:
        """Get glyph width in PDF units (1/1000 of font size) from font metrics."""
        if not hasattr(self, '_font') or self._font is None:
            # Fallback: estimate based on font size
            return int(font_size * 0.6)
        
        try:
            uni_code = ord(char)
            if hasattr(self, '_font_unicode_to_gid') and self._font_unicode_to_gid and hasattr(self, '_font') and self._font is not None:
                gid = self._font_unicode_to_gid.get(uni_code)
                if gid is not None:
                    # Get advance width from font metrics (HMTX table)
                    if 'hmtx' in self._font:
                        hmtx = self._font['hmtx']
                        if gid < len(hmtx.metrics):
                            # Get advance width and convert to PDF units
                            advance_width = hmtx.metrics[gid][0]  # First value is advance width in font units
                            # Convert from font units to PDF units (1/1000 of font size)
                            # PDF /W array uses units of 1/1000 of font size
                            # Formula: pdf_width = (advance_width / units_per_em) * 1000
                            # This gives width in units where 1000 = full font size (e.g., 9pt -> width * 9/1000 in points)
                            units_per_em = self._font['head'].unitsPerEm if 'head' in self._font else 1000
                            if units_per_em == 0:
                                units_per_em = 1000  # Safety check
                            
                            # Convert: advance_width (font units) -> pdf_width (1/1000 of font size)
                            # For example: if advance_width = 500 font units, units_per_em = 1000
                            # Then pdf_width = (500 / 1000) * 1000 = 500
                            # This means the character width is 500/1000 = 0.5 of font size
                            pdf_width = (advance_width * 1000.0) / units_per_em
                            # Round to nearest integer for /W array (PDF spec allows fractional but integers are standard)
                            pdf_width = round(pdf_width)
                            if pdf_width > 0:
                                return pdf_width
                    elif 'CFF ' in self._font:
                        # For CFF fonts, use CFF table
                        cff = self._font['CFF ']
                        top_dict = cff.cff.topDictIndex[0]
                        char_strings = top_dict.CharStrings
                        glyph_order = list(char_strings.keys())
                        if gid < len(glyph_order):
                            glyph_name = glyph_order[gid]
                            # Get width from CFF charstring
                            if glyph_name in char_strings:
                                charstring = char_strings[glyph_name]
                                # CFF widths are stored as first operand in charstring
                                # For simplicity, estimate based on glyph name patterns
                                # Common widths: 'a' ~500, 'm' ~750, 'i' ~250
                                if len(glyph_name) > 0:
                                    # Estimate: use average width for CFF
                                    return int(font_size * 0.55)
                            # Fallback for CFF
                            return int(font_size * 0.55)
        except Exception as e:
            logger.debug(f"Failed to get glyph width for char={char!r}, uni_code={uni_code}, font_size={font_size}: {e}")
            # Fallback: estimate based on font size
            # Polish characters are typically similar width to Latin characters
            return int(font_size * 0.55)
        
        # Fallback: estimate based on font size
        return int(font_size * 0.6)


class DirectPdfWriter:
    """Create a PDF document without external dependencies."""

    def __init__(self, output_path: str | Path, dpi: float = 72.0) -> None:
        self.output_path = Path(output_path)
        self.pages: List[DirectPdfPage] = []
        self.font_subsets: Dict[Path, FontSubset] = {}
        self.image_registry: Dict[str, Tuple[bytes, int, int, str]] = {}  # alias -> (data, width, height, type)
        self.image_next_num: int = 1
        self.scale = float(dpi) / 72.0 if dpi else 1.0
        self.bookmarks: List[BookmarkCommand] = []  # PDF bookmarks/outline
        self.metadata: Dict[str, str] = {
            "Title": "Generated PDF",
            "Producer": "DoclingForge PDF Compiler",
            "Creator": "Python PDF Compiler",
        }

    def add_page(self, width: float, height: float) -> DirectPdfPage:
        page = DirectPdfPage(width=float(width) * self.scale, height=float(height) * self.scale)
        self.pages.append(page)
        return page

    def add_link(self, page: DirectPdfPage, x1: float, y1: float, x2: float, y2: float, url: str, internal: bool = False) -> None:
        """Add link (external URL or internal page reference) to page."""
        page.add_link(x1 * self.scale, y1 * self.scale, x2 * self.scale, y2 * self.scale, url, internal=internal)
    
    def add_shadow(
        self,
        page: DirectPdfPage,
        x: float,
        y: float,
        width: float,
        height: float,
        color: Tuple[float, float, float],
        offset_x: float,
        offset_y: float,
        blur: float = 2.0,
        alpha: float = 0.5,
    ) -> None:
        """Add shadow to page."""
        page.add_shadow(
            x * self.scale,
            y * self.scale,
            width * self.scale,
            height * self.scale,
            color,
            offset_x * self.scale,
            offset_y * self.scale,
            blur * self.scale,
            alpha,
        )
    
    def add_gradient(
        self,
        page: DirectPdfPage,
        x: float,
        y: float,
        width: float,
        height: float,
        start_color: Tuple[float, float, float],
        end_color: Tuple[float, float, float],
        direction: str = "vertical",
        alpha: float = 1.0,
    ) -> None:
        """Add gradient to page."""
        page.add_gradient(
            x * self.scale,
            y * self.scale,
            width * self.scale,
            height * self.scale,
            start_color,
            end_color,
            direction,
            alpha,
        )
    
    def add_ellipse(
        self,
        page: DirectPdfPage,
        x: float,
        y: float,
        width: float,
        height: float,
        fill_color: Tuple[float, float, float] | None,
        stroke_color: Tuple[float, float, float] | None,
        stroke_width: float,
        fill_alpha: float = 1.0,
        stroke_alpha: float = 1.0,
    ) -> None:
        """Add ellipse/circle to page."""
        page.add_ellipse(
            x * self.scale,
            y * self.scale,
            width * self.scale,
            height * self.scale,
            fill_color,
            stroke_color,
            stroke_width * self.scale,
            fill_alpha,
            stroke_alpha,
        )
    
    def add_bezier(
        self,
        page: DirectPdfPage,
        path: List[Tuple[float, float]],
        fill_color: Tuple[float, float, float] | None,
        stroke_color: Tuple[float, float, float] | None,
        stroke_width: float,
        fill_alpha: float = 1.0,
        stroke_alpha: float = 1.0,
        dash_array: List[float] | None = None,
        dash_phase: float = 0.0,
    ) -> None:
        """Add Bezier curve to page with optional dash pattern."""
        scaled_path = [(x * self.scale, y * self.scale) for x, y in path]
        scaled_dash = [d * self.scale for d in dash_array] if dash_array else None
        page.add_bezier(
            scaled_path,
            fill_color,
            stroke_color,
            stroke_width * self.scale,
            fill_alpha,
            stroke_alpha,
            dash_array=scaled_dash,
            dash_phase=dash_phase * self.scale,
        )
    
    def add_bezier_with_dash(
        self,
        page: DirectPdfPage,
        path: List[Tuple[float, float]],
        fill_color: Tuple[float, float, float] | None,
        stroke_color: Tuple[float, float, float] | None,
        stroke_width: float,
        fill_alpha: float = 1.0,
        stroke_alpha: float = 1.0,
        dash_array: List[float] | None = None,
        dash_phase: float = 0.0,
    ) -> None:
        """Add Bezier curve with dash pattern (alias for add_bezier with dash_array)."""
        self.add_bezier(
            page, path, fill_color, stroke_color, stroke_width,
            fill_alpha, stroke_alpha, dash_array, dash_phase
        )
    
    def register_image(self, image_data: bytes, width: float, height: float, image_type: str = "JPEG") -> str:
        """Register an image and return its alias.
        
        Args:
            image_data: Raw image data (JPEG or PNG bytes)
            width: Image width in points
            height: Image height in points
            image_type: Image type ("JPEG" or "PNG")
            
        Returns:
            Image alias (e.g., "/Im1")
        """
        alias = f"/Im{self.image_next_num}"
        self.image_next_num += 1
        self.image_registry[alias] = (image_data, int(width), int(height), image_type)
        return alias
    
    def add_image(
        self,
        page: DirectPdfPage,
        image_alias: str,
        x: float,
        y: float,
        width: float,
        height: float,
        clip_x: float | None = None,
        clip_y: float | None = None,
        clip_width: float | None = None,
        clip_height: float | None = None,
    ) -> None:
        """Add image to page.
        
        Args:
            page: PDF page
            image_alias: Image alias from register_image()
            x: X position (left edge)
            y: Y position (bottom edge)
            width: Image width
            height: Image height
            clip_x: Optional clipping X position
            clip_y: Optional clipping Y position
            clip_width: Optional clipping width
            clip_height: Optional clipping height
        """
        scaled_clip_x = clip_x * self.scale if clip_x is not None else None
        scaled_clip_y = clip_y * self.scale if clip_y is not None else None
        scaled_clip_width = clip_width * self.scale if clip_width is not None else None
        scaled_clip_height = clip_height * self.scale if clip_height is not None else None
        
        page.add_image(
            image_alias,
            x * self.scale,
            y * self.scale,
            width * self.scale,
            height * self.scale,
            clip_x=scaled_clip_x,
            clip_y=scaled_clip_y,
            clip_width=scaled_clip_width,
            clip_height=scaled_clip_height,
        )
    
    def add_bookmark(self, title: str, page_number: int, level: int = 0, parent: int | None = None) -> None:
        """Add bookmark to PDF outline."""
        self.bookmarks.append(
            BookmarkCommand(
                title=title,
                page_number=page_number,
                level=level,
                parent=parent,
            )
        )

    def add_rect(
        self,
        page: DirectPdfPage,
        x: float,
        y: float,
        width: float,
        height: float,
        fill_color: Tuple[float, float, float] | None,
        stroke_color: Tuple[float, float, float] | None,
        stroke_width: float,
        fill_alpha: float = 1.0,
        stroke_alpha: float = 1.0,
        radius: float = 0.0,
    ) -> None:
        """Add rectangle with optional transparency and border radius."""
        page.add_rect(
            x * self.scale,
            y * self.scale,
            width * self.scale,
            height * self.scale,
            fill_color,
            stroke_color,
            stroke_width * self.scale,
            fill_alpha,
            stroke_alpha,
            radius * self.scale,
        )

    def encode_text(self, text: str, font_path: str | None) -> tuple[bytes, str, bool]:
        """Encode text for PDF: Always use CID fonts for consistency.
        
        IMPORTANT: We always use CID fonts (even for ASCII-only text) to ensure
        consistent rendering across all lines. Using different fonts (Type1 vs CID)
        for ASCII vs non-ASCII text causes visual inconsistencies (different sizes,
        spacing, appearance) when lines contain mixed content.
        
        REQUIRES: font_path must be provided from DOCX document - no fallbacks allowed.
        """
        # Normalize text to NFC (composed form) for consistent encoding
        text = unicodedata.normalize("NFC", text)
        
        # Always use CID font for consistency, even for ASCII-only text
        # This ensures all lines render with the same font, preventing visual
        # inconsistencies when mixing ASCII and non-ASCII characters
        
        # REQUIRED: font_path must come from DOCX document
        if not font_path:
            error_msg = (
                f"Font path is required but not provided. "
                f"Font must be resolved from DOCX document run style. "
                f"Text: {text[:50]!r}..."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        # For Unicode text with CID font: use CID codes (not UTF-16BE!)
        # CID fonts with Identity-H encoding use CID codes, not UTF-16BE bytes
        subset = self._get_subset(Path(font_path))
        
        # Encode text as CID codes (each character gets a unique CID)
        payload = subset.encode(text)  # Returns CID codes (2 bytes per CID)
        return payload, subset.resource_name, True

    def add_text(
        self,
        page: DirectPdfPage,
        x: float,
        y: float,
        text: str,
        font_size: float,
        font_path: str | None,
        word_spacing: float = 0.0,
        character_positions: list[float] | None = None,
    ) -> None:
        payload, resource, unicode_flag = self.encode_text(text, font_path)
        # Scale character positions if provided
        scaled_positions = None
        if character_positions:
            scaled_positions = [pos * self.scale for pos in character_positions]
        page.add_text(
            x * self.scale,
            y * self.scale,
            payload,
            font_size * self.scale,
            resource,
            unicode_flag,
            word_spacing * self.scale,  # Scale word spacing with DPI
            character_positions=scaled_positions,
        )

    def get_nominal_advances(self, text: str, font_path: str, font_size: float) -> list[float]:
        """Return nominal per-character advances (in points) from font metrics.

        Uses the same font subset machinery as encoding to ensure widths match /W array.
        """
        subset = self._get_subset(Path(font_path))
        advances: list[float] = []
        for ch in text:
            width_1000 = subset.get_glyph_width(ch, 1000.0)
            # Convert from 1/1000 em to points for the given font size
            advances.append((width_1000 / 1000.0) * float(font_size))
        return advances

    def _find_fallback_font(self) -> str | None:
        """Try to find a fallback font that supports Unicode."""
        from docx_interpreter.engine.font_resolver import resolve_font_path
        
        for name in ["DejaVu Sans", "Arial", "Liberation Sans", "Verdana", "Times New Roman"]:
            result = resolve_font_path(name)
            if result:
                return result[1]
        return None

    def _get_subset(self, path: Path) -> FontSubset:
        """Get or create font subset for the given font path.
        
        REQUIRES: Font path must exist and come from DOCX document - no fallbacks allowed.
        """
        resolved = path.expanduser().resolve()
        if not resolved.exists():
            error_msg = (
                f"Font file not found: {path} (resolved: {resolved}). "
                f"Font must be present in the system or embedded in DOCX document. "
                f"No fallback fonts will be used - font must be resolved from DOCX run style."
            )
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)
        
        subset = self.font_subsets.get(resolved)
        if subset is None:
            resource_name = f"FUF{len(self.font_subsets) + 1}"
            subset = FontSubset(path=resolved, resource_name=resource_name)
            self.font_subsets[resolved] = subset
        return subset

    def set_metadata(self, **kwargs: str) -> None:
        self.metadata.update({k: v for k, v in kwargs.items() if v is not None})

    def flush_page(self) -> None:
        # Placeholder for future streaming implementation.
        return None

    def write(self) -> None:
        if not self.pages:
            self.add_page(595.0, 842.0)

        page_count = len(self.pages)

        catalog_id = 1
        pages_id = 2
        page_id_start = 3
        content_id_start = page_id_start + page_count
        base_font_id = content_id_start + page_count

        subsets = list(self.font_subsets.values())
        next_id = base_font_id + 1
        for subset in subsets:
            subset.fontfile_id = next_id
            subset.descriptor_id = next_id + 1
            subset.cidtogid_id = next_id + 2
            subset.cidfont_id = next_id + 3
            subset.tounicode_id = next_id + 4
            subset.type0_id = next_id + 5
            next_id += 6

        # Assign image object IDs
        image_ids: Dict[str, int] = {}
        for alias in self.image_registry.keys():
            image_ids[alias] = next_id
            next_id += 1

        total_links = sum(len(page.links) for page in self.pages)
        annotation_id_start = next_id
        info_id = annotation_id_start + total_links
        total_objects = info_id

        object_map: Dict[int, bytes] = {}

        kids_refs = " ".join(f"{page_id_start + idx} 0 R" for idx in range(page_count))
        # Add bookmarks/outline if any
        outline_id = None
        if self.bookmarks:
            # Build outline structure
            outline_id = next_id
            next_id += 1
            total_objects = next_id
            
            # Create outline items
            outline_items = []
            for idx, bookmark in enumerate(self.bookmarks):
                item_id = next_id
                next_id += 1
                total_objects += 1
                
                # Build outline item
                page_ref = f"{page_id_start + bookmark.page_number - 1} 0 R" if 0 < bookmark.page_number <= page_count else f"{page_id_start} 0 R"
                
                item_dict = f"<< /Title ({_escape_text(bookmark.title)}) /Dest [{page_ref} /XYZ 0 842 0] >>"
                object_map[item_id] = item_dict.encode("latin-1", errors="ignore")
                outline_items.append(f"{item_id} 0 R")
            
            # Create outline dictionary
            outline_dict = f"<< /Type /Outlines /Count {len(self.bookmarks)} /First {outline_items[0] if outline_items else None} /Last {outline_items[-1] if outline_items else None} >>"
            object_map[outline_id] = outline_dict.encode()
            
            # Update catalog with outline
            object_map[catalog_id] = f"<< /Type /Catalog /Pages {pages_id} 0 R /Outlines {outline_id} 0 R >>".encode()
        else:
            object_map[catalog_id] = f"<< /Type /Catalog /Pages {pages_id} 0 R >>".encode()
        object_map[pages_id] = (
            f"<< /Type /Pages /Count {page_count} /Kids [{kids_refs}] >>".encode()
        )

        for idx, page in enumerate(self.pages):
            content_stream = page.build_stream()
            content_id = content_id_start + idx
            object_map[content_id] = (
                f"<< /Length {len(content_stream)} >>\nstream\n".encode()
                + content_stream
                + b"endstream"
            )

        annotation_objects: List[Tuple[int, LinkCommand]] = []
        current_annotation_id = annotation_id_start

        for idx, page in enumerate(self.pages):
            page_id = page_id_start + idx
            content_id = content_id_start + idx
            font_entries = [f"/F1 {base_font_id} 0 R"]
            for subset in subsets:
                if subset.resource_name in page.font_resources:
                    font_entries.append(f"/{subset.resource_name} {subset.type0_id} 0 R")
            
            # Add image resources
            image_entries = []
            for alias in page.image_resources:
                if alias in image_ids:
                    image_entries.append(f"{alias} {image_ids[alias]} 0 R")
            
            resources_parts = [f"/Font << {' '.join(font_entries)} >>"]
            if image_entries:
                resources_parts.append(f"/XObject << {' '.join(image_entries)} >>")
            resources = f"<< {' '.join(resources_parts)} /ProcSet [/PDF /Text /ImageB /ImageC] >>"

            annots_refs: List[str] = []
            for link in page.links:
                annotation_objects.append((current_annotation_id, link))
                annots_refs.append(f"{current_annotation_id} 0 R")
                current_annotation_id += 1

            annots_entry = ""
            if annots_refs:
                annots_entry = f"/Annots [{' '.join(annots_refs)}] "

            page_dict = (
                f"<< /Type /Page /Parent {pages_id} 0 R "
                f"/MediaBox [0 0 {page.width:.2f} {page.height:.2f}] "
                f"/Contents {content_id} 0 R {annots_entry}/Resources {resources} >>"
            ).encode()
            object_map[page_id] = page_dict

        object_map[base_font_id] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"

        # Write image objects
        for alias, (image_data, width, height, image_type) in self.image_registry.items():
            image_id = image_ids[alias]
            
            # Prepare image data
            processed_data = image_data
            image_dict_parts = [
                "/Type /XObject",
                "/Subtype /Image",
                f"/Width {width}",
                f"/Height {height}",
                "/BitsPerComponent 8",
            ]
            
            if image_type == "JPEG":
                image_dict_parts.extend(["/ColorSpace /DeviceRGB", "/Filter /DCTDecode"])
                # JPEG can be embedded directly
                processed_data = image_data
            elif image_type == "PNG":
                # PNG needs to be decoded to raw RGB
                try:
                    from PIL import Image
                    from io import BytesIO
                    
                    png_image = Image.open(BytesIO(image_data))
                    if png_image.mode == "RGBA":
                        rgb_image = Image.new("RGB", png_image.size, (255, 255, 255))
                        rgb_image.paste(png_image, mask=png_image.split()[3])
                        png_image = rgb_image
                    elif png_image.mode != "RGB":
                        png_image = png_image.convert("RGB")
                    
                    processed_data = png_image.tobytes()
                    image_dict_parts.extend(["/ColorSpace /DeviceRGB"])
                except ImportError:
                    logger.warning("PIL not available - cannot decode PNG, image may be corrupted")
                    image_dict_parts.extend(["/ColorSpace /DeviceRGB"])
                except Exception as e:
                    logger.error(f"Failed to decode PNG image: {e}")
                    # Create placeholder
                    processed_data = bytes([238, 238, 238]) * (width * height)
                    image_dict_parts.extend(["/ColorSpace /DeviceRGB"])
            else:
                image_dict_parts.extend(["/ColorSpace /DeviceRGB"])
            
            image_dict_parts.append(f"/Length {len(processed_data)}")
            image_dict = f"<< {' '.join(image_dict_parts)} >>"
            
            object_map[image_id] = (
                image_dict.encode("utf-8") + b"\nstream\n" + processed_data + b"\nendstream"
            )

        for subset in subsets:
            font_data = subset.path.read_bytes()
            object_map[subset.fontfile_id] = (
                f"<< /Length {len(font_data)} >>\nstream\n".encode()
                + font_data
                + b"endstream"
            )

            font_name = subset.resource_name
            descriptor = (
                f"<< /Type /FontDescriptor /FontName /{font_name} /Flags 32 "
                f"/FontBBox [-200 -500 1200 1000] /ItalicAngle 0 "
                f"/Ascent 900 /Descent -300 /CapHeight 700 /StemV 80 "
                f"/FontFile2 {subset.fontfile_id} 0 R >>"
            ).encode()
            object_map[subset.descriptor_id] = descriptor

            # Build CIDToGIDMap: map CID codes to GID (glyph index)
            if subset.code_to_gid:
                max_cid = max(subset.code_to_gid.keys())
                # Create array where index = CID, value = GID
                # Size: (max_cid + 1) entries, each 2 bytes (big-endian uint16)
                gid_array = [0] * (max_cid + 1)
                for cid, gid in subset.code_to_gid.items():
                    if 0 <= cid <= max_cid:
                        gid_value = int(gid) if isinstance(gid, (int, float)) else 0
                        gid_array[cid] = gid_value
                
                # Encode as binary stream (2 bytes per GID, big-endian)
                cidtogid_data = bytearray()
                for gid in gid_array:
                    gid_int = int(gid) if isinstance(gid, (int, float)) else 0
                    cidtogid_data.extend(gid_int.to_bytes(2, "big"))
            else:
                # Empty mapping - create minimal stream (1 CID = 1 entry = 2 bytes)
                cidtogid_data = b'\x00\x00'
            
            object_map[subset.cidtogid_id] = (
                f"<< /Length {len(cidtogid_data)} >>\nstream\n".encode()
                + cidtogid_data
                + b"\nendstream"
            )
            
            # Build /W array with glyph widths for all used CID codes
            # Format: /W [first last [width1 width2 ...]] or /W [first [width1 width2 ...]]
            # IMPORTANT: We use basic glyph widths from HMTX table, NOT HarfBuzz advance_x
            # because HarfBuzz advance_x includes kerning, which should be handled separately
            # For proper rendering with HarfBuzz, glyph positions should be used instead of /W array
            widths_array = []
            if subset.codes and subset.code_to_gid:
                # Get all CID codes that have characters
                used_cids = sorted([cid for cid in subset.codes.values() if cid in subset.code_to_unicode])
                if used_cids:
                    # Calculate widths for each CID - iterate through all codes to ensure all widths are calculated
                    char_to_width = {}
                    cid_to_char = {cid: char for char, cid in subset.codes.items()}
                    
                    # First, calculate widths for all characters we've seen
                    if hasattr(subset, '_characters') and subset._characters:
                        for char in subset._characters:
                            cid = subset.codes.get(char)
                            if cid is not None:
                                # Get width in PDF units (1/1000 of font size)
                                # Use default font size 1000 for calculation
                                # Uses basic glyph width from HMTX table (without kerning)
                                # Conversion: pdf_width = (advance_width / units_per_em) * 1000
                                width = subset.get_glyph_width(char, 1000.0)
                                char_to_width[cid] = width
                    
                    # Also calculate widths for any CID codes we haven't seen yet
                    for cid in used_cids:
                        if cid not in char_to_width:
                            char = cid_to_char.get(cid)
                            if char is not None:
                                width = subset.get_glyph_width(char, 1000.0)
                                char_to_width[cid] = width
                    
                    # Build widths array - use sparse format for non-contiguous CIDs
                    # Format: /W [cid1 [width1] cid2 [width2] ...] for sparse or /W [first last [width1 width2 ...]] for contiguous
                    if used_cids:
                        # Check if CIDs are mostly contiguous
                        sorted_cids = sorted(used_cids)
                        gaps = [sorted_cids[i + 1] - sorted_cids[i] for i in range(len(sorted_cids) - 1)]
                        has_large_gaps = any(gap > 10 for gap in gaps)
                        
                        if has_large_gaps:
                            # Use sparse format: /W [cid1 [width1] cid2 [width2] ...]
                            widths_parts = []
                            for cid in sorted_cids:
                                if cid in char_to_width:
                                    width = char_to_width[cid]
                                else:
                                    char = cid_to_char.get(cid)
                                    if char is not None:
                                        width = subset.get_glyph_width(char, 1000.0)
                                        char_to_width[cid] = width
                                    else:
                                        # Fallback: estimate based on typical character width
                                        width = 550
                                widths_parts.append(str(cid))
                                widths_parts.append(f"[{round(width)}]")
                            widths_str = f"[{' '.join(widths_parts)}]"
                        else:
                            # Use contiguous format: /W [first [width1 width2 ...]]
                            first_cid = sorted_cids[0]
                            last_cid = sorted_cids[-1]
                            widths_list = []
                            for cid in sorted_cids:
                                if cid in char_to_width:
                                    width = char_to_width[cid]
                                else:
                                    char = cid_to_char.get(cid)
                                    if char is not None:
                                        width = subset.get_glyph_width(char, 1000.0)
                                        char_to_width[cid] = width
                                    else:
                                        width = 550
                                widths_list.append(str(round(width)))
                            
                            widths_str = f"[{first_cid} [{' '.join(widths_list)}]]"
                        
                        widths_array = [f"/W {widths_str}"]
            
            # Build CIDFontType2 with /W array
            cidfont_parts = [
                f"<< /Type /Font /Subtype /CIDFontType2 /BaseFont /{font_name}",
                f"/CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >>",
                f"/FontDescriptor {subset.descriptor_id} 0 R",
                f"/CIDToGIDMap {subset.cidtogid_id} 0 R"
            ]
            if widths_array:
                cidfont_parts.extend(widths_array)
            cidfont_parts.append(">>")
            
            cidfont = " ".join(cidfont_parts).encode()
            object_map[subset.cidfont_id] = cidfont

            cmap_lines = [
                "/CIDInit /ProcSet findresource begin",
                "12 dict begin",
                "begincmap",
                "/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def",
                "/CMapName /Adobe-Identity-UCS def",
                "/CMapType 2 def",
                "1 begincodespacerange",
                "<0000><FFFF>",
                "endcodespacerange",
            ]

            mappings = [f"<{code:04X}><{uni:04X}>" for code, uni in sorted(subset.code_to_unicode.items())]
            if mappings:
                cmap_lines.append(f"{len(mappings)} beginbfchar")
                cmap_lines.extend(mappings)
                cmap_lines.append("endbfchar")
            cmap_lines.extend(["endcmap", "CMapName currentdict /CMap defineresource pop", "end", "end"])
            cmap_content = "\n".join(cmap_lines).encode("ascii")
            object_map[subset.tounicode_id] = (
                f"<< /Length {len(cmap_content)} >>\nstream\n".encode()
                + cmap_content
                + b"\nendstream"
            )

            type0 = (
                f"<< /Type /Font /Subtype /Type0 /BaseFont /{font_name} "
                f"/Encoding /Identity-H /DescendantFonts [{subset.cidfont_id} 0 R] "
                f"/ToUnicode {subset.tounicode_id} 0 R >>"
            ).encode()
            object_map[subset.type0_id] = type0

        for obj_id, link in annotation_objects:
            x1, y1, x2, y2 = link.rect
            if link.internal:
                # Internal link to page
                # Extract page number from URL (format: "page:3" or just page number)
                page_num = 1
                if link.url.startswith("page:"):
                    try:
                        page_num = int(link.url.split(":")[1])
                    except (ValueError, IndexError):
                        page_num = 1
                elif link.url.isdigit():
                    page_num = int(link.url)
                
                page_ref = f"{page_id_start + page_num - 1} 0 R" if 0 < page_num <= page_count else f"{page_id_start} 0 R"
                annotation = (
                    f"<< /Type /Annot /Subtype /Link /Rect [{x1:.2f} {y1:.2f} {x2:.2f} {y2:.2f}] "
                    f"/Border [0 0 0] /Dest [{page_ref} /XYZ 0 842 0] >>"
                ).encode("latin-1", errors="ignore")
            else:
                # External URL link
                annotation = (
                    f"<< /Type /Annot /Subtype /Link /Rect [{x1:.2f} {y1:.2f} {x2:.2f} {y2:.2f}] "
                    f"/Border [0 0 0] /A << /S /URI /URI ({_escape_text(link.url)}) >> >>"
                ).encode("latin-1", errors="ignore")
            object_map[obj_id] = annotation

        info_entries = [f"/{key} ({_escape_text(value)})" for key, value in self.metadata.items()]
        object_map[info_id] = f"<< {' '.join(info_entries)} >>".encode()

        with self.output_path.open("wb") as handle:
            handle.write(b"%PDF-1.4\n%\xFF\xFF\xFF\xFF\n")
            offsets: List[int] = []
            for obj_id in range(1, total_objects + 1):
                obj = object_map.get(obj_id, b"<< >>")
                offsets.append(handle.tell())
                handle.write(f"{obj_id} 0 obj\n".encode())
                handle.write(obj)
                if not obj.endswith(b"\n"):
                    handle.write(b"\n")
                handle.write(b"endobj\n")

            xref_offset = handle.tell()
            handle.write(f"xref\n0 {total_objects + 1}\n".encode())
            handle.write(b"0000000000 65535 f \n")
            for offset in offsets:
                handle.write(f"{offset:010} 00000 n \n".encode())
            handle.write(b"trailer\n")
            handle.write(
                f"<< /Size {total_objects + 1} /Root {catalog_id} 0 R /Info {info_id} 0 R >>\n".encode()
            )
            handle.write(b"startxref\n")
            handle.write(f"{xref_offset}\n".encode())
            handle.write(b"%%EOF\n")


__all__ = ["DirectPdfWriter", "DirectPdfPage"]

