"""Backend using new pdfcompiler architecture."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

from docx_interpreter.engine.base_engine import LayoutPage

try:
    from pdfcompiler import PDFCompiler
except ImportError:
    # Fallback if pdfcompiler is not in path
    import sys
    from pathlib import Path
    pdfcompiler_path = Path(__file__).parent.parent.parent / "pdfcompiler"
    if pdfcompiler_path.exists():
        sys.path.insert(0, str(pdfcompiler_path.parent))
    from pdfcompiler import PDFCompiler

from ..compilation_context import CompilationContext


class PdfCompilerBackend:
    """Backend using new pdfcompiler architecture."""
    
    def __init__(
        self,
        output_path: str | Path,
        options: Dict[str, Any] | None = None,
        *,
        context: Optional[CompilationContext] = None,
    ) -> None:
        """Initialize backend.
        
        Args:
            output_path: Path to output PDF file
            options: Backend options
            context: Compilation context
        """
        self.output_path = Path(output_path)
        self.options = options or {}
        self.context = context
        self.logger = logging.getLogger("compiler.pdfcompiler_backend")
        
        # Extract package_reader from context if available
        compiler_options = dict(self.options)
        package_reader = None
        
        if context:
            # Try to get package_reader from context attributes
            if hasattr(context, "package_reader"):
                package_reader = context.package_reader
            # Try to get package_reader from variables
            elif hasattr(context, "variables"):
                package_reader = context.variables.get("package_reader")
        
        if package_reader:
            compiler_options["package_reader"] = package_reader
        
        # Create compiler
        self.compiler = PDFCompiler(self.output_path, options=compiler_options)
    
    def render(self, layout_pages: Sequence[LayoutPage] | Any) -> None:
        """Render layout pages to PDF.
        
        Args:
            layout_pages: Sequence of layout pages
        """
        # Update package_reader from context if available (it may be set after backend initialization)
        if self.context:
            if hasattr(self.context, "variables"):
                package_reader = self.context.variables.get("package_reader")
                if package_reader and not self.compiler.package_reader:
                    self.compiler.package_reader = package_reader
        
        # Normalize pages
        pages = layout_pages
        if hasattr(layout_pages, "pages"):
            pages = getattr(layout_pages, "pages")
        
        if not pages:
            self.logger.warning("No pages to render")
            return
        
        self.logger.info(f"Rendering {len(pages)} pages using new pdfcompiler")
        
        # Compile pages
        self.compiler.compile(pages)
        
        self.logger.info(f"PDF generated: {self.output_path}")
    
    def save(self) -> None:
        """Save PDF file (already saved during compile)."""
        # PDF is already saved during compile
        pass

