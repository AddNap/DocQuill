"""Shared state for a single compilation session."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class CompilationContext:
    """Lightweight container for variables and caches used during compilation."""

    page_number: int = 1
    total_pages: int = 0
    variables: Dict[str, Any] = field(default_factory=dict)
    style_cache: Dict[str, Any] = field(default_factory=dict)

    def get_var(self, key: str, default: Any = "") -> Any:
        return self.variables.get(key, default)

    def set_var(self, key: str, value: Any) -> None:
        self.variables[key] = value


__all__ = ["CompilationContext"]

