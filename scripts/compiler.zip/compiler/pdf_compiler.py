"""High-level PDF compiler orchestrating preprocessing, layout, and rendering."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

from docx_interpreter.engine.geometry import Margins, Size
from docx_interpreter.engine.simple_layout_engine import SimpleLayoutEngine
from docx_interpreter.engine.placeholder_resolver import PlaceholderResolver
from docx_interpreter.renderers.render_utils import ensure_margins, ensure_page_size

from .backends.pdf_backend import PdfBackend
from .backends.pdfcompiler_backend import PdfCompilerBackend
from .compilation_context import CompilationContext
from .diagnostics import logger, time_block
from .preprocessor import Preprocessor
from .types import DocumentModel


@dataclass
class CompilerOptions:
    """Configuration for :class:`PdfCompiler`."""

    margins: Sequence[float] | None = None
    page_size: Sequence[float] | str | None = None
    dpi: float | None = None
    placeholder_values: Dict[str, Any] | None = None
    renderer: str | None = None


class PdfCompiler:
    """Compile a document model into a PDF file using the layout engine."""

    def __init__(
        self,
        model: DocumentModel | Any,  # Accept DocumentModel or Any for flexibility
        output_path: str | Path,
        options: CompilerOptions | Dict[str, Any] | None = None,
        *,
        layout_engine: SimpleLayoutEngine | None = None,
    ) -> None:
        self.model = model
        self.output_path = Path(output_path)
        self.options = self._normalize_options(options)
        self.context = CompilationContext()

        if self.options.placeholder_values:
            self.context.variables.update(self.options.placeholder_values)

        self._external_engine = layout_engine
        
        # Choose backend based on renderer option
        renderer = self.options.renderer or "direct"
        
        if renderer == "pdfcompiler":
            # Use new pdfcompiler architecture
            self.backend = PdfCompilerBackend(
                self.output_path,
                {
                    "margins": self.options.margins,
                    "page_size": self.options.page_size,
                    "dpi": self.options.dpi,
                },
                context=self.context,
            )
        else:
            # Use existing backend (direct or reportlab)
            self.backend = PdfBackend(
                self.output_path,
                {
                    "margins": self.options.margins,
                    "page_size": self.options.page_size,
                    "dpi": self.options.dpi,
                    "backend": self.options.renderer,  # Map "renderer" to "backend" for PdfBackend
                    "renderer": self.options.renderer,  # Keep for compatibility
                },
                context=self.context,
            )

    def compile(self) -> Path:
        """Run the full compilation pipeline."""
        try:
            with time_block("preprocess"):
                preprocessor = Preprocessor(self.model, self.context)
                processed_model = preprocessor.process()

            engine = self._external_engine or self._create_engine(processed_model)

            with time_block("layout"):
                layout_pages = engine.build_layout(processed_model)

            self.context.total_pages = len(layout_pages)

            # Extract package_reader from model for image loading
            package_reader = None
            if hasattr(processed_model, "_package_reader"):
                package_reader = processed_model._package_reader
            elif hasattr(processed_model, "package_reader"):
                package_reader = processed_model.package_reader
            
            # Store package_reader in context for backend
            if package_reader:
                self.context.variables["package_reader"] = package_reader

            with time_block("render"):
                self.backend.render(layout_pages)
                self.backend.save()

            logger.info(
                "[OK] Compiled %d pages → %s",
                self.context.total_pages,
                self.output_path,
            )

            return self.output_path
        except Exception as exc:  # pragma: no cover - propagated errors
            from docx_interpreter.exceptions import CompilationError
            logger.exception("Compilation error: %s", exc)
            raise CompilationError(f"PDF compilation failed: {exc}", details=str(exc)) from exc

    def _normalize_options(
        self, options: CompilerOptions | Dict[str, Any] | None
    ) -> CompilerOptions:
        if options is None:
            return CompilerOptions()
        if isinstance(options, CompilerOptions):
            return options
        if not isinstance(options, dict):
            logger.warning(f"Options is not a dict or CompilerOptions, got {type(options)}. Using defaults.")
            return CompilerOptions()
        recognized: Dict[str, Any] = {
            "margins": options.get("margins"),
            "page_size": options.get("page_size"),
            "dpi": options.get("dpi"),
            "placeholder_values": options.get("placeholder_values"),
            "renderer": options.get("renderer"),
        }
        return CompilerOptions(**recognized)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _create_engine(self, model: DocumentModel | Any) -> SimpleLayoutEngine:
        page_size, margins = self._resolve_geometry(model)

        # Use protocol methods when available, fallback to getattr for compatibility
        if isinstance(model, DocumentModel):
            numbering_data = model._numbering
            context = model._context
        else:
            numbering_data = getattr(model, "_numbering", {})
            context = getattr(model, "_context", None)
        
        doc_defaults = getattr(context, "doc_defaults", {"paragraph": {}, "run": {}}) if context else {"paragraph": {}, "run": {}}

        placeholder_resolver = PlaceholderResolver()
        placeholder_values = getattr(model, "placeholder_values", {}) or {}
        placeholder_resolver.set_values(placeholder_values)

        return SimpleLayoutEngine(
            page_size=page_size,
            margins=margins,
            placeholder_resolver=placeholder_resolver,
            numbering_data=numbering_data,
            doc_defaults=doc_defaults,
        )

    def _resolve_geometry(self, model: DocumentModel | Any) -> Tuple[Size, Margins]:
        if self.options.page_size or self.options.margins:
            width, height = ensure_page_size(self.options.page_size or "A4")
            margins = ensure_margins(self.options.margins or (50, 50, 50, 50))
            return Size(width=float(width), height=float(height)), margins

        # Use protocol method when available
        if isinstance(model, DocumentModel) or hasattr(model, "_determine_page_geometry"):
            try:
                page_size, margins = model._determine_page_geometry()  # type: ignore[attr-defined]
                size = self._coerce_size(page_size)
                coerced_margins = self._coerce_margins(margins)
                if size and coerced_margins:
                    return size, coerced_margins
            except Exception as e:
                logger.debug(f"Failed to determine page geometry from model: {e}")
                # Fall through to defaults

        width, height = ensure_page_size("A4")
        return Size(width=float(width), height=float(height)), Margins(top=50.0, bottom=50.0, left=50.0, right=50.0)

    @staticmethod
    def _coerce_size(value: Any) -> Optional[Size]:
        if isinstance(value, Size):
            return value
        if isinstance(value, (tuple, list)) and len(value) == 2:
            return Size(width=float(value[0]), height=float(value[1]))
        return None

    @staticmethod
    def _coerce_margins(value: Any) -> Optional[Margins]:
        if isinstance(value, Margins):
            return value
        if isinstance(value, (tuple, list)) and len(value) == 4:
            top, right, bottom, left = value
            return Margins(top=float(top), right=float(right), bottom=float(bottom), left=float(left))
        return None


__all__ = ["PdfCompiler", "CompilerOptions"]

