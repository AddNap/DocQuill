"""Command-line utilities for the compiler package."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import Dict, Iterable, Optional, Sequence

from docx_interpreter.document import Document

from .diagnostics import configure_logging
from .pdf_compiler import CompilerOptions, PdfCompiler


def compile_docx_to_pdf(
    input_path: str | Path,
    output_path: str | Path | None = None,
    *,
    page_size: Sequence[float] | str | None = None,
    margins: Sequence[float] | None = None,
    dpi: float | None = None,
    placeholder_values: Optional[Dict[str, str]] = None,
    backend: str | None = None,
) -> Path:
    """Compile a DOCX file into PDF using :class:`PdfCompiler`."""

    input_path = Path(input_path)
    if output_path is None:
        output_path = input_path.with_suffix(".pdf")

    document = Document.from_file(input_path)
    if placeholder_values:
        document.set_placeholder_values(placeholder_values)

    options = CompilerOptions(
        page_size=page_size,
        margins=margins,
        dpi=dpi,
        placeholder_values=placeholder_values,
        renderer=backend,
    )

    compiler = PdfCompiler(document, output_path, options)
    return compiler.compile()


def _parse_margins(value: Optional[str]) -> Optional[Sequence[float]]:
    if not value:
        return None
    parts = [p.strip() for p in value.split(",") if p.strip()]
    if len(parts) != 4:
        raise argparse.ArgumentTypeError("margins must contain four comma-separated values")
    return tuple(float(p) for p in parts)


def _parse_page_size(value: Optional[str]) -> Optional[Sequence[float] | str]:
    if not value:
        return None
    parts = [p.strip() for p in value.split(",") if p.strip()]
    if len(parts) == 2:
        return tuple(float(p) for p in parts)
    if len(parts) == 1:
        return parts[0]
    raise argparse.ArgumentTypeError("page size must be preset name or two comma-separated values")


def _parse_variables(values: Iterable[str] | None) -> Dict[str, str]:
    result: Dict[str, str] = {}
    if not values:
        return result
    for item in values:
        if "=" not in item:
            raise argparse.ArgumentTypeError("variables must be provided as key=value")
        key, value = item.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compile DOCX files into PDF")
    parser.add_argument("input", help="Path to the DOCX file")
    parser.add_argument("-o", "--output", help="Destination PDF path")
    parser.add_argument("--page-size", dest="page_size", help="Page size preset or width,height")
    parser.add_argument("--margins", dest="margins", help="Margins top,right,bottom,left")
    parser.add_argument("--dpi", dest="dpi", type=float, help="Output DPI")
    parser.add_argument(
        "--var",
        dest="variables",
        action="append",
        help="Placeholder variable in key=value form (may be repeated)",
    )
    parser.add_argument(
        "--backend",
        dest="backend",
        default="reportlab",
        help="Rendering backend: reportlab (default) or direct",
    )
    parser.add_argument(
        "--log-level",
        dest="log_level",
        default="WARNING",
        help="Logging level (DEBUG, INFO, WARNING, ERROR)",
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_argument_parser()
    args = parser.parse_args(argv)

    log_level = getattr(logging, (args.log_level or "WARNING").upper(), logging.WARNING)
    configure_logging(log_level)

    margins = _parse_margins(args.margins)
    page_size = _parse_page_size(args.page_size)
    variables = _parse_variables(args.variables)

    compile_docx_to_pdf(
        args.input,
        args.output,
        page_size=page_size,
        margins=margins,
        dpi=args.dpi,
        placeholder_values=variables or None,
        backend=args.backend,
    )

    return 0


__all__ = ["compile_docx_to_pdf", "main", "build_argument_parser"]

