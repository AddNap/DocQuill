"""Diagnostic helpers for the compiler pipeline."""

from __future__ import annotations

import logging
from contextlib import contextmanager
from time import perf_counter
from typing import Iterator


logger = logging.getLogger("compiler")


def configure_logging(level: int = logging.INFO) -> None:
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("[%(levelname)s] %(name)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(level)


@contextmanager
def time_block(msg: str) -> Iterator[None]:
    start = perf_counter()
    try:
        yield
    finally:
        elapsed = perf_counter() - start
        logger.debug("%s finished in %.3fs", msg, elapsed)


__all__ = ["logger", "configure_logging", "time_block"]

